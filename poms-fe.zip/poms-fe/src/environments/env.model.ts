export interface EnvModel {
  production: boolean;
  host: string;
  hostAuth: string;
}
