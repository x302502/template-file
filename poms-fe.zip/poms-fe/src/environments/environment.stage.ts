export const environment = {
  production: true,
  host: 'https://poms-be-dev.smartlogix.biz',
  hostAuth: "https://swm-auth-be.danghung.xyz",
};
