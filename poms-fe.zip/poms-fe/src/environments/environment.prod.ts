import { EnvModel } from "./env.model";

export const environment: EnvModel = {
  production: true,
  host: 'https://poms-be.smartlogix.biz',
  hostAuth: "https://authentication.smartlog.info"
};
