/*
 * Public API Surface of core-lib
 */
export * from './core.module';
