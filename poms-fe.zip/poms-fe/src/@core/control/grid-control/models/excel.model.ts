export class ExcelInfo<T = any> {
  data: T[] = [];
  sheetName: string = "";
  fileName: string = "";
}
