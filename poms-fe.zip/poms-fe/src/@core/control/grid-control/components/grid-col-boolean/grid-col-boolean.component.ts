import { Component, Input, OnInit } from "@angular/core";
import { BooleanColDef, GridRow } from "../../models";



@Component({
  selector: "grid-col-boolean",
  templateUrl: "grid-col-boolean.component.html",
  styleUrls: ["grid-col-boolean.component.less"]
})
export class GridColBooleanComponent {

  @Input() gridRow: GridRow;
  @Input() colDef: BooleanColDef;

  get selected() {
    return this.gridRow.item[this.colDef.field!] + "";
  }

  set selected(value) {
    if(value === 'false'){
      this.gridRow.item[this.colDef.field!] = false;
    }
    if(value === 'true'){
      this.gridRow.item[this.colDef.field!] = true;
    }
  }

  onChangeColumn(event) {
    if (this.colDef && this.colDef.onChange) {
      this.colDef.onChange(this.gridRow.item, this.gridRow)
    }
  }
  onEnterColumn() {
    if (this.colDef && this.colDef.onEnter) {
      this.colDef.onEnter(this.gridRow.item, this.gridRow)
    }
    this.gridRow.editable = false;
  }
  get isDisable() {
    if (!this.colDef.disabled) {
      return false;
    }
    if (typeof this.colDef.disabled === 'boolean') {
      return this.colDef.disabled;
    }
    return this.colDef.disabled(this.gridRow.item, this.gridRow);
  }
}
