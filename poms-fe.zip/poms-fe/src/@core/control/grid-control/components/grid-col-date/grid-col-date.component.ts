import { ChangeDetectorRef, Component, Input } from "@angular/core";
import { DateColDef, GridRow } from "../../models";



@Component({
  selector: "grid-col-date",
  templateUrl: "grid-col-date.component.html",
  styleUrls: ["grid-col-date.component.less"]
})
export class GridColDateComponent {


  @Input()
  gridRow: GridRow;

  @Input()
  colDef: DateColDef

  onChangeColumn() {
    if (this.colDef && this.colDef.onChange) {
      this.colDef.onChange(this.gridRow.item, this.gridRow)
    }
  }
  onEnterColumn() {
    if (this.colDef && this.colDef.onEnter) {
      this.colDef.onEnter(this.gridRow.item, this.gridRow)
    }
    this.gridRow.editable = false;
  }
  get isDisable() {
    if (!this.colDef.disabled) {
      return false;
    }
    if (typeof this.colDef.disabled === 'boolean') {
      return this.colDef.disabled;
    }
    return this.colDef.disabled(this.gridRow.item, this.gridRow);
  }
}
