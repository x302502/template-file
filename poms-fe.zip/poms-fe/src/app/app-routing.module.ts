import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainLayout } from './layouts/main/main.layout';
import { LoginPage } from './pages/login/login.page';
import { AuthService } from './services/auth/auth.service';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/main' },
  {
    path: 'main', component: MainLayout, canActivate: [AuthService], children: [
      { path: '', pathMatch: 'prefix', redirectTo: 'welcome' },
      { path: 'welcome', loadChildren: () => import('./pages/welcome/welcome.module').then(m => m.WelcomeModule) },
      { path: 'masterdata', loadChildren: () => import('./pages/masterdata/masterdata.module').then(m => m.MasterDataModule) },
      { path: 'operation', loadChildren: () => import('./pages/operation/operation.module').then(m => m.OperationModule) },
      { path: 'setting', loadChildren: () => import('./pages/setting/setting.module').then(m => m.SettingModule) }
    ]
  },

  {
    path: 'login', component: LoginPage
  },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
