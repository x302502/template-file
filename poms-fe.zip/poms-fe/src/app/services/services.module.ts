import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { CategoryService, CustomerService, EndpointsService, OrderDetailService, OrdersService, SkuGroupService, SkuService, MasterDataPartnerSerivce, WarehouseCoditioncodeService, LoggerService, IntegratedlogsService, PackService } from "./business";
import { SupplierService } from "./business/supplier.service";

@NgModule({
  imports: [
    CommonModule,
  ],

  providers: [
    SkuService,
    SkuGroupService,
    SupplierService,
    CustomerService,
    OrdersService,
    CategoryService,
    OrderDetailService,
    EndpointsService,
    MasterDataPartnerSerivce,
    WarehouseCoditioncodeService,
    LoggerService,
    IntegratedlogsService,
    PackService
  ]
})

export class ServicesModule { }
