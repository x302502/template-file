import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { API, ApiService } from "../common";

@Injectable()
export class PackService {

  constructor(
    private apiServcie: ApiService
  ) { }

  list(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>(API.PACK.LIST, {
      ...pageRequest,
    })
  }

}