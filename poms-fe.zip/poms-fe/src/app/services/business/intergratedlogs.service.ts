import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { API, ApiService } from "../common";



@Injectable()
export class IntegratedlogsService {
    constructor(private apiServcie: ApiService) {
    }

    listAll(pageRequest: PageRequest) {
        return this.apiServcie.post<PageResponse>(API.INTEGRATEDLOGS.LIST_ALL_TLG, {
            ...pageRequest,
        });
    }

    async save(item = {}) {
        return await this.apiServcie.post<PageResponse>(API.INTEGRATEDLOGS.SAVE, item);
    }

    list(pageRequest: PageRequest) {
        return this.apiServcie.post<PageResponse>(API.INTEGRATEDLOGS.LIST_BY_CLIENT_CODE, pageRequest);
    }

    download(item: { filename: string }) {
        return this.apiServcie.get(API.INTEGRATEDLOGS.DOWNLOAD_FILE, { ...item });
    }

    syncAll(items: any = []) {
        return this.apiServcie.post(API.INTEGRATEDLOGS.SYNC_ALL, items)
    }

}