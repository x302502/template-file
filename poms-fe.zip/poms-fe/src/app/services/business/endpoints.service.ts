import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { ApiService } from "../common";

@Injectable()
export class EndpointsService {
  constructor(private apiServcie: ApiService) {

  }
  list(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>("/api/business/endpoints/list", {
      ...pageRequest,
    });
  }

  save(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/endpoints/save", { ...item });
  }

  delete(item) {
    if(!item) throw `[ENDPOINTS] ENDPOINTS NOT FOUND`;
    return this.apiServcie.post<PageResponse>("/api/business/endpoints/delete", { ...item });
  }

}