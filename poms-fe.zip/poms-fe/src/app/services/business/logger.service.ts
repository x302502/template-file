import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { API, ApiService } from "../common";



@Injectable()
export class LoggerService {
  constructor(private apiServcie: ApiService) {
  }

  listAll(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>(API.LOGGER.LIST_SO_TMS, {
      ...pageRequest,
    });
  }

  async save(item = {}) {
    return await this.apiServcie.post<PageResponse>(API.LOGGER.SAVE, item);
  }

}