import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { API, ApiService } from "../common";


@Injectable()
export class SkuService {

  constructor(private apiServcie: ApiService) {

  }
  list(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>("/api/business/sku/list", {
      ...pageRequest,
    });
  }

  save(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/sku/save-entity", { ...item });
  }

  syncSWM(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/sku/SyncSWM", { skuId: item });
  }

  syncSkuOmstoSwm(items: any = []) {
    return this.apiServcie.post<PageRequest>(API.SKU.SYNC_SKU_MUTIPLE, { skus: items });
  }


  // SGB
  sendSkuToTms(ids: string[]) {
    return this.apiServcie.post<PageRequest>(API.SKU.SEND_TMS_SGB, { ids: ids });
  }

  sendContentFileImport(text: string) {
    return this.apiServcie.post<PageRequest>(API.SKU.READ_FILE_SKU, { text: JSON.stringify(text) });
  }

}