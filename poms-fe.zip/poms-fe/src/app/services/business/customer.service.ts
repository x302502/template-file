import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { API, ApiService } from "../common";



@Injectable()
export class CustomerService {
  constructor(private apiServcie: ApiService) {

  }
  list(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>("/api/business/customer/list", {
      ...pageRequest,
    });
  }

  save(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/customer/save-entity", { ...item });
  }

  syncSWM(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/customer/SyncSWM", { customerId: item });
  }

  syncSWMAll(items: any = []) {
    return this.apiServcie.post<PageResponse>(API.CUSTOMER.SYNC_CUSTOMER_MUTIPLE, { customers: items });
  }

  sendCustomerToTms(items: string[]) {
    return this.apiServcie.post<PageResponse>(API.CUSTOMER.SEND_TMS_SGB, { ids: items });
  }

  readFileCustomer(text: string) {
    return this.apiServcie.post<PageResponse>(API.CUSTOMER.READ_FILE_CUSTOMER, { text: JSON.stringify(text) });
  }
}