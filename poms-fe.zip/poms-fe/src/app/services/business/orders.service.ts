import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { API, ApiService } from "../common";



@Injectable()
export class OrdersService {
  constructor(private apiServcie: ApiService) {

  }
  list(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>("/api/business/orders/list", {
      ...pageRequest,
    });
  }

  save(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/orders/save", { ...item });
  }

  syncSWM(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/orders/SyncSWM", { orderId: item });
  }

  delete(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/orders/delete", { ...item });
  }

  removeSelected(orderIds: string[]) {
    return this.apiServcie.post<PageResponse>("/api/business/orders/removeSelected", orderIds);
  }

  syncAll(items: any = []) {
    return this.apiServcie.post(API.ORDERS.SYNC_ORDERS_MUTIPLE, { orders: items })
  }

  getFiles() {
    return this.apiServcie.get(API.ORDERS.GET_FILES);
  }

  syncTms(items: any = []) {
    return this.apiServcie.post(API.ORDERS.SYNC_TMS, { orders: items })
  }

  getAllOrdersFromSap(dto: { fromdate: string | Date }) {
    return this.apiServcie.post(API.ORDERS.GET_ALL_ORDER_FROM_SAP, dto);
  }

  syncAllStm(items: any = []) {
    return this.apiServcie.post(API.ORDERS.SYNC_ORDERS_STM, { orders: items })
  }


}