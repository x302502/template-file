import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { ApiService } from "../common";

@Injectable()
export class WarehouseCoditioncodeService {
  constructor(private apiServcie: ApiService) { }
  WarehouseConditionCodeController


  public WAREHOUSE_CONDITION_CODE_URL = {
    SAVE: '/api/business/warehouse-conditioncode/save',
    LIST: '/api/business/warehouse-conditioncode/list',
    DELETE: '/api/business/warehouse-conditioncode/delete',
    REMOVE_MANY: '/api/business/warehouse-conditioncode/remove-many'
  }

  save(entity = {}) {
    return this.apiServcie.post<PageResponse>(this.WAREHOUSE_CONDITION_CODE_URL.SAVE, { ...entity });
  }

  list(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>(this.WAREHOUSE_CONDITION_CODE_URL.LIST, {
      ...pageRequest,
    });
  }

  delete(entity = {}) {
    return this.apiServcie.post<PageResponse>(this.WAREHOUSE_CONDITION_CODE_URL.DELETE, { ...entity });
  }

  removeMany(dto: { ids: string[] }) {
    return this.apiServcie.post<PageResponse>(this.WAREHOUSE_CONDITION_CODE_URL.REMOVE_MANY, dto.ids);
  }

}