import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { ApiService } from "../common";

@Injectable()
export class CategoryService {
  constructor(private apiServcie: ApiService) {

  }
  list(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>("/api/business/category/list", {
      ...pageRequest,
    });
  }

  save(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/category/save", { ...item });
  }

  delete(item) {
    return this.apiServcie.post<PageResponse>("/api/business/category/delete", { ...item });
  }

}