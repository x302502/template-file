import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { ApiService } from "../common";


@Injectable()
export class SkuGroupService {

  constructor(private apiServcie: ApiService) {

  }
  list(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>("/api/business/skugroup/list-all", {
      ...pageRequest,
    });
  }

  save(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/skugroup/save", { ...item });
  }
}