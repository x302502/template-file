import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { ApiService } from "../common";

@Injectable()
export class OrderDetailService {
  constructor(private apiServcie: ApiService) {

  }
  list(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>("/api/business/orderdetail/list", {
      ...pageRequest,
    }).catch(err => {
      console.log(err);
      return new PageResponse();
    });
  }

  save(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/orderdetail/save", { ...item });
  }

  delete(item) {
    return this.apiServcie.post<PageResponse>('/api/business/orderdetail/delete', { ...item });
  }

}