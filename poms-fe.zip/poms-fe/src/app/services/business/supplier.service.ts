import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { API, ApiService } from "../common";



@Injectable()
export class SupplierService {
  constructor(private apiServcie: ApiService) {

  }
  list(pageRequest: PageRequest) {
    return this.apiServcie.post<PageResponse>("/api/business/supplier/list", {
      ...pageRequest,
    });
  }

  save(item = {}) {
    return this.apiServcie.post<PageResponse>("/api/business/supplier/save-entity", [item]);
  }

  syncSWM(item = {}){
    return this.apiServcie.post<PageResponse>("/api/business/supplier/SyncSWM", { supplierId: item });
  }

  syncAll(items : any = []){
    return this.apiServcie.post<PageResponse>(API.SUPLLIER.SYNC_SUPPLIER_MUTIPLE, { suppliers: items });
  }
}