import { Injectable } from "@angular/core";
import { PageRequest, PageResponse } from "~/@core/control/grid-control/models";
import { ApiService } from "../common";


@Injectable()
export class MasterDataPartnerSerivce {
  constructor(private apiServcie: ApiService) { }

  public MASTERDATA_URL = {
    GET_CUSTOMER: '/api/intergrate/oms-get-data/getCustomer',
    GET_ITEM: '/api/intergrate/oms-get-data/getItem',
    GET_SUPPLIER: '/api/intergrate/oms-get-data/getSupplier',
    GET_ORDERS: '/api/intergrate/oms-get-data/getOrders',
    GET_PURCHASE_ORDER: '/api/intergrate/oms-get-data/getPurchaseOrder',
    GET_RETURN_ORDER: '/api/intergrate/oms-get-data/getReturnOrder',
    GET_RETURN_PURCHASE_ORDER: '/api/intergrate/oms-get-data/getReturnPurChaseOrder',

    GET_PRODUCTION_STANDARD: '/api/intergrate/masterdata-partner/getProductionStandard',
    GET_INVENTORY_TRANSFER_PRODUCTION: '/api/intergrate/masterdata-partner/getInventoryTransferProduction',
    GET_INVENTORY_TRANSFER: '/api/intergrate/masterdata-partner/getInventoryTransfer',
    GET_OTHER_RECEIPT: '/api/intergrate/masterdata-partner/getOtherReceipt',
    GET_OTHER_ORDER: '/api/intergrate/masterdata-partner/getOtherOrder',
    GET_INVENTORY_TRANSFER_IN: '/api/intergrate/masterdata-partner/getInventoryTranferDraft_14_VfcNOVA',
    GET_INVENTORY_TRANSFER_OUT: '/api/intergrate/masterdata-partner/getInternalTransferDraft_12_VfcNOVA',
    GET_CHANGE_STATUS: '/api/intergrate/masterdata-partner/getChangeStatusOfNOVA',
    GET_GOODS_RECEIPT: '/api/intergrate/masterdata-partner/getGoodsReceiptDraft_18_VfcNOVA',
    GET_GOODS_ISSUE: '/api/intergrate/masterdata-partner/getGoodsIssueDraft_20_VfcNOVA',
  };

  getCustomer(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageResponse>(this.MASTERDATA_URL.GET_CUSTOMER, {
      ...pageRequest, fromdate
    });
  }

  getItem(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageResponse>(this.MASTERDATA_URL.GET_ITEM, { ...pageRequest, fromdate });
  }

  getSupplier(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageResponse>(this.MASTERDATA_URL.GET_SUPPLIER, { ...pageRequest, fromdate });
  }

  getOrders(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageResponse>(this.MASTERDATA_URL.GET_ORDERS, { ...pageRequest, fromdate });
  }

  getPurchaseOrder(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageResponse>(this.MASTERDATA_URL.GET_PURCHASE_ORDER, { ...pageRequest, fromdate  });
  }

  getReturnOrder(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_RETURN_ORDER, { ...pageRequest, fromdate  });
  }

  getReturnPurChaseOrder(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_RETURN_PURCHASE_ORDER, { ...pageRequest, fromdate  });
  }

  getProductionStandard(pageRequest: PageRequest) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_PRODUCTION_STANDARD, { ...pageRequest });
  }

  getInventoryTransferProduction(pageRequest: PageRequest) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_INVENTORY_TRANSFER_PRODUCTION, { ...pageRequest });
  }

  getInventoryTransfer(pageRequest: PageRequest) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_INVENTORY_TRANSFER, { ...pageRequest });
  }

  getOtherReceipt(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_OTHER_RECEIPT, { ...pageRequest, fromdate  });
  }

  getOtherOrder(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_OTHER_ORDER, { ...pageRequest, fromdate  });
  }

  getInventoryTransferIn(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_INVENTORY_TRANSFER_IN, { ...pageRequest, fromdate  });
  }

  getInventoryTransferOut(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_INVENTORY_TRANSFER_OUT, { ...pageRequest, fromdate  });
  }

  getChangeStatus(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_CHANGE_STATUS, { ...pageRequest, fromdate  });
  }

  getGoodsReceipt(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_GOODS_RECEIPT, { ...pageRequest, fromdate });
  }

  getGoodsIssue(pageRequest: PageRequest, fromdate?: string | Date) {
    return this.apiServcie.post<PageRequest>(this.MASTERDATA_URL.GET_GOODS_ISSUE, { ...pageRequest, fromdate });
  }

}