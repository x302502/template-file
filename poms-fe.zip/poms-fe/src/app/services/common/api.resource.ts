export const API = {

  SKU: {
    SYNC_SKU_MUTIPLE: "/api/business/sku/SyncSWMAll",
    SEND_TMS_SGB: "/api/intergrate/sgb-partner/push-category-tms",
    READ_FILE_SKU: "/api/intergrate/mdlz-partner/read-sku",
  },
  SUPLLIER: {
    SYNC_SUPPLIER_MUTIPLE: "/api/business/supplier/SyncSWMAll",
  },
  CUSTOMER: {
    SYNC_CUSTOMER_MUTIPLE: "/api/business/customer/SyncSWMAll",
    SEND_TMS_SGB: "/api/intergrate/sgb-partner/push-shipto-tms",
    READ_FILE_CUSTOMER: "/api/intergrate/mdlz-partner/read-customer",
  },
  ORDERS: {
    SYNC_ORDERS_MUTIPLE: "/api/business/orders/sync-all",
    GET_FILES: "/api/intergrate/trasas-partner/get-file-manual",
    SYNC_TMS: "/api/intergrate/ump-partner/sync-orders-tms",
    GET_ALL_ORDER_FROM_SAP: "/api/intergrate/nandio-partner/get-all-orders-sap",
    SYNC_ORDERS_STM: "/api/business/orders/sync-all-stm",
  },
  LOGGER: {
    LIST_SO_TMS: "/api/business/logger/list-all",
    SAVE: "/api/business/logger/update"
  },
  INTEGRATEDLOGS: {
    LIST_ALL_TLG: "/api/business/integratedlogs/list-all-tlg",
    SAVE: "/api/business/integratedlogs/save",
    LIST_BY_CLIENT_CODE: "/api/business/integratedlogs/list",
    DOWNLOAD_FILE: "/api/intergrate/mdlz-partner/download-file",
    SYNC_ALL: "/api/business/integratedlogs/syncAll",
  },
  PACK: {
    LIST: "/api/business/packs/list"
  }

};