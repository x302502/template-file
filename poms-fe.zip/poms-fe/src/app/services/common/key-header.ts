

export const KeyHeader = {
  token: "token".trim(),
  whseid: "whseid".trim(),
}