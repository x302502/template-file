
export interface AuthModel {
    token: string;

    // User Infomation
    userId: string;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    email: string;
    tel: string;
    avatar: string;
    isMasterUser: boolean;
    isSml: boolean;

    // Client Infomation
    clientId: string;
    clientCode: string;
    isMasterClient: boolean;
    domain: string;
    socketUrl: string;
    socketKey: string;
    backendUrl: string;

    // Danh sách Waresouse
    warehouses: WarehouseModel[];
    strWarehouses: string;

    // Warehouse Infomation
    warehouse: {
        [warehouseCode: string]: WarehouseModel
    };
}

export interface WarehouseModel {
    code: string; // Code của warehouse,
    type: 'DISTRIBUTION' | 'CFS'; // Type của warehouse,
    name: string; // Tên warehouse

    // Các quyền của user trên warehouseCode tương ứng
    claim: {
        [claimCode: string]: Permission
    };

    // Danh sách storerCodes của warehouse đó
    storerCodes: string[];
    strOwners: string;

    // Danh sách storers của warehouse đó
    storers: StorerModel[];

    // Thông tin storer
    storer: {
        [storerkey: string]: StorerModel
    };
}

export interface StorerModel {
    code: string;
    type: 'DEFAULT' | 'XDOCK'; // Type của storer
    name: string;
    address: string;
    phone: string;
    email: string;
    contact: string;
    lottable01: string;
    lottable02: string;
    lottable03: string;
    lottable04: string;
    lottable05: string;
    lottable06: string;
    lottable07: string;
    lottable08: string;
    lottable09: string;
    lottable10: string;
    lottable11: string;
    lottable12: string;
    claim: {
        [claimCode: string]: Permission
    };
}

export type Permission = 'READ' | 'CREATE' | 'EDIT' | 'DELETE';

