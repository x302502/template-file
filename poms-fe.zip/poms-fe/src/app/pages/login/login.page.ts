import { Component } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { NzMessageService } from "ng-zorro-antd/message";
import { AuthService } from "~/app/services/auth";
import { MessageService } from "~/app/services/common/message.service";


@Component({
  selector: "page-login",
  templateUrl: "./login.page.html",
  styleUrls: [
    "./login.page.less"
  ]
})
export class LoginPage {
  validateForm!: FormGroup;

  submitForm(): void {
    for (const i in this.validateForm.controls) {
      this.validateForm.controls[i].markAsDirty();
      this.validateForm.controls[i].updateValueAndValidity();
    }

    console.log('-------------------');
    console.log(this.validateForm.valid);
    console.log('-------------------');

    if (this.validateForm.valid) {
      this.login();
    }

  }

  constructor(private fb: FormBuilder, protected authService: AuthService,
    private messageService: MessageService) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      userName: [null, [Validators.required]],
      password: [null, [Validators.required]]
    });
  }
  login() {
    this.authService.login(this.validateForm.controls['userName'].value, this.validateForm.controls['password'].value).then(() => {
      window.location.href = this.authService.homeUrl;
    }).catch((err) => {
      this.messageService.handleError(err)
    });
  }

}