
import { ModuleRegistry, AllCommunityModules } from '@ag-grid-community/all-modules';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NzI18nService } from 'ng-zorro-antd/i18n';
import { ApiService } from 'src/app/services/common/api.service';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, ISelectDataItem, PageRequest, PageResponse, SelectColDef } from '~/@core/control/grid-control/models';
import { DateUtils } from '~/@core/utils';
import { AuthService } from '~/app/services/auth';
import { MasterDataPartnerSerivce, PackService, SkuGroupService } from '~/app/services/business';
import { SkuService } from '~/app/services/business/sku.service';
import { MessageService } from '~/app/services/common/message.service';
import { NzUploadChangeParam } from 'ng-zorro-antd/upload';
import { NzMessageService } from 'ng-zorro-antd/message';

ModuleRegistry.registerModules(AllCommunityModules);

@Component({
  selector: 'app-pack',
  templateUrl: './pack.component.html',
  styleUrls: ['./pack.component.less']
})
export class PackComponent implements OnInit {
  @ViewChild("girdControl") gird: GridControl;

  constructor(
    private skuGroupService: SkuGroupService,
    private messageService: MessageService,
    private authService: AuthService,
    private skuService: SkuService,
    private packService: PackService,
    private masterDataPartnerSerivce: MasterDataPartnerSerivce,
    private msg: NzMessageService
  ) { }
  gridOption: GridOption;

  private listWhareHouse: ISelectDataItem[] = [];

  async ngOnInit() {
    await this.initGrid();
  }


  initGrid() {
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    this.gridOption.type = "SERVER";
    this.gridOption.commands = [
      {
        icon: {
          nzType: 'send',
          nzTheme: 'outline'
        },
        tooltip: 'Sync WMS',
        onClick: async (item, gridRow) => {
          try {
            const res = await this.skuService.syncSWM(item.id);
          }
          catch (error) {
            this.messageService.handleError(error);
          }
        }
      },
    ]
    // this.gridOption.onSave = async (item, gridRow) => {
    //   try {
    //     const newItem = await this.skuService.save(item);
    //     gridRow.item = newItem;
    //     this.messageService.success();
    //     return true;
    //   } catch (error) {
    //     this.messageService.handleError(error);
    //     return false;
    //   }
    // }

    this.gridOption.columnDefs = [
      {
        field: 'whseId',
        headerName: 'Warehouse',
        type: "SELECT",
        disabled: true,
        selectData: this.authService.listWareHouse.map(wh => {
          return {
            label: wh.name,
            value: wh.whseid
          }
        })
      },
      { field: 'createdDate', headerName: 'Created Date', type: "DATETIME" },
      { field: 'updateDate', headerName: 'Update Date', type: "DATETIME" },
      { field: 'packKey', headerName: 'Pack key', type: "TEXT" },
      { field: 'description', headerName: 'Description', type: "TEXT" },
      { field: 'packUom2', headerName: 'Pack Uom2', type: "TEXT" },
      { field: 'innerPack', headerName: 'Inner Pack', type: "NUMBER" },
      { field: 'packUom3', headerName: 'Pack Uom3', type: "TEXT" },
      { field: 'qty', headerName: 'Qty', type: "NUMBER" },
      { field: 'packUom4', headerName: 'Pack Uom4', type: "TEXT" },
      { field: 'pallet', headerName: 'Pallet', type: "NUMBER" },
      { field: 'packUom8', headerName: 'Pack Uom8', type: "TEXT" },
      { field: 'otherUnit1', headerName: 'Other Unit1', type: "NUMBER" },
      { field: 'packUom9', headerName: 'Pack Uom9', type: "TEXT" },
      { field: 'otherUnit2', headerName: 'Other Unit2', type: "NUMBER" },
      { field: 'syncStatus', headerName: 'Sync Status', type: "TEXT" },
      { field: 'syncDate', headerName: 'Sync Date', type: "DATETIME" },
      { field: 'syncMess', headerName: 'Sync Mess', type: "TEXT" }
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      return this.packService.list(pageRequest);
    }
  }

}
