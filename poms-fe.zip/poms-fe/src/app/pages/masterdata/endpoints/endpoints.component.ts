import { Component, OnInit, ViewChild } from '@angular/core';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, PageRequest } from '~/@core/control/grid-control/models';
import { AuthService, WarehouseModel } from '~/app/services/auth';
import { EndpointsService } from '~/app/services/business';
import { MessageService } from '~/app/services/common/message.service';

@Component({
  selector: 'app-endpoints',
  templateUrl: './endpoints.component.html',
  styleUrls: ['./endpoints.component.scss']
})
export class EndpointsComponent implements OnInit {
  @ViewChild("girdControl") gird: GridControl;
  gridOption: GridOption;

  constructor(
    private messageService: MessageService,
    private authService: AuthService,
    private endpointsService: EndpointsService
  ) { }

  ngOnInit(): void {
    this.initGrid();
  }

  initGrid() {
    const warehouses = this.authService.currentUser.warehouses;
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    this.gridOption.addable = true;
    this.gridOption.type = "SERVER";
    this.gridOption.defaultAction = {
      edit: true,
      delete: false,
    }
    this.gridOption.commands = [
    ]
    this.gridOption.onSave = async (item, gridRow) => {
      try {
        const newItem = await this.endpointsService.save(item);
        gridRow.item = newItem;
        this.messageService.success()
        return true;

      } catch (error) {
        this.messageService.handleError(error);
        return false;
      }
    }
    this.gridOption.columnDefs = [
      {
        field: 'whseId',
        headerName: 'WAREHOUSE',
        type: 'SELECT',
        selectData: warehouses.map((e: WarehouseModel) => {
          return {
            label: e.name,
            value: e.code
          };
        }),
        width: 150,
        disabled: (skuGroup) => skuGroup.id != null
      }, {
        field: 'storerKey',
        headerName: 'OWNER',
        type: 'SELECT',
        width: 150,
        selectData: this.authService.listAllStorer().map(st => {
          return {
            value: st.code,
            label: st.name
          }
        }),
        disabled: (skuGroup) => skuGroup.id != null
      },
      { field: 'code', headerName: 'CODE', type: "TEXT" },
      { field: 'name', headerName: 'NAME', type: "TEXT" },
      { field: 'address', headerName: 'ADDRESS', type: "TEXT" },
      { field: 'countryCode', headerName: 'COUNTRYCODE', type: "TEXT" },
      { field: 'provinceCode', headerName: 'PROVINCECODE', type: "TEXT" },
      { field: 'districtCode', headerName: 'DISTRICTCODE', type: "TEXT" },
      { field: 'wardCode', headerName: 'WARDCODE', type: "TEXT" },
      { field: 'taxCode', headerName: 'TAXCODE', type: "TEXT" },
      { field: 'phoneNumber', headerName: 'PHONENUMBER', type: "TEXT" },
      { field: 'shelfLife', headerName: 'SHELFLIFE', type: "TEXT" },
      
      { field: 'susr01', headerName: 'SUSR01', type: "TEXT" },
      { field: 'susr02', headerName: 'SUSR02', type: "TEXT" },
      { field: 'susr03', headerName: 'SUSR03', type: "TEXT" },
      { field: 'susr04', headerName: 'SUSR04', type: "TEXT" },
      { field: 'susr05', headerName: 'SUSR05', type: "TEXT" },
      { field: 'susr06', headerName: 'SUSR06', type: "TEXT" },
      { field: 'susr07', headerName: 'SUSR07', type: "TEXT" },
      { field: 'susr08', headerName: 'SUSR08', type: "TEXT" },
      { field: 'susr09', headerName: 'SUSR09', type: "TEXT" },
      { field: 'susr10', headerName: 'SUSR10', type: "TEXT" },
      { field: 'susr11', headerName: 'SUSR11', type: "TEXT" },
      { field: 'susr12', headerName: 'SUSR12', type: "TEXT" },
      { field: 'susr13', headerName: 'SUSR13', type: "TEXT" },
      { field: 'susr14', headerName: 'SUSR14', type: "TEXT" },
      { field: 'susr15', headerName: 'SUSR15', type: "TEXT" },
      { field: 'susr16', headerName: 'SUSR16', type: "TEXT" },
      { field: 'susr17', headerName: 'SUSR17', type: "TEXT" },
      { field: 'susr18', headerName: 'SUSR18', type: "TEXT" },
      { field: 'susr19', headerName: 'SUSR19', type: "TEXT" },
      { field: 'susr20', headerName: 'SUSR20', type: "TEXT" },
      { field: 'notes1', headerName: 'NOTES1', type: "TEXT" },
      { field: 'notes2', headerName: 'NOTES2', type: "TEXT" },
      { field: 'createdUser', headerName: 'CREATED USER', type: "TEXT" },
      { field: 'updateUser', headerName: 'UPDATE USER', type: "TEXT" },

      { field: 'createdDate', headerName: 'CREATED DATE', type: "DATE", disabled: true },
      { field: 'updateDate', headerName: 'UPDATE DATE', type: "DATE", disabled: true }
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      return await this.endpointsService.list(pageRequest);
    }

  }

}
