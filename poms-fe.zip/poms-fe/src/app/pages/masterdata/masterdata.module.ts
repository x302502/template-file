import { AgGridModule } from '@ag-grid-community/angular';
import { NgModule } from '@angular/core';
import { MasterDataRoutingModule } from './masterdata-routing.module';
import { SkuComponent } from './sku/sku.component';
import { CoreModule } from 'src/@core';
import { CustomerComponent } from './customer/customer.component';
import { SupplierComponent } from './supplier/supplier.component';
import { ServicesModule } from '~/app/services/services.module';
import { SkuGroupComponent } from './sku-group/sku-group.component';
import { CategoryComponent } from './category/category.component';
import { EndpointsComponent } from './endpoints/endpoints.component';
import { WarehouseConditioncodeComponent } from './warehouse-conditioncode/warehouse-conditioncode.component';
import { PackComponent } from './pack/pack.component';

@NgModule({
  imports: [
    MasterDataRoutingModule,
    CoreModule,
    AgGridModule.withComponents([]),
    ServicesModule,
  ],
  declarations: [

    CustomerComponent,
    SupplierComponent,
    SkuGroupComponent,
    SkuComponent,
    CategoryComponent,
    EndpointsComponent,
    WarehouseConditioncodeComponent,
    PackComponent
  ],
  exports: [
    CustomerComponent,
    SupplierComponent,
    PackComponent,
  ],
  providers: []
})
export class MasterDataModule { }
