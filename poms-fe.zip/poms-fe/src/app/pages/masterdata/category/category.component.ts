import { Component, OnInit, ViewChild } from '@angular/core';
import { NzModalService } from 'ng-zorro-antd/modal';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, PageRequest } from '~/@core/control/grid-control/models';
import { CategoryService } from '~/app/services/business';
import { MessageService } from '~/app/services/common/message.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent implements OnInit {
  @ViewChild("girdControl") gird: GridControl;
  gridOption: GridOption;
  constructor(
    private messageService: MessageService,
    private modalService: NzModalService,
    private categoryService: CategoryService
  ) { }

  ngOnInit(): void {
    this.initGrid();
  }

  initGrid() {
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    this.gridOption.addable = true;
    this.gridOption.type = "SERVER";
    this.gridOption.commands = [
    ]
    this.gridOption.onSave = async (item, gridRow) => {
      try {
        const newItem = await this.categoryService.save(item);
        gridRow.item = newItem;
        this.messageService.success();
        return true;
      } catch (error) {
        this.messageService.handleError(error);
        return false;
      }
    }
    this.gridOption.onDelete = async (item, gridRow) => {
      this.modalService.confirm({
        nzTitle: 'Are you sure delete item ?',
        nzOkText: 'Yes',
        nzOkType: 'primary',
        nzOkDanger: true,
        nzOnOk: async () => {
          await this.categoryService.delete(item)
            .then(() => {
              this.messageService.success();
              this.gird.reload();
              return true;
            })
            .catch((error) => {
              this.messageService.handleError(error);
              return false;
            })
        },
        nzCancelText: 'No',
        nzOnCancel: () => console.log('Cancel')
      });
      return false;
    }

    this.gridOption.columnDefs = [
      {
        field: 'createdDate',
        headerName: 'CREATED DATE',
        type: "DATE"
      },
      {
        field: 'updateDate',
        headerName: 'UPDATE DATE',
        type: "DATE"
      },
      {
        field: 'name',
        headerName: 'NAME',
        type: "TEXT"
      },
      {
        field: 'image',
        headerName: 'IMAGE',
        type: "TEXT"
      },
      {
        field: 'level',
        headerName: 'LEVEL',
        type: "NUMBER"
      },
      {
        field: 'parentId',
        headerName: 'PARENT ID',
        type: "TEXT"
      }
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      return this.categoryService.list(pageRequest);
    }
  }

}
