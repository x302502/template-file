
import { ModuleRegistry, AllCommunityModules, GridOptions } from '@ag-grid-community/all-modules';
import { AgGridAngular } from '@ag-grid-community/angular';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { ApiService } from 'src/app/services/common/api.service';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, PageRequest } from '~/@core/control/grid-control/models';
import { DateUtils } from '~/@core/utils';
import { AuthService, WarehouseModel } from '~/app/services/auth';
import { CustomerService, MasterDataPartnerSerivce } from '~/app/services/business';
import { SupplierService } from '~/app/services/business/supplier.service';
import { MessageService } from '~/app/services/common/message.service';
import { NzUploadChangeParam } from 'ng-zorro-antd/upload';
import { NzMessageService } from 'ng-zorro-antd/message';


ModuleRegistry.registerModules(AllCommunityModules);

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit, AfterViewInit {
  @ViewChild("girdControl") gird: GridControl;
  constructor(
    private messageService: MessageService,
    private authService: AuthService,
    private customerService: CustomerService,
    private masterDataPartnerSerivce: MasterDataPartnerSerivce,
    private msg: NzMessageService
  ) { }
  gridOption: GridOption;
  ngOnInit() {
    this.initGrid();
  }
  initGrid() {
    const warehouses = this.authService.currentUser.warehouses;
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    this.gridOption.addable = true;
    this.gridOption.type = "SERVER";
    this.gridOption.defaultAction = {
      edit: true,
      delete: false,
    }
    this.gridOption.commands = [
      {
        icon: {
          nzType: 'send',
          nzTheme: 'outline'
        },
        tooltip: 'Sync WMS',
        onClick: async (item, gridRow) => {
          try {
            const res = await this.customerService.syncSWM(item.id);
          }
          catch (error) {
            this.messageService.handleError(error);
          }
        }
      },
    ]
    this.gridOption.onSave = async (item, gridRow) => {
      try {
        const newItem = await this.customerService.save(item);
        gridRow.item = newItem;
        this.messageService.success()
        return true;

      } catch (error) {
        this.messageService.handleError(error);
        return false;
      }
    }
    this.gridOption.columnDefs = [
      {
        field: 'whseId',
        headerName: 'Warehouse',
        type: 'SELECT',
        selectData: warehouses.map((e: WarehouseModel) => {
          return {
            label: e.name,
            value: e.code
          };
        }),
        width: 150,
        disabled: (skuGroup) => skuGroup.id != null
      }, {
        field: 'storerKey',
        headerName: 'Storer',
        type: 'SELECT',
        width: 150,
        selectData: this.authService.listAllStorer().map(st => {
          return {
            value: st.code,
            label: st.name
          }
        }),
        disabled: (skuGroup) => skuGroup.id != null
      },
      { field: 'code', headerName: 'Code', type: "TEXT" },
      { field: 'name', headerName: 'Name', type: "TEXT" },
      { field: 'address', headerName: 'Address', type: "TEXT" },
      { field: 'countryCode', headerName: 'Country Code', type: "TEXT" },
      { field: 'provinceCode', headerName: 'Province Code', type: "TEXT" },
      { field: 'districtCode', headerName: 'District Code', type: "TEXT" },
      { field: 'wardCode', headerName: 'Ward Code', type: "TEXT" },
      { field: 'taxCode', headerName: 'Tax Code', type: "TEXT" },
      { field: 'phoneNumber', headerName: 'Phone Number', type: "TEXT" },
      { field: 'susr01', headerName: 'User define 1', type: "TEXT" },
      { field: 'susr02', headerName: 'User define 2', type: "TEXT" },
      { field: 'susr03', headerName: 'User define 3', type: "TEXT" },
      { field: 'susr04', headerName: 'User define 4', type: "TEXT" },
      { field: 'susr05', headerName: 'User define 5', type: "TEXT" },
      { field: 'notes1', headerName: 'Notes 1', type: "TEXT" },
      { field: 'notes2', headerName: 'Notes 2', type: "TEXT" },
      { field: 'createdDate', headerName: 'Created Date', type: "DATE", disabled: true },
      { field: 'updateDate', headerName: 'Update Date', type: "DATE", disabled: true },
      { field: 'wmsSyncStatus', headerName: 'WMS Sync Status', type: "TEXT" },
      { field: 'wmsSyncDate', headerName: 'WMS Sync Date', type: "DATE", disabled: true },
      { field: 'wmsSyncMess', headerName: 'WMS Sync Message', type: "TEXT" },
      { field: 'tmsSync', headerName: 'TMS Message', type: "TEXT" },
      { field: 'notes1', headerName: 'Notes 1', type: "TEXT" },
      { field: 'notes2', headerName: 'Notes 2', type: "TEXT" },
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      return await this.customerService.list(pageRequest);
    }

  }
  ngAfterViewInit(): void {

  }

  async syncAll() {
    const items = this.gird.getItemChecked().map(v => v.item);
    try {
      await this.customerService.syncSWMAll(items);
      this.gird.reload();
    }
    catch (error) {
      throw error;
    }
  }

  async fetchData() {
    this.isVisible = true;
  }

  // Modal
  isVisible = false;
  fromdate = null;

  async handleOk() {
    this.isVisible = false;
    let pageRequest: PageRequest;
    try {
      await this.masterDataPartnerSerivce.getCustomer(pageRequest, DateUtils.formatDate(this.fromdate));
      this.gird.reload();
      this.messageService.success();
    } catch (error) {
      this.messageService.handleError(error);
    }

  }

  handleCancel(): void {
    console.log('Button cancel clicked!');
    this.isVisible = false;
  }

  onChange(result: Date): void {
    this.fromdate = result;
  }

  async sendSCustomerTms() {
    const items = this.gird.getItemChecked().map(v => v.item);
    let ids: string[] = []
    if (items.length > 0) {
      ids = items.map(v => v.id);
    }
    else {
      return;
    }
    try {
      await this.customerService.sendCustomerToTms(ids);
      this.gird.reload();
    }
    catch (error) {
      throw error;
    }
  }

  handleChange(info: NzUploadChangeParam): void {
    if (info.file.status !== 'uploading') {
      console.log(info.file, info.fileList);
      let reader = new FileReader();
      reader.onload = (e) => {
        console.log(e.target.result);
        try {
          this.customerService.readFileCustomer(e.target.result as string)
        } catch (error) {
          throw error;
        }
      }
      reader.readAsText(info.file.originFileObj);
    }
    if (info.file.status === 'done') {
      this.msg.success(`${info.file.name} file uploaded successfully`);
    } else if (info.file.status === 'error') {
      this.msg.error(`${info.file.name} file upload failed.`);
    }
    console.log("info::", info.file);

  }

}
