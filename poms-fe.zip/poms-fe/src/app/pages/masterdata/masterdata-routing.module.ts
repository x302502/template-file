import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CategoryComponent } from './category/category.component';
import { CustomerComponent } from './customer/customer.component';
import { EndpointsComponent } from './endpoints/endpoints.component';
import { OrderDetailComponent } from '../operation/order-detail/order-detail.component';
import { SkuGroupComponent } from './sku-group/sku-group.component';
import { SkuComponent } from './sku/sku.component';
import { SupplierComponent } from './supplier/supplier.component';
import { WarehouseConditioncodeComponent } from './warehouse-conditioncode/warehouse-conditioncode.component';
import { PackComponent } from './pack/pack.component';

const routes: Routes = [
  { path: '', component: SkuComponent },
  { path: 'customer', component: CustomerComponent },
  { path: 'sku', component: SkuComponent },
  { path: 'sku-group', component: SkuGroupComponent },
  { path: 'supplier', component: SupplierComponent },
  { path: 'category', component: CategoryComponent },
  { path: 'endpoints', component: EndpointsComponent },
  { path: 'wareshouse-conditioncode', component: WarehouseConditioncodeComponent },
  { path: 'pack', component: PackComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterDataRoutingModule { }
