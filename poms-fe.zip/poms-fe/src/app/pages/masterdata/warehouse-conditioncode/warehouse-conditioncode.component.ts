import { Component, OnInit, ViewChild } from '@angular/core';
import { NzModalService } from 'ng-zorro-antd/modal';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, PageRequest } from '~/@core/control/grid-control/models';
import { AuthService, WarehouseModel } from '~/app/services/auth';
import { SupplierService, WarehouseCoditioncodeService } from '~/app/services/business';
import { MessageService } from '~/app/services/common/message.service';

@Component({
  selector: 'app-warehouse-conditioncode',
  templateUrl: './warehouse-conditioncode.component.html',
  styleUrls: ['./warehouse-conditioncode.component.scss']
})
export class WarehouseConditioncodeComponent implements OnInit {

  @ViewChild("girdControl") gird: GridControl;
  gridOption: GridOption;

  isCheckedRemove: boolean = false;

  constructor(
    private messageService: MessageService,
    private authService: AuthService,
    private warehouseCoditioncodeService: WarehouseCoditioncodeService,
    private modalService: NzModalService,
  ) { }

  ngOnInit() {
    this.initGrid();
  }

  initGrid() {
    const warehouses = this.authService.currentUser.warehouses;
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    this.gridOption.addable = true;
    this.gridOption.type = "SERVER";
    this.gridOption.defaultAction = {
      edit: true,
      delete: false,
    }
    this.gridOption.commands = [];
    this.gridOption.onSave = async (item, gridRow) => {
      try {
        item.active = item.active ? item.active : true;
        const newItem = await this.warehouseCoditioncodeService.save(item);
        gridRow.item = newItem;
        this.messageService.success();
        return true;

      } catch (error) {
        this.messageService.handleError(error);
        return false;
      }
    }
    this.gridOption.columnDefs = [
      {
        field: 'whseId',
        headerName: 'Warehouse',
        type: 'SELECT',
        selectData: warehouses.map((e: WarehouseModel) => {
          return {
            label: e.name,
            value: e.code
          };
        }),
        width: 150,
        disabled: true
      }, {
        field: 'storerKey',
        headerName: 'Owner',
        type: 'SELECT',
        width: 150,
        selectData: this.authService.listAllStorer().map(st => {
          return {
            value: st.code,
            label: st.name
          }
        }),
        disabled: true
      },

      { field: 'createdDate', headerName: 'Created Date', type: 'DATE', width: 150 },
      { field: 'updateDate', headerName: 'Update Date', type: 'DATE', width: 150 },
      { field: 'tenantId', headerName: 'Tenant Id', type: 'TEXT', width: 150 },
      { field: 'tenantCode', headerName: 'Tenant Code', type: 'TEXT', width: 150 },
      { field: 'warehouseCode', headerName: 'Warehouse Code', type: 'TEXT', width: 150 },
      { field: 'conditionCode', headerName: 'Condition Code', type: 'TEXT', width: 150 },
      { field: 'plantCode', headerName: 'Plant Code', type: 'TEXT', width: 150 },
      { field: 'storageLocation', headerName: 'Storage Location', type: 'TEXT', width: 150 },
      { field: 'susr01', headerName: 'Susr01', type: 'TEXT', width: 150 },
      { field: 'susr02', headerName: 'Susr02', type: 'TEXT', width: 150 },
      { field: 'susr03', headerName: 'Susr03', type: 'TEXT', width: 150 },
      { field: 'susr04', headerName: 'Susr04', type: 'TEXT', width: 150 },
      { field: 'susr05', headerName: 'Susr05', type: 'TEXT', width: 150 },
      { field: 'susr06', headerName: 'Susr06', type: 'TEXT', width: 150 },
      { field: 'susr07', headerName: 'Susr07', type: 'TEXT', width: 150 },
      { field: 'susr08', headerName: 'Susr08', type: 'TEXT', width: 150 },
      { field: 'susr09', headerName: 'Susr09', type: 'TEXT', width: 150 },
      { field: 'susr10', headerName: 'Susr10', type: 'TEXT', width: 150 },
      { field: 'susr11', headerName: 'Susr11', type: 'TEXT', width: 150 },
      { field: 'susr12', headerName: 'Susr12', type: 'TEXT', width: 150 },
      { field: 'susr13', headerName: 'Susr13', type: 'TEXT', width: 150 },
      { field: 'susr14', headerName: 'Susr14', type: 'TEXT', width: 150 },
      { field: 'susr15', headerName: 'Susr15', type: 'TEXT', width: 150 },
      { field: 'susr16', headerName: 'Susr16', type: 'TEXT', width: 150 },
      { field: 'susr17', headerName: 'Susr17', type: 'TEXT', width: 150 },
      { field: 'susr18', headerName: 'Susr18', type: 'TEXT', width: 150 },
      { field: 'susr19', headerName: 'Susr19', type: 'TEXT', width: 150 },
      { field: 'susr20', headerName: 'Susr20', type: 'TEXT', width: 150 },
      { field: 'notes1', headerName: 'Notes1', type: 'TEXT', width: 150 },
      { field: 'notes2', headerName: 'Notes2', type: 'TEXT', width: 150 },
      { field: 'createdUser', headerName: 'Created User', type: 'TEXT', width: 150 },
      { field: 'updateUser', headerName: 'Update User', type: 'TEXT', width: 150 },
      {
        field: 'active',
        headerName: 'Active',
        type: 'BOOLEAN',
        width: 150
      },
      { field: 'priority', headerName: 'Priority', type: 'NUMBER', width: 150 }
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      return await this.warehouseCoditioncodeService.list(pageRequest);
    }

  }

  async removeMany() {
    const items = this.gird.getItemChecked().map(v => v.item);
    if (items && items.length > 0) {
      this.isCheckedRemove = true;
      this.modalService.confirm({
        nzTitle: `Are you sure delete ${items.length} item?`,
        nzOkText: 'Yes',
        nzOkType: 'primary',
        nzOkDanger: true,
        nzOnOk: async () => {
          return await this.warehouseCoditioncodeService.removeMany({ ids: items.map(v => v.id) })
            .then(() => {
              this.messageService.success();
              this.gird.reload();
              return true;
            })
            .catch((error) => {
              this.messageService.handleError(error);
              return false;
            })
        },
        nzCancelText: 'No',
        nzOnCancel: () => { }
      });
    }
    else {
      return;
    }
  }

}
