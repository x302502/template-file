
import { ModuleRegistry, AllCommunityModules } from '@ag-grid-community/all-modules';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NzI18nService } from 'ng-zorro-antd/i18n';
import { ApiService } from 'src/app/services/common/api.service';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, ISelectDataItem, PageRequest, PageResponse, SelectColDef } from '~/@core/control/grid-control/models';
import { DateUtils } from '~/@core/utils';
import { AuthService } from '~/app/services/auth';
import { MasterDataPartnerSerivce, SkuGroupService } from '~/app/services/business';
import { SkuService } from '~/app/services/business/sku.service';
import { MessageService } from '~/app/services/common/message.service';
import { NzUploadChangeParam } from 'ng-zorro-antd/upload';
import { NzMessageService } from 'ng-zorro-antd/message';

ModuleRegistry.registerModules(AllCommunityModules);

@Component({
  selector: 'app-sku',
  templateUrl: './sku.component.html',
  styleUrls: ['./sku.component.less']
})
export class SkuComponent implements OnInit {
  @ViewChild("girdControl") gird: GridControl;

  constructor(
    private skuGroupService: SkuGroupService,
    private messageService: MessageService,
    private authService: AuthService,
    private skuService: SkuService,
    private masterDataPartnerSerivce: MasterDataPartnerSerivce,
    private msg: NzMessageService
  ) { }
  gridOption: GridOption;

  private listWhareHouse: ISelectDataItem[] = [];

  private listAllStorer: ISelectDataItem[] = [];
  private skuGroups: ISelectDataItem[] = [];

  async ngOnInit() {

    try {
      const res = await this.skuGroupService.list({ pageIndex: 1 })
      this.skuGroups = res.data.map(skuGroup => {
        return {
          value: skuGroup.code,
          label: skuGroup.name
        }
      })
    } catch (error) {

    }

    this.listWhareHouse = this.authService.listWareHouse.map(wh => {
      return {
        label: wh.name,
        value: wh.whseid
      }
    });
    this.listAllStorer = this.authService.listAllStorer().map(st => {
      return {
        value: st.code,
        label: st.name
      }
    })
    this.initGrid();

  }



  initGrid() {
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    this.gridOption.addable = true;
    this.gridOption.type = "SERVER";
    this.gridOption.commands = [
      {
        icon: {
          nzType: 'send',
          nzTheme: 'outline'
        },
        tooltip: 'Sync WMS',
        onClick: async (item, gridRow) => {
          try {
            const res = await this.skuService.syncSWM(item.id);
          }
          catch (error) {
            this.messageService.handleError(error);
          }
        }
      },
    ]
    this.gridOption.onSave = async (item, gridRow) => {
      try {
        const newItem = await this.skuService.save(item);
        gridRow.item = newItem;
        this.messageService.success();
        return true;
      } catch (error) {
        this.messageService.handleError(error);
        return false;
      }
    }

    this.gridOption.columnDefs = [
      {
        field: 'whseId',
        headerName: 'Warehouse',
        type: "SELECT",
        disabled: true,
        selectData: this.listWhareHouse,
      },
      {
        field: 'storerKey',
        headerName: 'Owner',
        type: "SELECT",
        disabled: true,
        selectData: this.listAllStorer,
      },
      {
        field: 'packKey', headerName: 'Pack key', type: "TEXT",
      },
      // {
      //   field: 'groupCode', headerName: 'Group Code', type: "SELECT",
      //   selectData: this.skuGroups,
      //   disabled: true
      // },
      { field: 'groupCode', headerName: 'Group Code', type: "TEXT" },
      {
        field: 'sku', headerName: 'Item Code', type: "TEXT", disabled: true
      },
      { field: 'description', headerName: 'Description', type: "TEXT" },
      { field: 'stdNetWeight', headerName: 'Net Weight', type: "NUMBER" },
      { field: 'stdGrossWeight', headerName: 'Gross Weight', type: "NUMBER" },
      { field: 'stdCube', headerName: 'Cube', type: "NUMBER" },
      {
        field: 'createdDate', headerName: 'Created Date', type: "DATE", disabled: true
      },
      { field: 'updateDate', headerName: 'Update Date', type: "DATE", disabled: true },
      { field: 'wmsSyncStatus', headerName: 'WMS Sync Status', type: "TEXT" },
      { field: 'wmsSyncDate', headerName: 'WMS Sync Date', type: "DATE", disabled: true },
      { field: 'wmsSyncMess', headerName: 'WMS Sync Message', type: "TEXT" },
      { field: 'tmssyncstatus', headerName: 'TMS Message', type: "TEXT" },
      { field: 'notes1', headerName: 'Notes 1', type: "TEXT" },
      { field: 'notes2', headerName: 'Notes 2', type: "TEXT" },
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      return this.skuService.list(pageRequest);
    }
  }

  async fetchData() {
    this.isVisible = true;
  }

  // Modal
  isVisible = false;
  fromdate = null;

  async handleOk() {
    this.isVisible = false;
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getItem(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch(err => {
      this.messageService.handleError(err);
    })

  }

  handleCancel(): void {
    console.log('Button cancel clicked!');
    this.isVisible = false;
  }

  onChange(result: Date): void {
    this.fromdate = result;
  }

  async syncAll() {
    const items = this.gird.getItemChecked().map(v => v.item);
    if (items && items.length > 0) {
      try {
        await this.skuService.syncSkuOmstoSwm(items);
        this.gird.reload();
      } catch (error) {
        this.gird.reload();
        throw error;
      }
    }
  }

  async sendSkuTms() {
    const items = this.gird.getItemChecked().map(v => v.item);
    if (items && items.length > 0) {
      try {
        let ids: string[] = items.map(v => v.id);
        await this.skuService.sendSkuToTms(ids);
        this.gird.reload();
      } catch (error) {
        this.gird.reload();
        throw error;
      }
    }
  }

  handleChange(info: NzUploadChangeParam): void {
    if (info.file.status !== 'uploading') {
      console.log(info.file, info.fileList);
      let reader = new FileReader();
      reader.onload = (e) => {
        console.log(e.target.result);
        try {
          this.skuService.sendContentFileImport(e.target.result as string)
        } catch (error) {
          throw error;
        }
      }
      const content = reader.readAsText(info.file.originFileObj);
    }
    if (info.file.status === 'done') {
      this.msg.success(`${info.file.name} file uploaded successfully`);
    } else if (info.file.status === 'error') {
      this.msg.error(`${info.file.name} file upload failed.`);
    }
    console.log("info::", info.file);

  }

}
