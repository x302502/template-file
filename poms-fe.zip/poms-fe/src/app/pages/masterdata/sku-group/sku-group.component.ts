
import { ModuleRegistry, AllCommunityModules } from '@ag-grid-community/all-modules';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NzI18nService } from 'ng-zorro-antd/i18n';
import { ApiService } from 'src/app/services/common/api.service';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, ISelectDataItem, PageRequest, PageResponse, SelectColDef } from '~/@core/control/grid-control/models';
import { AuthService, WarehouseModel } from '~/app/services/auth';
import { SkuGroupService } from '~/app/services/business';
import { MessageService } from '~/app/services/common/message.service';

@Component({
  selector: 'app-sku-group',
  templateUrl: './sku-group.component.html',
  styleUrls: ['./sku-group.component.less']
})

export class SkuGroupComponent implements OnInit {
  @ViewChild("girdControl") gird: GridControl;

  constructor(
    private i18n: NzI18nService,
    private messageService: MessageService,
    private authService: AuthService,
    private skuGroupService: SkuGroupService,
  ) { }
  gridOption: GridOption;
  ngOnInit() {
    this.initGrid();
  }
  initGrid() {
    const warehouses = this.authService.currentUser.warehouses;
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    this.gridOption.addable = true;
    this.gridOption.type = "SERVER";
    this.gridOption.defaultAction = {
      edit: true,
      delete: false,
    }
    this.gridOption.commands = [
    ]
    this.gridOption.onSave = async (item, gridRow) => {
      try {
        await this.skuGroupService.save(item);
        this.messageService.success()
        return true;

      } catch (error) {
        this.messageService.handleError(error);
        return false;
      }
    }
    this.gridOption.columnDefs = [
      {
        field: 'whseId',
        headerName: 'Warehouse',
        type: 'SELECT',
        selectData: warehouses.map((e: WarehouseModel) => {
          return {
            label: e.name,
            value: e.code
          };
        }),
        width: 150,
        disabled: (skuGroup) => skuGroup.id != null
      }, {
        field: 'storerKey',
        headerName: 'Storer',
        type: 'SELECT',
        width: 150,
        selectData: this.authService.listAllStorer().map(st => {
          return {
            value: st.code,
            label: st.name
          }
        }),
        disabled: (skuGroup) => skuGroup.id != null
      }, {
        field: 'code',
        headerName: 'Code',
        type: 'TEXT',
        width: 150,
        disabled: (skuGroup) => skuGroup.id != null
      }, {
        field: 'name',
        headerName: 'Name',
        type: 'TEXT'
      }
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      return await this.skuGroupService.list(pageRequest);
    }

  }
}
