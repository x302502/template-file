
import { ModuleRegistry, AllCommunityModules, GridOptions } from '@ag-grid-community/all-modules';
import { AgGridAngular } from '@ag-grid-community/angular';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { async } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzModalService } from 'ng-zorro-antd/modal';
import { ApiService } from 'src/app/services/common/api.service';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, PageRequest } from '~/@core/control/grid-control/models';
import { DateUtils } from '~/@core/utils';
import { AuthService, WarehouseModel } from '~/app/services/auth';
import { CustomerService, MasterDataPartnerSerivce, OrdersService } from '~/app/services/business';
import { MessageService } from '~/app/services/common/message.service';

ModuleRegistry.registerModules(AllCommunityModules);

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss']
})
export class OrdersComponent implements OnInit, AfterViewInit {
  @ViewChild("girdControl") gird: GridControl;
  gridOption: GridOption;
  fromdate = new Date();

  currentWarehouse: string = null;
  isWarehouseNandio: string[] = ['HSDN', 'CNHN', 'CNHU', 'CNDN', 'CNHM'];
  isShowButton: Boolean = false;

  constructor(
    private messageService: MessageService,
    private authService: AuthService,
    private ordersService: OrdersService,
    private _router: Router,
    private masterDataPartnerSerivce: MasterDataPartnerSerivce,
    private modalService: NzModalService,
  ) {
    this.currentWarehouse = authService.currentWarehouse.code;
  }
  ngAfterViewInit(): void {

  }

  ngOnInit() {
    this.initGrid();
    this.isShowButton = this.isWarehouseNandio.includes(this.currentWarehouse);
  }
  
  initGrid() {
    const warehouses = this.authService.currentUser.warehouses;
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    this.gridOption.addable = true;
    this.gridOption.type = "SERVER";
    this.gridOption.defaultAction = {
      edit: true,
      delete: !false,
    }
    this.gridOption.commands = [
      {
        icon: {
          nzType: 'send',
          nzTheme: 'outline'
        },
        tooltip: 'Sync WMS',
        onClick: async (item, gridRow) => {
          try {
            const res = await this.ordersService.syncSWM(item.id);
            this.gird.reload();
          }
          catch (error) {
            this.messageService.handleError(error);
          }
        }
      },
      {
        icon: {
          nzType: "info-circle",
          nzTheme: "outline",
          color: "#08c",
          size: "16px"
        },
        tooltip: "Detail",
        onClick: (item, gridRow) => {
          this._router.navigateByUrl(`/main/operation/orderdetail?orderKey=${item.orderKey}`);
        }
      }
    ]
    this.gridOption.onSave = async (item, gridRow) => {
      try {
        const newItem = await this.ordersService.save(item);
        gridRow.item = newItem;
        this.messageService.success()
        return true;

      } catch (error) {
        this.messageService.handleError(error);
        return false;
      }
    }
    this.gridOption.onDelete = async (item, gridRow) => {
      this.modalService.confirm({
        nzTitle: `Are you sure delete orderkey [${item.orderKey}] ?`,
        nzOkText: 'Yes',
        nzOkType: 'primary',
        nzOkDanger: true,
        nzOnOk: async () => {
          await this.ordersService.delete(item)
            .then(() => {
              this.messageService.success();
              this.gird.reload();
              return true;
            })
            .catch((error) => {
              this.messageService.handleError(error);
              return false;
            })
        },
        nzCancelText: 'No',
        nzOnCancel: () => { }
      });
      return false;
    }
    this.gridOption.columnDefs = [
      {
        field: 'whseId',
        headerName: 'Warehouse',
        type: 'SELECT',
        selectData: warehouses.map((e: WarehouseModel) => {
          return {
            label: e.name,
            value: e.code
          };
        }),
        width: 150,
        disabled: (skuGroup) => skuGroup.id != null
      }, {
        field: 'storerKey',
        headerName: 'Storer',
        type: 'SELECT',
        width: 150,
        selectData: this.authService.listAllStorer().map(st => {
          return {
            value: st.code,
            label: st.name
          }
        }),

      },
      {
        field: 'omsType',
        headerName: 'OMS TYPE',
        type: 'SELECT',
        width: 150,
        selectData: [
          {
            value: "ASN",
            label: "ASN"
          },
          {
            value: "MSO",
            label: "MSO"
          },
          {
            value: "SO",
            label: "SO"
          }, {
            value: "PRO",
            label: "PRODUCTION"
          }, {
            value: "STO",
            label: "STO"
          },
          {
            value: "PO",
            label: "PO"
          },
          {
            value: "TO",
            label: "TO"
          },
          {
            value: "TI",
            label: "TI"
          },
          {
            value: "GR",
            label: "GR"
          },
          {
            value: "PR",
            label: "PR"
          },
          {
            value: "SR",
            label: "SR"
          },
          {
            value: "GI",
            label: "GI"
          },
          {
            value: "TS",
            label: "TS"
          },
          {
            value: "GRR",
            label: "GRR"
          },
          {
            value: "RR",
            label: "RR"
          },
          {
            value: "GI",
            label: "GI"
          },
          {
            value: "IT",
            label: "IT"
          },
        ]
      },
      { field: 'status', headerName: 'Status', type: "TEXT" },
      { field: 'susr01', headerName: 'Susr 1', type: "TEXT" },
      { field: 'soldTo', headerName: 'Sold To', type: "TEXT" },
      { field: 'shipTo', headerName: 'Ship To', type: "TEXT" },
      { field: 'customerCode', headerName: 'Customer Code', type: "TEXT" },
      { field: 'supplierCode', headerName: 'Supplier Code', type: "TEXT" },
      { field: 'orderKey', headerName: 'OrderKey', type: "TEXT" },
      { field: 'districtCode', headerName: 'District Code', type: "TEXT" },
      { field: 'externalKey1', headerName: 'External Key 1', type: "TEXT" },
      { field: 'externalKey2', headerName: 'External Key 2', type: "TEXT" },
      { field: 'notes1', headerName: 'Notes 1', type: "TEXT" },
      { field: 'notes2', headerName: 'Notes 2', type: "TEXT" },
      { field: 'createdDate', headerName: 'Created Date', type: "DATE", disabled: true },
      { field: 'updateDate', headerName: 'Update Date', type: "DATE", disabled: true },
      { field: 'wmsSyncStatus', headerName: 'WMS Sync Status', type: "TEXT" },
      { field: 'wmsSyncDate', headerName: 'WMS Sync Date', type: "DATE", disabled: true },
      { field: 'wmsSyncMess', headerName: 'WMS Sync Message', type: "TEXT" },
      { field: 'tmsSyncMess', headerName: 'Tms Sync Message', type: "TEXT" }
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      return await this.ordersService.list(pageRequest);
    }

  }

  //Select date
  onChange(result: Date): void {
    this.fromdate = result;
  }

  // Button fetch data
  async getOrders() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getOrders(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getPurchaseOrder() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getPurchaseOrder(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      console.error(err);
    })
  }

  async getReturnOrder() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getReturnOrder(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getReturnPurChaseOrder() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getReturnPurChaseOrder(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getProductionStandard() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getProductionStandard(pageRequest).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getInventoryTransferProduction() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getInventoryTransferProduction(pageRequest).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getInventoryTransfer() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getInventoryTransfer(pageRequest).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  get isCheckDelete() {
    if (!this.gird || !this.gird.getItemChecked()) {
      return true;
    }
    return this.gird.getItemChecked().length <= 0;
  }

  async deleteOrders() {
    try {
      const orderIds = this.gird.getItemChecked().map(order => order.rowId);
      this.modalService.confirm({
        nzTitle: `Are you sure delete ${orderIds.length} Orders?`,
        nzOkText: 'Yes',
        nzOkType: 'primary',
        nzOkDanger: true,
        nzOnOk: async () => {
          await this.ordersService.removeSelected(orderIds)
            .then(() => {
              this.messageService.success();
              this.gird.reload();
              return true;
            })
            .catch((error) => {
              this.messageService.handleError(error);
              return false;
            })
        },
        nzCancelText: 'No',
        nzOnCancel: () => { }
      });
      return false;
    } catch (error) {
      this.messageService.handleError(error);
      console.error(error);
    }
  }

  async getOtherReceipt() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getOtherReceipt(pageRequest).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getOtherOrder() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getOtherOrder(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getInventoryTransferIn() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getInventoryTransferIn(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getInventoryTransferOut() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getInventoryTransferOut(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getChangeStatus() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getChangeStatus(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getGoodsReceipt() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getGoodsReceipt(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async getGoodsIssue() {
    let pageRequest: PageRequest;
    await this.masterDataPartnerSerivce.getGoodsIssue(pageRequest, DateUtils.formatDate(this.fromdate)).then(() => {
      this.gird.reload();
      this.messageService.success();
    }).catch((err) => {
      this.messageService.handleError(err);
      console.error(err);
    })
  }

  async syncAll() {
    const items = this.gird.getItemChecked().map(v => v.item);
    if (items && items.length > 0) {
      try {
        await this.ordersService.syncAll(items);
        this.gird.reload();
      } catch (error) {
        throw error;
      }
    }
  }

  get isCheckClient() {
    // if (this.authService.clientCode == "TRASAS") {
    //   return true;
    // }
    // else if (this.authService.clientCode == "UMP") {
    //   return true;
    // }
    // else if (this.authService.clientCode == "VFC") {
    //   return true;
    // }
    // else if (this.authService.clientCode == "THIENVIET") {
    //   return true;
    // }
    return this.authService.clientCode;
  }

  async getFiles() {
    await this.ordersService.getFiles();
    this.messageService.success();
  }

  async syncTms() {
    const items = this.gird.getItemChecked().map(v => v.item);
    if (items && items.length > 0) {
      try {
        await this.ordersService.syncTms(items);
        this.gird.reload();
      } catch (error) {
        throw error;
      }
    }
  }

  async getAllOrdersFromSap() {
    try {
      return await this.ordersService.getAllOrdersFromSap({ fromdate: this.fromdate });
    } catch (error) {
      throw error;
    }
  }

  async syncAllStm() {
    const items = this.gird.getItemChecked().map(v => v.item);
    if (items && items.length > 0) {
      try {
        await this.ordersService.syncAllStm(items);
        this.gird.reload();
      } catch (error) {
        throw error;
      }
    }
  }

}
