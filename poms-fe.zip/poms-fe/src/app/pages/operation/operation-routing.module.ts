import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IntegratedlogComponent } from './intergrated-logs/intergratedlog.component';
import { OrderDetailComponent } from './order-detail/order-detail.component';
import { OrdersTmsComponent } from './orders-tms/orders-tms.component';
import { OrdersComponent } from './orders/orders.component';

const routes: Routes = [
    { path: '', component: OrdersComponent },
    { path: 'orders', component: OrdersComponent },
    { path: 'orderdetail', component: OrderDetailComponent },
    { path: 'orderdetail/:orderKey', component: OrderDetailComponent },
    { path: 'list-by-warehouse', component: OrdersTmsComponent },
    { path: 'list-Integratedlog', component: IntegratedlogComponent },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class OperationRoutingModule { }
