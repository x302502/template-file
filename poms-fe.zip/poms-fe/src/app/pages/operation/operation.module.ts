import { AgGridModule } from '@ag-grid-community/angular';
import { NgModule } from '@angular/core';
import { CoreModule } from 'src/@core';
import { ServicesModule } from '~/app/services/services.module';
import { IntegratedlogComponent } from './intergrated-logs/intergratedlog.component';
import { OperationRoutingModule } from './operation-routing.module';
import { OrderDetailComponent } from './order-detail/order-detail.component';
import { OrdersTmsComponent } from './orders-tms/orders-tms.component';
import { OrdersComponent } from './orders/orders.component';

@NgModule({
  imports: [
    OperationRoutingModule,
    CoreModule,
    AgGridModule.withComponents([]),
    ServicesModule,
  ],
  declarations: [
    OrdersComponent,
    OrderDetailComponent,
    OrdersTmsComponent,
    IntegratedlogComponent
  ],
  exports: [
    OrdersComponent,
    OrderDetailComponent,
    OrdersTmsComponent,
    IntegratedlogComponent
  ],
  providers: []
})
export class OperationModule { }
