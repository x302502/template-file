import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NzModalService } from 'ng-zorro-antd/modal';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, PageRequest } from '~/@core/control/grid-control/models';
import { AuthService, WarehouseModel } from '~/app/services/auth';
import { OrderDetailService, OrdersService } from '~/app/services/business';
import { MessageService } from '~/app/services/common/message.service';

@Component({
  selector: 'app-order-detail',
  templateUrl: './order-detail.component.html',
  styleUrls: ['./order-detail.component.scss']
})
export class OrderDetailComponent implements OnInit {
  @ViewChild("girdControl") gird: GridControl;
  gridOption: GridOption;
  public orderkey: string;
  constructor(
    private messageService: MessageService,
    private authService: AuthService,
    private ordersService: OrdersService,
    private orderDetailService: OrderDetailService,
    private modalService: NzModalService,
    private activatedRoute: ActivatedRoute
  ) {
    this.activatedRoute.queryParams.subscribe(params => {
      this.orderkey = params['orderKey'];
    })
  }

  ngOnInit(): void {
    this.initGrid();
  }

  initGrid() {
    const warehouses = this.authService.currentUser.warehouses;
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    this.gridOption.addable = true;
    this.gridOption.type = "SERVER";
    // this.gridOption.defaultAction = {
    //   edit: true,
    //   delete: false,
    // }
    this.gridOption.commands = [
    ]
    this.gridOption.onSave = async (item, gridRow) => {
      try {
        const newItem = await this.orderDetailService.save(item);
        gridRow.item = newItem;
        this.messageService.success()
        return true;

      } catch (error) {
        this.messageService.handleError(error);
        return false;
      }
    }
    this.gridOption.onDelete = async (item, gridRow) => {
      this.modalService.confirm({
        nzTitle: 'Are you sure delete item ?',
        nzOkText: 'Yes',
        nzOkType: 'primary',
        nzOkDanger: true,
        nzOnOk: async () => {
          await this.orderDetailService.delete(item)
            .then(() => {
              this.messageService.success();
              this.gird.reload();
              return true;
            })
            .catch((error) => {
              this.messageService.handleError(error);
              return false;
            })
        },
        nzCancelText: 'No',
        nzOnCancel: () => console.log('Cancel')
      });
      return false;
    }
    this.gridOption.columnDefs = [
      {
        field: 'whseId',
        headerName: 'WAREHOUSE',
        type: 'SELECT',
        selectData: warehouses.map((e: WarehouseModel) => {
          return {
            label: e.name,
            value: e.code
          };
        }),
        width: 150,
        disabled: (skuGroup) => skuGroup.id != null
      }, {
        field: 'storerKey',
        headerName: 'OWNER',
        type: 'SELECT',
        width: 150,
        selectData: this.authService.listAllStorer().map(st => {
          return {
            value: st.code,
            label: st.name
          }
        }),
        disabled: (skuGroup) => skuGroup.id != null
      },
      { field: 'soldTo', headerName: 'SOLDTO', type: "TEXT" },
      { field: 'shipTo', headerName: 'SHIPTO', type: "TEXT" },
      { field: 'customerCode', headerName: 'CUSTOMER CODE', type: "TEXT" },
      { field: 'supplierCode', headerName: 'SUPPLIER CODE', type: "TEXT" },
      { field: 'carrierCode', headerName: 'CARRIER CODE', type: "TEXT" },
      { field: 'orderKey', headerName: 'ORDERKEY', type: "TEXT" },
      { field: 'omsType', headerName: 'OMS TYPE', type: "TEXT" },
      { field: 'externalKey1', headerName: 'EXTERNALKEY1', type: "TEXT" },
      { field: 'externalKey2', headerName: 'EXTERNALKEY2', type: "TEXT" },
      { field: 'priority', headerName: 'PRIORITY', type: "TEXT" },
      { field: 'gate', headerName: 'GATE', type: "TEXT" },
      { field: 'door', headerName: 'DOOR', type: "TEXT" },
      { field: 'traillerNumber', headerName: 'TRAILLER NUMBER', type: "TEXT" },
      { field: 'driverName', headerName: 'DRIVER NAME', type: "TEXT" },
      { field: 'phoneNumber', headerName: 'PHONE NUMBER', type: "TEXT" },

      { field: 'orderDate', headerName: 'ORDER DATE', type: "DATE" },
      { field: 'beginTime', headerName: 'BEGIN TIME', type: "DATE" },
      { field: 'endTime', headerName: 'END TIME', type: "DATE" },
      { field: 'requestShipDate', headerName: 'REQUESTSHIPDATE', type: "DATE" },
      { field: 'actualShipDate', headerName: 'ACTUALSHIPDATE', type: "DATE" },
      { field: 'deliveryDate', headerName: 'DELIVERYDATE', type: "DATE" },
      { field: 'expectedReceiptDate', headerName: 'EXPECTEDRECEIPTDATE', type: "DATE" },
      { field: 'receiptDate', headerName: 'RECEIPTDATE', type: "DATE" },

      { field: 'status', headerName: 'STATUS', type: "TEXT" },
      { field: 'type', headerName: 'TYPE', type: "TEXT" },
      { field: 'susr01', headerName: 'SUSR01', type: "TEXT" },
      { field: 'susr02', headerName: 'SUSR02', type: "TEXT" },
      { field: 'susr03', headerName: 'SUSR03', type: "TEXT" },
      { field: 'susr04', headerName: 'SUSR04', type: "TEXT" },
      { field: 'susr05', headerName: 'SUSR05', type: "TEXT" },
      { field: 'susr06', headerName: 'SUSR06', type: "TEXT" },
      { field: 'susr07', headerName: 'SUSR07', type: "TEXT" },
      { field: 'susr08', headerName: 'SUSR08', type: "TEXT" },
      { field: 'susr09', headerName: 'SUSR09', type: "TEXT" },
      { field: 'susr10', headerName: 'SUSR10', type: "TEXT" },
      { field: 'susr11', headerName: 'SUSR11', type: "TEXT" },
      { field: 'susr12', headerName: 'SUSR12', type: "TEXT" },
      { field: 'susr13', headerName: 'SUSR13', type: "TEXT" },
      { field: 'susr14', headerName: 'SUSR14', type: "TEXT" },
      { field: 'susr15', headerName: 'SUSR15', type: "TEXT" },
      { field: 'susr16', headerName: 'SUSR16', type: "TEXT" },
      { field: 'susr17', headerName: 'SUSR17', type: "TEXT" },
      { field: 'susr18', headerName: 'SUSR18', type: "TEXT" },
      { field: 'susr19', headerName: 'SUSR19', type: "TEXT" },
      { field: 'susr20', headerName: 'SUSR20', type: "TEXT" },
      { field: 'notes1', headerName: 'NOTES1', type: "TEXT" },
      { field: 'notes2', headerName: 'NOTES2', type: "TEXT" },
      { field: 'createdUser', headerName: 'CREATED USER', type: "TEXT" },
      { field: 'updateUser', headerName: 'UPDATE USER', type: "TEXT" },

      { field: 'orderId', headerName: 'ORDERID', type: "TEXT" },
      { field: 'orderLineNumber', headerName: 'ORDERLINENUMBER', type: "TEXT" },
      { field: 'externLineNumber', headerName: 'EXTERNLINENUMBER', type: "TEXT" },
      { field: 'skuId', headerName: 'SKUID', type: "TEXT" },
      { field: 'sku', headerName: 'SKU', type: "TEXT" },

      { field: 'originalQty', headerName: 'ORIGINALQTY', type: "NUMBER" },
      { field: 'preAllocateQty', headerName: 'PREALLOCATEQTY', type: "NUMBER" },
      { field: 'allocateQty', headerName: 'ALLOCATEQTY', type: "NUMBER" },
      { field: 'pickedQty', headerName: 'PICKEDQTY', type: "NUMBER" },
      { field: 'shippedQty', headerName: 'SHIPPEDQTY', type: "NUMBER" },
      { field: 'grossWeight', headerName: 'GROSSWEIGHT', type: "NUMBER" },
      { field: 'netWeight', headerName: 'NETWEIGHT', type: "NUMBER" },
      { field: 'cube', headerName: 'CUBE', type: "NUMBER" },

      { field: 'conditionCode', headerName: 'CONDITIONCODE', type: "TEXT" },
      { field: 'lpnid', headerName: 'LPNID', type: "TEXT" },
      { field: 'uom', headerName: 'UOM', type: "TEXT" },
      { field: 'packKey', headerName: 'CONDITIONCODE', type: "TEXT" },

      { field: 'lottable01', headerName: 'LOTTABLE01', type: "TEXT" },
      { field: 'lottable02', headerName: 'LOTTABLE02', type: "TEXT" },
      { field: 'lottable03', headerName: 'LOTTABLE03', type: "TEXT" },
      { field: 'lottable04', headerName: 'LOTTABLE04', type: "DATE" },
      { field: 'lottable05', headerName: 'LOTTABLE05', type: "DATE" },
      { field: 'lottable06', headerName: 'LOTTABLE06', type: "TEXT" },
      { field: 'lottable07', headerName: 'LOTTABLE07', type: "TEXT" },
      { field: 'lottable08', headerName: 'LOTTABLE08', type: "TEXT" },
      { field: 'lottable09', headerName: 'LOTTABLE09', type: "TEXT" },
      { field: 'lottable10', headerName: 'LOTTABLE10', type: "TEXT" },
      { field: 'lottable11', headerName: 'LOTTABLE11', type: "DATE" },
      { field: 'lottable12', headerName: 'LOTTABLE12', type: "DATE" },

      { field: 'createdDate', headerName: 'CREATED DATE', type: "DATE", disabled: true },
      { field: 'updateDate', headerName: 'UPDATE DATE', type: "DATE", disabled: true }
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      const customPageRequest = this.orderkey ? { ...pageRequest, orderKey: this.orderkey } : pageRequest;
      return await this.orderDetailService.list(customPageRequest);
    }

  }

}
