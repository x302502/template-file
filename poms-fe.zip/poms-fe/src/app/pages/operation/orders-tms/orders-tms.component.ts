
import { ModuleRegistry, AllCommunityModules, GridOptions } from '@ag-grid-community/all-modules';
import { AgGridAngular } from '@ag-grid-community/angular';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { async } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzModalService } from 'ng-zorro-antd/modal';
import { ApiService } from 'src/app/services/common/api.service';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, PageRequest } from '~/@core/control/grid-control/models';
import { DateUtils } from '~/@core/utils';
import { AuthService, WarehouseModel } from '~/app/services/auth';
import { CustomerService, LoggerService, MasterDataPartnerSerivce, OrdersService } from '~/app/services/business';
import { MessageService } from '~/app/services/common/message.service';

ModuleRegistry.registerModules(AllCommunityModules);

@Component({
  selector: 'app-orders-tns',
  templateUrl: './orders-tms.component.html',
  styleUrls: ['./orders-tms.component.scss']
})
export class OrdersTmsComponent implements OnInit, AfterViewInit {
  @ViewChild("girdControl") gird: GridControl;
  constructor(
    private messageService: MessageService,
    private authService: AuthService,
    private ordersService: OrdersService,
    private _router: Router,
    private masterDataPartnerSerivce: MasterDataPartnerSerivce,
    private modalService: NzModalService,
    private loggerService: LoggerService,
  ) { }
  ngAfterViewInit(): void {

  }
  gridOption: GridOption;

  ngOnInit() {
    this.initGrid();
  }
  initGrid() {
    const warehouses = this.authService.currentUser.warehouses;
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    // this.gridOption.addable = true;
    this.gridOption.type = "SERVER";
    this.gridOption.defaultAction = {
      edit: true
    }
    this.gridOption.onSave = async (item, gridRow) => {
      try {
        const newItem = await this.loggerService.save(item);
        gridRow.item = newItem;
        this.messageService.success()
        return true;

      } catch (error) {
        this.messageService.handleError(error);
        return false;
      }
    }

    this.gridOption.columnDefs = [
      {
        field: 'whseId',
        headerName: 'Warehouse',
        type: 'SELECT',
        selectData: warehouses.map((e: WarehouseModel) => {
          return {
            label: e.name,
            value: e.code
          };
        }),
        width: 150,
        disabled: (item) => item.id != null
      },
      { field: 'clientCode', headerName: 'Client Code', type: "TEXT", disabled: true },
      { field: 'method', headerName: 'Method', type: "TEXT", disabled: true },
      { field: 'endpoint', headerName: 'Endpoint', type: "TEXT", disabled: true },
      { field: 'headers', headerName: 'Headers', type: "TEXT", disabled: true },
      { field: 'params', headerName: 'Params', type: "TEXT" },
      { field: 'body', headerName: 'Body', type: "TEXT" },
      { field: 'results', headerName: 'Results', type: "TEXT" },
      { field: 'status', headerName: 'Status', type: "BOOLEAN" },
      { field: 'apiName', headerName: 'Api Name', type: "TEXT", disabled: true},
      { field: 'createdUser', headerName: 'Created User', type: "TEXT", disabled: true },
      { field: 'createdDate', headerName: 'Created Date', type: "DATETIME" },
      { field: 'updateDate', headerName: 'Update Date', type: "DATETIME"},
      { field: 'notes', headerName: 'Notes', type: "TEXT"},
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      return await this.loggerService.listAll(pageRequest);
    }

  }

  get isCheckDelete() {
    if (!this.gird || !this.gird.getItemChecked()) {
      return true;
    }
    return this.gird.getItemChecked().length <= 0;
  }
}
