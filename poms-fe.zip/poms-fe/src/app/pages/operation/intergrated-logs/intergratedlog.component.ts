
import { ModuleRegistry, AllCommunityModules, GridOptions } from '@ag-grid-community/all-modules';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { async } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { NzModalService } from 'ng-zorro-antd/modal';
import { ApiService } from 'src/app/services/common/api.service';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, PageRequest } from '~/@core/control/grid-control/models';
import { DateUtils } from '~/@core/utils';
import { AuthService, WarehouseModel } from '~/app/services/auth';
import { IntegratedlogsService, LoggerService, MasterDataPartnerSerivce, OrdersService } from '~/app/services/business';
import { MessageService } from '~/app/services/common/message.service';
import { DomSanitizer } from '@angular/platform-browser';

ModuleRegistry.registerModules(AllCommunityModules);

@Component({
    selector: 'app-intergratedlog',
    templateUrl: './intergratedlog.component.html',
    styleUrls: ['./intergratedlog.component.scss']
})
export class IntegratedlogComponent implements OnInit, AfterViewInit {
    @ViewChild("girdControl") gird: GridControl;
    constructor(
        private messageService: MessageService,
        private authService: AuthService,
        private ordersService: OrdersService,
        private _router: Router,
        private masterDataPartnerSerivce: MasterDataPartnerSerivce,
        private modalService: NzModalService,
        private loggerService: LoggerService,
        private integratedlogsService: IntegratedlogsService,
        private sanitizer: DomSanitizer
    ) { }
    ngAfterViewInit(): void {

    }
    gridOption: GridOption;

    ngOnInit() {
        this.initGrid();
    }
    initGrid() {
        const warehouses = this.authService.currentUser.warehouses;
        this.gridOption = new GridOption();
        this.gridOption.primaryKeyColumns = ['id']
        // this.gridOption.addable = true;
        this.gridOption.type = "SERVER";
        this.gridOption.defaultAction = {
            edit: true
        }
        this.gridOption.commands = [
            {
                icon: {
                    nzType: 'download',
                    nzTheme: 'outline'
                },
                tooltip: 'Download',
                onClick: async (item) => {
                    try {
                        let text = await this.integratedlogsService.download({ filename: item.filename });
                        if (text) {
                            let data = new Blob([text], { type: 'text/plain' });
                            const url = window.URL.createObjectURL(data);
                            let a = document.createElement('a');
                            document.body.appendChild(a);
                            a.setAttribute('style', 'display: none');
                            a.href = url;
                            a.download = item.filename;
                            a.click();
                            a.remove();
                        }
                    }
                    catch (error) {
                        this.messageService.handleError(error);
                    }
                },
                disabled: (item) => !item.filename
            }
        ]
        this.gridOption.columnDefs = [
            {
                field: 'whseId',
                headerName: 'Warehouse',
                type: 'SELECT',
                selectData: warehouses.map((e: WarehouseModel) => {
                    return {
                        label: e.name,
                        value: e.code
                    };
                }),
                width: 150,
                disabled: (item) => item.id != null
            },
            { field: 'clientCode', headerName: 'Client Code', type: "TEXT", disabled: true },
            { field: 'externalKey', headerName: 'External Key', type: "TEXT", disabled: true },
            { field: 'endpoint', headerName: 'Endpoint', type: "TEXT", disabled: true },
            { field: 'bodyIn', headerName: 'Body In', type: "TEXT" },
            { field: 'bodyOut', headerName: 'Body Out', type: "TEXT" },
            { field: 'results', headerName: 'Results', type: "TEXT" },
            { field: 'status', headerName: 'Status', type: "BOOLEAN" },
            { field: 'data', headerName: 'Type', type: "TEXT", disabled: true },
            { field: 'filename', headerName: 'File name', type: "TEXT", disabled: true },
            { field: 'type', headerName: 'Type', type: "TEXT", disabled: true },
            { field: 'createdUser', headerName: 'Created User', type: "TEXT", disabled: true },
            { field: 'createdDate', headerName: 'Created Date', type: "DATETIME" },
            { field: 'method', headerName: 'Method', type: "TEXT" },

        ]

        this.gridOption.loadData = async (pageRequest: PageRequest) => {
            if (this.authService.currentUser.clientCode == "THIENLONG") {
                return await this.integratedlogsService.listAll(pageRequest);
            }
            else {
                return await this.integratedlogsService.list(pageRequest);
            }
        }

    }

    get isCheckDelete() {
        if (!this.gird || !this.gird.getItemChecked()) {
            return true;
        }
        return this.gird.getItemChecked().length <= 0;
    }

    async syncAll() {
        const items = this.gird.getItemChecked().map(v => v.item);
        if (items && items.length > 0) {
            try {
                await this.integratedlogsService.syncAll(items);
                this.gird.reload();
            } catch (error) {
                throw error;
            }
        }
    }
}
