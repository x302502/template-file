
import { ModuleRegistry, AllCommunityModules, GridOptions } from '@ag-grid-community/all-modules';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NzModalService } from 'ng-zorro-antd/modal';
import { ApiService } from 'src/app/services/common/api.service';
import { GridControl } from '~/@core/control/grid-control/grid.control';
import { GridOption, PageRequest } from '~/@core/control/grid-control/models';
import { AuthService, WarehouseModel } from '~/app/services/auth';
import { WarehouseCoditioncodeService } from '~/app/services/business';
import { MessageService } from '~/app/services/common/message.service';

ModuleRegistry.registerModules(AllCommunityModules);

@Component({
  selector: 'app-warehouse-setting',
  templateUrl: './warehouse-setting.component.html',
  styleUrls: ['./warehouse-setting.component.scss']
})
export class WarehouseSettingComponent implements OnInit, AfterViewInit {
  @ViewChild("girdControl") gird: GridControl;
  constructor(
    private messageService: MessageService,
    private authService: AuthService,
    private _router: Router,
    private modalService: NzModalService,
    private warehouseCoditioncodeService: WarehouseCoditioncodeService,
  ) { }
  ngAfterViewInit(): void {

  }
  gridOption: GridOption;

  ngOnInit() {
    this.initGrid();
    console.log('===================');
    console.log("ok");
    console.log('===================');

  }

  initGrid() {
    const warehouses = this.authService.currentUser.warehouses;
    this.gridOption = new GridOption();
    this.gridOption.primaryKeyColumns = ['id']
    this.gridOption.addable = true;
    this.gridOption.type = "SERVER";
    this.gridOption.defaultAction = {
      edit: true,
      delete: !false,
    }
    // this.gridOption.commands = [];
    this.gridOption.onSave = async (item, gridRow) => {
      if (!item.whseId) {
        this.messageService.warning("Warehouse code required");
        return false;
      }
      if (!item.storerKey) {
        this.messageService.warning("owner code required");
        return false;
      }
      if (!item.plantCode) {
        this.messageService.warning("Plant code required");
        return false;
      }

      try {
        item.warehouseCode = item.warehouseCode ? item.warehouseCode : "";
        item.conditionCode = item.conditionCode ? item.conditionCode : "";
        item.storageLocation = item.storageLocation ? item.storageLocation : "";
        item.plantCode = item.plantCode ? item.plantCode.trim() : "";
        item.active = item.active ? item.active : false;
        let newItem = await this.warehouseCoditioncodeService.save(item);
        gridRow.item = newItem;
        this.messageService.success();
        this.gird.reload();
        return true;
      } catch (error) {
        this.messageService.error("Có lỗi xảy ra");
      }

    }
    this.gridOption.onDelete = async (item, gridRow) => {
      this.modalService.confirm({
        nzTitle: `Are you sure delete item?`,
        nzOkText: 'Yes',
        nzOkType: 'primary',
        nzOkDanger: true,
        nzOnOk: async () => {
          await this.warehouseCoditioncodeService.delete({ id: item.id })
            .then(() => {
              this.messageService.success();
              this.gird.reload();
              return true;
            })
            .catch((error) => {
              this.messageService.handleError(error);
              return false;
            })
        },
        nzCancelText: 'No',
        nzOnCancel: () => { }
      });
      return false;
    }
    this.gridOption.columnDefs = [
      {
        field: 'whseId',
        headerName: 'Warehouse',
        type: 'SELECT',
        selectData: warehouses.map((e: WarehouseModel) => {
          return {
            label: e.name,
            value: e.code
          };
        }),
        width: 150,
        disabled: (skuGroup) => skuGroup.id != null
      }, {
        field: 'storerKey',
        headerName: 'Owner',
        type: 'SELECT',
        width: 150,
        selectData: this.authService.listAllStorer().map(st => {
          return {
            value: st.code,
            label: st.name
          }
        }),
      },
      { field: 'warehouseCode', headerName: 'Warehouse Code', type: "TEXT" },
      { field: 'plantCode', headerName: 'Plant Code', type: "TEXT" },
      { field: 'active', headerName: 'Active', type: "BOOLEAN" },
      { field: 'notes1', headerName: 'Notes', type: "TEXT" },
      { field: 'createdDate', headerName: 'Created Date', type: "DATE", disabled: true }
    ]

    this.gridOption.loadData = async (pageRequest: PageRequest) => {
      return await this.warehouseCoditioncodeService.list(pageRequest);
    }

  }

}
