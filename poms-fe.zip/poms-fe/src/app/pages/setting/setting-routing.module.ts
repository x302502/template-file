import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WarehouseSettingComponent } from './warehouse-setting/warehouse-setting.component';

const routes: Routes = [
    { path: '', component: WarehouseSettingComponent },
    { path: 'warehouse-setting', component: WarehouseSettingComponent },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SettingeRoutingModule { }
