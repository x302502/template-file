import { AgGridModule } from '@ag-grid-community/angular';
import { NgModule } from '@angular/core';
import { CoreModule } from 'src/@core';
import { ServicesModule } from '~/app/services/services.module';
import { SettingeRoutingModule } from './setting-routing.module';
import { WarehouseSettingComponent } from './warehouse-setting/warehouse-setting.component';

@NgModule({
  imports: [
    SettingeRoutingModule,
    CoreModule,
    AgGridModule.withComponents([]),
    ServicesModule,
  ],
  declarations: [
    WarehouseSettingComponent
  ],
  exports: [
    WarehouseSettingComponent
  ],
  providers: []
})
export class SettingModule { }
