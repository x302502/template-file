import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { IsEmail, IsEthereumAddress, IsNotEmpty } from "class-validator";
import { PageRequest } from "~/@systems/utils";
import { ENftTier, EUserTier } from "~/common/enums";



export class WalletAddressReq {
    @ApiProperty()
    @IsEthereumAddress()
    walletAddress: string;

}



export class UpdateUserProfileReq extends WalletAddressReq {

    @ApiProperty()
    @IsNotEmpty()
    @IsEmail()
    email: string;

    @ApiProperty()
    @IsNotEmpty()
    fullName: string;

}


export class SpecialOfferReq {
    @ApiPropertyOptional()
    walletAddress?: string;
}


export class ListOfferBySearchTypeReq {
    @ApiPropertyOptional()
    walletAddress?: string;

    @ApiProperty()
    @IsNotEmpty()
    searchType: "YOUR_OFFER" | "ALL" | "COMMING" = "ALL";
}


export class ScanWidReq {

    @ApiProperty()
    @IsNotEmpty()
    programCode: string;

    @ApiProperty()
    @IsNotEmpty()
    apiKey: string;

    @ApiProperty()
    @IsNotEmpty()
    storeCode: string;

    @ApiProperty()
    @IsNotEmpty()
    wid: string;
}

export class ListMerchantTierByUserReq extends PageRequest {
    @ApiProperty()
    @IsEthereumAddress()
    walletAddress: string;
}