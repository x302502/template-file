import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger"
import { IsEmail, IsEthereumAddress, IsNotEmpty, IsUUID } from "class-validator"
import { PageRequest } from "~/@systems/utils"
import { EMerchantStatus, EGender, ENftTier, EUserAdminStatus, EUserTier } from "~/common/enums"
import { EMerchantType } from "~/common/enums/EMerchantType"
import { EProgramStatus } from "~/common/enums/EProgramStatus"
import { MerchantTier, Program } from "~/entities/primary"





export class BrandLoginReq {
    @ApiProperty()
    @IsNotEmpty()
    @IsEmail()
    email: string

    @ApiProperty()
    @IsNotEmpty()
    password: string
}

export class BrandRegisterReq {

    @ApiProperty()
    @IsNotEmpty()
    @IsEmail()
    email: string

    @ApiProperty()
    @IsNotEmpty()
    password: string

    @ApiProperty()
    @IsNotEmpty()
    name: string;

    @ApiProperty({ description: "Company Name" })
    @IsNotEmpty()
    companyName: string;

    @ApiPropertyOptional()
    logo?: string;

    @ApiPropertyOptional()
    banner?: string;

    @ApiPropertyOptional()
    @IsNotEmpty()
    website: string;

    @ApiPropertyOptional()
    type: EMerchantType;

    @ApiPropertyOptional()
    countryCode: string;

    @ApiPropertyOptional()
    cityCode: string;

    @ApiPropertyOptional()
    store?: number;

    @ApiPropertyOptional()
    industry?: string;

    @ApiPropertyOptional()
    aboutUs?: string;

    @ApiPropertyOptional()
    addressId?: string;
}

export class UpdateMerchantReq {
    @ApiProperty()
    @IsNotEmpty()
    @IsEmail()
    email: string

    @ApiProperty()
    @IsNotEmpty()
    name: string;

    @ApiProperty({ description: "Company Name" })
    @IsNotEmpty()
    companyName: string;

    @ApiPropertyOptional()
    logo?: string;

    @ApiPropertyOptional()
    banner?: string;

    @ApiPropertyOptional()
    @IsNotEmpty()
    website: string;

    @ApiPropertyOptional()
    type: EMerchantType;

    @ApiPropertyOptional()
    countryCode: string;

    @ApiPropertyOptional()
    cityCode: string;

    @ApiPropertyOptional()
    store?: number;

    @ApiPropertyOptional()
    industry?: string;

    @ApiPropertyOptional()
    aboutUs?: string;

    @ApiPropertyOptional()
    addressId?: string;
}

export class BrandSessionDto {
    @ApiProperty()
    id: string

    @ApiProperty()
    email: string;

    @ApiProperty()
    password: string;

    @ApiProperty()
    name: string;

    @ApiProperty()
    companyName: string;

    @ApiPropertyOptional()
    status: EMerchantStatus;

    @ApiPropertyOptional()
    logo?: string;

    @ApiPropertyOptional()
    website?: string;

    @ApiProperty()
    createdDate: Date;

    @ApiProperty()
    accessToken: string;

}

export class CreateApiKeyReq {
    @ApiProperty()
    @IsNotEmpty()
    keyName: string;
}



export class CreateStoreReq {
    @ApiProperty()
    @IsNotEmpty()
    name: string;

    @ApiProperty()
    @IsNotEmpty()
    storeCode: string;

    @ApiPropertyOptional()
    address?: string;

    @ApiPropertyOptional()
    countryCode: string;

    @ApiPropertyOptional()
    cityCode: string;
}

export class UpdateStoreReq extends CreateStoreReq {

    @ApiProperty()
    @IsNotEmpty()
    @IsUUID('4')
    id: string;
}

export class ListApiKeyReq extends PageRequest {

}

export class ListApiKeyByBrandReq extends ListApiKeyReq {
    @ApiProperty()
    @IsNotEmpty()
    @IsUUID('4')
    merchantId: string;
}

export class ListBrandReq extends PageRequest {
}


export class ListStoreReq extends PageRequest {

}

export class ListStoreByMerchantReq extends ListStoreReq {
    @ApiProperty()
    @IsNotEmpty()
    @IsUUID('4')
    merchantId: string;
}

export class ListProgramReq extends PageRequest {

}

export class ListProgramByBrandReq extends PageRequest {
    @ApiProperty()
    @IsNotEmpty()
    @IsUUID('4')
    merchantId: string;
}

export class ListStoreApplyProgramReq extends PageRequest {
    @ApiProperty()
    @IsNotEmpty()
    @IsUUID('4')
    programId: string;
}



export class CreateProgramReq {
    @ApiProperty()
    name: string;

    @ApiPropertyOptional()
    programType?: string;

    @ApiPropertyOptional()
    title?: string;

    @ApiPropertyOptional()
    startTime: Date;

    @ApiPropertyOptional()
    endTime: Date;

    @ApiPropertyOptional()
    w3wTiers: EUserTier[] = [];

    @ApiPropertyOptional()
    merchantTiers: string[] = [];

    @ApiPropertyOptional()
    banner?: string;

    @ApiPropertyOptional()
    desc?: string;

    @ApiPropertyOptional()
    type?: number;
}

export class UpdateProgramReq extends CreateProgramReq {
    @ApiProperty()
    @IsNotEmpty()
    @IsUUID('4')
    id: string;
}

export class ApplyStoreInProgramReq {
    @ApiProperty()
    @IsNotEmpty()
    @IsUUID('4')
    programId: string;


    @ApiProperty()
    storeIds: string[];
}

export class ListTransactionReq extends PageRequest {
    @ApiProperty()
    id: string;
}

export class CreateCampaignReq {
    @ApiProperty()
    name: string;

    @ApiProperty()
    programType: string;

    @ApiPropertyOptional()
    countryCode: string;

    @ApiPropertyOptional()
    cityCode: string;

    @ApiProperty()
    w3wTiers: EUserTier[] = [];

    @ApiProperty()
    merchantTiers: string[] = [];

    @ApiPropertyOptional()
    banner: string;

    @ApiPropertyOptional()
    logo: string;

    @ApiPropertyOptional()
    cover: string;

    @ApiPropertyOptional()
    aboutCampaign: string;

    @ApiPropertyOptional()
    forMerchant: string;

    @ApiPropertyOptional()
    showForMerchant: boolean;

    @ApiProperty()
    startTime: Date;

    @ApiProperty()
    endTime: Date;

    @ApiProperty()
    program: Program[];

    @ApiPropertyOptional()
    status: EProgramStatus;
}

export class UpdateCampaignReq extends CreateCampaignReq {
    @ApiProperty()
    @IsNotEmpty()
    @IsUUID('4')
    id: string;
}

export class ListStoreApplyCampaignReq extends PageRequest {
    @ApiProperty()
    @IsNotEmpty()
    @IsUUID('4')
    campaignId: string;
}

export class ListMerchantReq extends PageRequest {
    @ApiProperty()
    type: string;
}


export class ListTransactionByUserReq extends PageRequest {
    @ApiProperty()
    @IsEthereumAddress()
    walletAddress: string;
}

export class ForgotPasswordReq {
    @ApiProperty()
    @IsNotEmpty()
    @IsEmail()
    email: string
}

export class ForgotPasswordDto {
    @ApiProperty()
    @IsNotEmpty()
    @IsEmail()
    email: string

    @ApiProperty()
    @IsNotEmpty()
    password: string

    @ApiProperty()
    @IsNotEmpty()
    verifyCode: number
}