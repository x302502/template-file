import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { IsEthereumAddress } from "class-validator";
import { IsNumber } from "~/@core/decorator/validate.decorator";
import { PageRequest } from "~/@systems/utils";
import { ENftType } from "~/common/enums/ENftType";



export class Metadata {
    @ApiPropertyOptional()
    image?: string;

    @ApiPropertyOptional()
    name?: string;

    @ApiPropertyOptional()
    description?: string;

    [key: string]: string
}

export class NftByAddress {

    @ApiProperty()
    chainId: number;

    @ApiProperty()
    @IsEthereumAddress()
    address: string;

    @ApiProperty()
    tokenId: string;

    @ApiProperty()
    @IsEthereumAddress()
    owner: string;

    @ApiProperty()
    amount: number;

    @ApiProperty({ enum: ENftType })
    contractType: ENftType;


    @ApiProperty()
    name: string;

    @ApiPropertyOptional()
    symbol?: string;

    @ApiPropertyOptional()
    tokenUri?: string;

    @ApiPropertyOptional()
    metadata?: Metadata;
}






export class ListNftReq extends PageRequest {

    @ApiProperty()
    @IsEthereumAddress()
    walletAddress: string;
}

export class CheckPriceReq {

    @ApiProperty()
    @IsNumber()
    chainId: number;


    @ApiProperty()
    @IsEthereumAddress()
    address: string;

}