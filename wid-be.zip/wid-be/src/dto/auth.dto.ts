import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger"
import { IsNotEmpty } from "class-validator"
import { EGender, EUserAdminStatus } from "~/common/enums"





export class LoginReq {
    @ApiProperty()
    @IsNotEmpty()
    username: string

    @ApiProperty()
    @IsNotEmpty()
    password: string
}

export class RegisterReq {

    @ApiProperty()
    @IsNotEmpty()
    username: string

    @ApiProperty()
    @IsNotEmpty()
    password: string

    @ApiPropertyOptional()
    gender?: EGender;

    @ApiPropertyOptional()
    avatar?: string
}

export class UserSessionDto {
    @ApiProperty()
    id: string
    @ApiProperty()
    username: string;


    @ApiProperty()
    status: EUserAdminStatus;

    @ApiPropertyOptional()
    gender?: EGender;

    @ApiPropertyOptional()
    avatar?: string;

    @ApiProperty()
    accessToken: string;
}
