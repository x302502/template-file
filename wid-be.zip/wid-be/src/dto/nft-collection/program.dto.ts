import { PageRequest } from "~/@systems/utils";

export class NftCollectionDto extends PageRequest {

}