import { ApiPropertyOptional } from '@nestjs/swagger';


export class VerifyEmailReq {
    @ApiPropertyOptional()
    email: string;

    @ApiPropertyOptional({ nullable: true })
    verifyCode: number;
}

export class SendEmailReq {
    @ApiPropertyOptional()
    email: string;
}