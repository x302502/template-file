import { ApiPropertyOptional } from "@nestjs/swagger";
import { PageRequest } from "~/@systems/utils";

export class ListCampaignReq extends PageRequest {
}

export class ListMerchantCampaignReq extends PageRequest {
    @ApiPropertyOptional()
    merchantId: string;
}

export class ListProgramCampaignReq extends PageRequest {
    @ApiPropertyOptional()
    campaignId: string;

    @ApiPropertyOptional()
    walletAddress?: string;
}

export class ListCampaignPublishedReq extends PageRequest {
    @ApiPropertyOptional()
    walletAddress?: string;
}
