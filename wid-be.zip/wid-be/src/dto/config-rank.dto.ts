import { ApiPropertyOptional } from "@nestjs/swagger";

export class ConfigRankDto {
    @ApiPropertyOptional()
    icon: string;

    @ApiPropertyOptional()
    tierName: string;

    @ApiPropertyOptional()
    minQuantity: number;

    @ApiPropertyOptional()
    benefit: string;

    @ApiPropertyOptional()
    description: string;
}