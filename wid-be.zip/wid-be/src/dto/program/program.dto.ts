import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PageRequest } from "~/@systems/utils";

export class ProgramDto extends PageRequest {

}

export class ListProgramReq extends PageRequest {
}

export class RequestProgramDto {
    @ApiProperty()
    programId: string;

    @ApiProperty()
    campaignId: string;
}

export class ListRequestProgramDto extends PageRequest {
    @ApiProperty()
    id: string
}

export class ListCampaignProgramDto extends PageRequest {
}

export class ListMerchantProgramReq extends PageRequest {
    @ApiPropertyOptional()
    merchantId: string;
    
    @ApiPropertyOptional()
    walletAddress?: string;
}

export class ListProgramPublishedReq extends PageRequest {
    @ApiPropertyOptional()
    walletAddress?: string;

    @ApiPropertyOptional()
    isCanJoin?: boolean;
}

export class ListProgramExcludeDto extends PageRequest {
    @ApiPropertyOptional()
    ids: string[];

    @ApiPropertyOptional()
    walletAddress?: string;
}

export class ListProgramTransactionReq {
    @ApiPropertyOptional()
    id?: string;
}

export class DetailProgramReq {
    @ApiPropertyOptional()
    walletAddress?: string;

    @ApiPropertyOptional()
    id: string;
}
