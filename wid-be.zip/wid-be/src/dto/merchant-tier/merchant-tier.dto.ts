import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { IsNotEmpty, IsUUID } from "class-validator";
import { PageRequest } from "~/@systems/utils";
import { EMerchantTierType } from "~/common/enums/EMerchantTierType";
import { ConfigRankDto } from "../config-rank.dto";

export class MerchantTierDto extends PageRequest {

}

export class CreateMerchantTierReq {
    @ApiProperty()
    name: string;

    @ApiPropertyOptional({
        type: [ConfigRankDto],
    })
    configRank?: ConfigRankDto[];

    @ApiProperty()
    contractAddress: string;

    @ApiProperty()
    chainId: number;

    @ApiPropertyOptional()
    type: EMerchantTierType;
}

export class UpdateMerchantTierReq extends CreateMerchantTierReq {
    @ApiProperty()
    @IsNotEmpty()
    @IsUUID('4')
    id: string;
}

export class ListMerchantTierDto extends PageRequest {
    @ApiPropertyOptional()
    merchantId: string;
}

export class ListMerchantTierCampaignDto extends PageRequest {
    @ApiPropertyOptional()
    ids: string;
}

export class MerchantTierProgramDto {
    @ApiPropertyOptional()
    ids: string[];
}

