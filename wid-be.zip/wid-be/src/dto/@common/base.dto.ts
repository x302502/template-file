import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsNumber, IsUUID } from "class-validator";

export class RemoveImageDto {
    @IsNotEmpty()
    urlImage: string;
}

export class IdNumberReq {
    @ApiProperty()
    @IsNumber()
    id: number;
}
export class UUIDReq {
    @ApiProperty()
    @IsUUID("4")
    id: string;
}

export class MultipartFile {
    fieldname: string;
    originalname: string;
    encoding: string;
    mimetype: string;
    buffer: Buffer;
    size: number
}


export class EmptyPageResponse {
    data = [];
    @ApiProperty()
    total = 0;
}

