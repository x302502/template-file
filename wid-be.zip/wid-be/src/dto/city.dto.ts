import { ApiPropertyOptional } from "@nestjs/swagger";
import { PageRequest } from "~/@systems/utils";

export class CityDto {
    @ApiPropertyOptional()
    countryCode: string
}