import { PageRequest } from "~/@systems/utils";



export class ListStoreAdminReq extends PageRequest {

}