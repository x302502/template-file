import 'reflect-metadata';
require('module-alias/register');
import "es6-shim";
import 'extensionsjs/lib';
import * as dotenv from "dotenv";
dotenv.config();
import { BootServer } from './boot.server';
import { configEnv } from './@config';
import { AppModule } from './app.module';
import { MerchantModule } from './merchant.module';
import { MerchantServer } from './merchant.server';

async function run() {
    try {

        const envConfig = configEnv();

        const bootServer = new BootServer(envConfig);
        await bootServer.runApp(AppModule);
        // const bootServerMerchant = new MerchantServer(envConfig);
        // await bootServerMerchant.runApp(MerchantModule);
        console.log('-------------------');
        console.log("SERVER START");
        console.log('-------------------');
    } catch (error) {
        console.log('-------------------');
        console.log(error);
        console.log('-------------------');
    }
}
run();