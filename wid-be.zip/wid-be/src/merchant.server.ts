
import * as bodyParser from 'body-parser';
import * as compression from 'compression';
import * as cookieParser from 'cookie-parser';
import * as cors from 'cors';
import * as express from 'express';
import * as morgan from 'morgan';
import Moralis from "moralis";
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder } from '@nestjs/swagger/dist/document-builder';
import { SwaggerModule } from '@nestjs/swagger/dist/swagger-module';
import { getFromContainer, MetadataStorage } from 'class-validator';
import { validationMetadatasToSchemas } from 'class-validator-jsonschema';
import { SchemasObject } from '@nestjs/swagger/dist/interfaces/open-api-spec.interface';
import { IEnvConfig } from './@config';
import { GlobalPrefix, KeyHeader } from './common/constants';
import { HttpExceptionFilter } from './@systems/exceptions';
import { TransformInterceptor } from './@systems/interceptors';
import { ApiException } from './@core/dto';
import { setupTransactionContext } from './@core/decorator';
import { ValidatePipe } from './@systems/pipe';
import { NestExpressApplication } from '@nestjs/platform-express';
import { PageResponse } from './@systems/utils';
export class MerchantServer {
    public envConfig: IEnvConfig;
    constructor(envConfig: IEnvConfig) {
        // this.envConfig = envConfig;
    }
    async runApp(appModule: any) {
        // setupTransactionContext();
        const app = await NestFactory.create<NestExpressApplication>(appModule);
        await this.setupMerchant(app);
    }

    private configMerchantSwagger(app: NestExpressApplication, envConfig: IEnvConfig) {

        // const { rootPath, info } = envConfig.APP.swaggerMerchantConfig


        const options = new DocumentBuilder()
            .setTitle("FAM WID API")
            .setDescription("FAM WID API")
            .setVersion("1.0.0")
            .addBasicAuth({
                bearerFormat: 'JWT',
                type: 'apiKey',
                name: KeyHeader.authorization,
                in: 'header'
            }, KeyHeader.authorization)
            .build();
        const document = SwaggerModule.createDocument(app, options, {
            extraModels: [PageResponse]
        });

        // Creating all the swagger schemas based on the class-validator decorators
        const metadatas = (getFromContainer(MetadataStorage) as any).validationMetadatas;
        const targetschemas = document.components.schemas || {};
        const schemasBinding = validationMetadatasToSchemas(metadatas) || {};



        Object.keys(schemasBinding).forEach(key => {
            const value = schemasBinding[key] as SchemasObject;
            if (!targetschemas[key]) {
                Object.assign(targetschemas, {
                    key: value
                })
            } else {
                const targetValue = targetschemas[key] as SchemasObject;

                Object.assign(targetValue.properties, value.properties)
                targetValue.required = value.required;
                Object.assign(targetschemas, {
                    key: targetValue
                })
            }
        })
        document.components.schemas = Object.assign({}, targetschemas);
        SwaggerModule.setup('swagger-merchant', app, document);
    }

    async setupMerchant(app: NestExpressApplication) {
        // const { APP } = this.envConfig
        const port = 3000;
        console.log(`-------------------`);
        console.log({
            port,
            portENV: process.env.PORT
        });
        console.log(`-------------------`);
        app.use(cookieParser());
        app.use(bodyParser.json({ limit: '50mb' }));
        app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
        app.use(compression());
        app.use(express.static(GlobalPrefix.STATIC_PATH.public));
        // app.use("/" + GlobalPrefix.STATIC_PATH.files, express.static(APP.dirResource));
        app.use(morgan('dev'));
        app.use(cors());
        app.setGlobalPrefix(GlobalPrefix.API);
        app.useGlobalPipes(new ValidatePipe({ transform: true, whitelist: false }));
        app.useGlobalInterceptors(new TransformInterceptor())
        app.useGlobalFilters(new HttpExceptionFilter());
        app.use((req: express.Request, res: express.Response, next: express.NextFunction) => {
            // const { requestTimeout = 30 * 60 * 1000 } = APP;
            // res.setTimeout(requestTimeout, () => {
            //     next(new ApiException("REQUEST TIMEOUT"));
            // })
            next();
        })

        this.configMerchantSwagger(app, this.envConfig);
        const server = await app.listen(port || 8002);

        console.log(`Server start on port ${port}. Open http://localhost:${port} to see results`);
        console.log(`API DOCUMENT Open http://localhost:${port}/swagger-merchant`);
        console.log("TIMEZONE: ", process.env.TZ);

    }
}

