import { Injectable } from "@nestjs/common";
import { Timeout } from "@nestjs/schedule";




@Injectable()
export class ScheduleProvider {



    @Timeout(1000)
    async setupQueue() {
        try {

        } catch (error) {
            console.log(`=====SETUP QUEUE ERROR=====`);
            console.log(error);

        }
    }
}