import { Module } from '@nestjs/common';
import { ScheduleProvider } from './providers/schedule.provider';
@Module({
    providers: [ScheduleProvider],
})
export class ActionModule { }