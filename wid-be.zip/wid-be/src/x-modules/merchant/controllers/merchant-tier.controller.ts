import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefDelete, DefGet, DefPost } from "~/@core/decorator";
import { CreateMerchantTierReq, MerchantTierDto, UpdateMerchantTierReq } from "~/dto/merchant-tier/merchant-tier.dto";
import { MerchantTierService } from "~/services";
import { UUIDReq } from "~/dto/@common";

@DefController()
export class MerchantTierController {

    @BindService("MerchantTierService")
    private merchantTierService: MerchantTierService;

    @DefPost("create-merchant-tier", {summary: 'Create merchant tier'})
    createMerchantTier(@Body() params: CreateMerchantTierReq) {
        return this.merchantTierService.createListMerchantTier(params)
    }

    @DefGet("list-merchant-tier", {summary: 'Get a list merchant tier'})
    listMerchantTier(@Query() params: MerchantTierDto) {
        return this.merchantTierService.getListMerchantTier(params)
    }

    @DefGet("list-merchant-tier-published", {summary: 'Get a list merchant tier published'})
    listMerchantTierPublished() {
        return this.merchantTierService.getListMerchantTierPublished()
    }

    @DefGet("list-merchant-tier-by-merchant", {summary: 'Get merchant tier by merchant'})
    getListMerchantTierByMerchant() {
        return this.merchantTierService.merchartTierByMerchant()
    }

    @DefPost("update-merchant-tier", { summary: 'Update information merchant tier' })
    updatePos(@Body() body: UpdateMerchantTierReq) {
        return this.merchantTierService.updateMerchantTier(body);
    }

    @DefDelete("delete-merchant-tier", { summary: 'Delete information merchant tier' })
    deleteMerchantTier(@Body() body: UUIDReq) {
        return this.merchantTierService.deleteMerchantTier(body.id);
    }

    @DefGet("detail-merchant-tier", {summary: 'Get detail merchant tier'})
    getDetailMerchantTier(@Query() body: UUIDReq) {
        return this.merchantTierService.merchartTierDetail(body);
    }
}