import { Body, Query } from "@nestjs/common";
import { ApiExtraModels } from "@nestjs/swagger";
import { BindService, DefController, DefDelete, DefGet, DefPost } from "~/@core/decorator";
import { contextSession } from "~/@systems/middlewares";
import { ApiOkResponsePaginated, PageResponse } from "~/@systems/utils";
import { UUIDReq } from "~/dto/@common";
import { ApplyStoreInProgramReq, BrandLoginReq, BrandRegisterReq, CreateApiKeyReq, CreateCampaignReq, CreateProgramReq, CreateStoreReq, ListApiKeyReq, ListStoreApplyProgramReq, ListStoreReq, ListProgramReq, ListStoreApplyCampaignReq, UpdateCampaignReq, UpdateMerchantReq, UpdateStoreReq, UpdateProgramReq, ForgotPasswordReq, ForgotPasswordDto, ListTransactionReq } from "~/dto/brand.dto";
import { ListCampaignReq } from "~/dto/campaign/campaign.dto";
import { ListCampaignProgramDto, ListRequestProgramDto, RequestProgramDto } from "~/dto/program/program.dto";
import { SendEmailReq } from "~/dto/users/verify-email.dto";
import { MerchantApiKey, Store } from "~/entities/primary";
import { BrandService, CampaignService, StoreService, ProgramService, WidTransactionService, ApiKeyService } from "~/services";
import { CampaignProgramService } from "~/services/campaign-program.service";




@DefController("")
@ApiExtraModels(PageResponse)
export class MerchantController {

    @BindService("BrandService")
    private brandService: BrandService;

    @BindService("StoreService")
    private storeService: StoreService;

    @BindService("ProgramService")
    private programService: ProgramService;

    @BindService("CampaignService")
    private campaignService: CampaignService;

    @BindService("CampaignProgramService")
    private campaignProgramService: CampaignProgramService;

    @BindService("WidTransactionService")
    private widTransactionService: WidTransactionService;

    @BindService("ApiKeyService")
    private apiKeyService: ApiKeyService;

    @DefPost("register", { summary: 'Register an account' })
    register(@Body() body: BrandRegisterReq) {
        return this.brandService.register(body);
    }

    @DefPost("resend-mail", { summary: 'Resend email verify' })
    resendEmail(@Body() body: SendEmailReq) {
        return this.brandService.sendMailVerifyCode(body);
    }

    @DefPost("send-mail-forgot-password", { summary: 'Forgot password' })
    sendMailForgotPassword(@Body() body: ForgotPasswordReq) {
        return this.brandService.sendMailForgotPassword(body);
    }

    @DefPost("forgot-password", { summary: 'Forgot password' })
    forgotPassword(@Body() body: ForgotPasswordDto) {
        return this.brandService.forgotPassword(body);
    }

    @DefPost("login", { summary: 'Account login' })
    login(@Body() body: BrandLoginReq) {
        return this.brandService.login(body);
    }

    @DefPost("authenticate", { summary: 'Get back login token' })
    authenticate() {
        return this.brandService.authenticate();
    }

    @DefGet("infomation", { summary: 'Get merchant information' })
    infomation(@Query() params: UUIDReq) {
        return this.brandService.infomation(params);
    }

    @DefPost("update-merchant", { summary: 'Update merchant information' })
    updateMerchant(@Body() body: UpdateMerchantReq) {
        return this.brandService.updateMerchant(body);
    }

    @DefPost("create-api-key", { summary: 'Generate API Key' })
    createApiKey(@Body() body: CreateApiKeyReq) {
        return this.brandService.createApiKey(body.keyName);
    }

    @DefDelete("delete-api-key", { summary: 'Delete API Key' })
    deleteApiKey(@Body() body: UUIDReq) {
        return this.brandService.deleteApiKey(body.id);
    }

    @ApiOkResponsePaginated(MerchantApiKey)
    @DefGet("list-api-key", { summary: 'Get list API Key' })
    listApiKey(@Query() params: ListApiKeyReq) {
        return this.brandService.listApiKeyByBrand({
            ...params,
            merchantId: contextSession.merchantId
        });
    }

    @ApiOkResponsePaginated(Store)
    @DefGet("list-store-by-merchant", { summary: 'Get list Store by merchant' })
    listStoreByMerchant(@Query() params: ListStoreReq) {
        return this.storeService.listStoreByMerchant({
            ...params,
            merchantId: contextSession.merchantId
        });
    }

    @DefPost("create-store", { summary: 'Create store' })
    createStore(@Body() body: CreateStoreReq) {
        return this.storeService.createStore(body);
    }

    @DefPost("update-store", { summary: 'Update information store' })
    updateStore(@Body() body: UpdateStoreReq) {
        return this.storeService.updateStore(body);
    }

    @DefGet("store-detail", { summary: 'Get information Store' })
    storeDetail(@Query() params: UUIDReq) {
        return this.storeService.storeDetail(params);
    }

    @DefDelete("delete-store", { summary: 'Delete information Store' })
    deleteStore(@Body() body: UUIDReq) {
        return this.storeService.deleteStore(body.id);
    }


    @ApiOkResponsePaginated(Store)
    @DefGet("list-program-by-merchant", { summary: 'Get list program by merchant' })
    listProgramByBrand(@Query() params: ListProgramReq) {
        return this.programService.listProgramByMerchant({
            ...params,
            merchantId: contextSession.merchantId
        });
    }

    @DefPost("create-program", { summary: 'Create program' })
    createProgram(@Body() body: CreateProgramReq) {
        return this.programService.createProgram(body);
    }

    @DefPost("update-program", { summary: 'Update program' })
    updateProgram(@Body() body: UpdateProgramReq) {
        return this.programService.updateProgram(body);
    }

    @DefGet("program-detail", { summary: 'Get information program' })
    programDetail(@Query() params: UUIDReq) {
        return this.programService.programDetail(params);
    }

    @DefDelete("delete-program", { summary: 'Delete information program' })
    deleteProgram(@Body() body: UUIDReq) {
        return this.programService.deleteProgram(body.id);
    }

    @DefPost("campaign-invite", { summary: 'Campaign invite program' })
    campaignInviteProgram(@Body() body: RequestProgramDto) {
        return this.campaignProgramService.createCampaignInviteProgram(body);
    }

    @DefPost("list-accept-program", { summary: 'Get list program request for campaign accept' })
    listAcceptProgram(@Body() body: ListCampaignProgramDto) {
        return this.campaignProgramService.getListAcceptProgramRequest(body);
    }

    @DefPost("list-detail-accept-program", { summary: 'Get list program request for campaign accept' })
    listDetailAcceptProgram(@Body() body: ListRequestProgramDto) {
        return this.campaignProgramService.getAcceptProgramRequest(body);
    }

    @DefPost("list-campaign-for-program", { summary: 'Get list campaign for program request' })
    listCampaignForProgram(@Body() body: ListRequestProgramDto) {
        return this.campaignProgramService.getListAcceptProgramRequest(body);
    }

    @DefPost("accept-program-request", { summary: 'Campaign accept program request' })
    acceptProgramRequest(@Body() body: RequestProgramDto) {
        return this.campaignProgramService.acceptProgramRequest(body);
    }

    @DefPost("reject-program-request", { summary: 'Campaign reject program request' })
    rejectProgramRequest(@Body() body: RequestProgramDto) {
        return this.campaignProgramService.rejectProgramRequest(body);
    }

    @DefPost("request-campaign", { summary: 'Program request campaign' })
    programRequestCampaign(@Body() body: RequestProgramDto) {
        return this.campaignProgramService.createProgramRequestCampaign(body);
    }

    @DefPost("list-accept-campaign", { summary: 'Get list campaign invite for program accept' })
    listAcceptCampaignInvite(@Body() body: ListCampaignProgramDto) {
        return this.campaignProgramService.getListAcceptCampaignInvite(body);
    }

    @DefPost("accept-campaign-invite", { summary: 'Program accept campaign invite' })
    acceptCampaignInvite(@Body() body: RequestProgramDto) {
        return this.campaignProgramService.acceptCampaignInvite(body);
    }

    @DefPost("reject-campaign-invite", { summary: 'Program reject campaign invite' })
    rejectCampaignInvite(@Body() body: RequestProgramDto) {
        return this.campaignProgramService.rejectCampaignInvite(body);
    }

    @DefPost("list-program-in-campaign", { summary: 'Get list program in campaign' })
    listProgramInCampaign(@Body() body: UUIDReq) {
        return this.campaignProgramService.getListProgramInCampaign(body);
    }

    @DefPost("request-publish-program", { summary: 'Request Publish Program' })
    requestPublishProgram(@Body() body: UUIDReq) {
        return this.programService.requestPublishProgram(body);
    }

    @DefPost("request-publish-campaign", { summary: 'Request Publish Campaign' })
    requestPublishCampaign(@Body() body: UUIDReq) {
        return this.campaignService.requestPublishCampaign(body);
    }

    @DefPost("list-all-campaign-by-tiers", { summary: 'Get list all campaign by tiers' })
    listAllCampaignByTiers(@Body() body: ListRequestProgramDto) {
        return this.campaignProgramService.listAllCampaignByTiers(body);
    }

    @DefPost("list-all-program-by-tiers", { summary: 'Get list all program by tiers' })
    listAllProgramByTiers(@Body() body: ListRequestProgramDto) {
        return this.campaignProgramService.listAllProgramByTiers(body);
    }

    @DefPost("list-campaigns-participated-program", { summary: 'Get list campaigns participated in the Program' })
    listCampaignJoinedProgram(@Body() body: UUIDReq) {
        return this.campaignProgramService.listCampaignJoinedProgram(body);
    }

    @DefGet("list-store-apply-program", { summary: 'Get list store apply program' })
    listStoreApplyProgram(@Query() params: ListStoreApplyProgramReq) {
        return this.storeService.listStoreApplyProgram({
            ...params,
        });
    }

    @DefPost("apply-store-in-program", { summary: 'Apply store in program' })
    applyStoreInProgram(@Body() body: ApplyStoreInProgramReq) {
        return this.programService.applyStoreInProgram(body);
    }

    @DefPost("create-campaign", { summary: 'Create campaign' })
    createCampaign(@Body() body: CreateCampaignReq) {
        return this.campaignService.createCampaign(body);
    }


    @DefGet("list-campaign", { summary: 'List campaign' })
    listCampaign(@Query() body: ListCampaignReq) {
        return this.campaignService.listByMerchant(body);
    }

    @DefPost("update-campaign", { summary: 'Update campaign' })
    updateCampaign(@Body() body: UpdateCampaignReq) {
        return this.campaignService.updateCampaign(body);
    }

    @DefGet("campaign-detail", { summary: 'Get information campaign' })
    campaignDetail(@Query() params: UUIDReq) {
        return this.campaignService.campaignDetail(params);
    }

    @DefDelete("delete-campaign", { summary: 'Delete information campaign' })
    deleteCampaign(@Body() body: UUIDReq) {
        return this.campaignService.deleteCampaign(body.id);
    }

    @DefGet("list-transaction-by-merchant", { summary: 'Get list transaction by merchant' })
    listByMerchant(@Query() params: ListTransactionReq) {
        return this.widTransactionService.listByMerchant(params);
    }

    @DefGet("list-transaction-by-campaign", { summary: 'Get list transaction by campaign' })
    listByCampaign(@Query() params: ListTransactionReq) {
        return this.widTransactionService.listByCampaign(params);
    }

    @DefGet("list-transaction-by-program", { summary: 'Get list transaction by program' })
    listByProgram(@Query() params: ListTransactionReq) {
        return this.widTransactionService.listByProgram(params);
    }


    @DefGet("first-api-by-merchant", { summary: 'first-api-by-merchant' })
    firstApiByMerchant() {
        const { merchantId } = contextSession;
        return this.apiKeyService.firstApiByMerchant({ merchantId });
    }
}