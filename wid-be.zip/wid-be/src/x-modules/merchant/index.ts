import { ChildModule } from '~/@core/decorator';
import { RefixModule } from '../config-module';
import { MerchantController } from './controllers/merchant.controller';
import { MiddlewareConsumer, NestModule, RequestMethod } from '@nestjs/common';
import { BrandMiddleware } from '~/@systems/middlewares';
import { GlobalPrefix } from '~/common/constants';
import { MerchantTierController } from './controllers/merchant-tier.controller';

@ChildModule({
    prefix: RefixModule.merchant,
    controllers: [
        MerchantController,
        MerchantTierController
    ],
})
export class BrandModule implements NestModule {
    configure(consumer: MiddlewareConsumer) {
        consumer.apply(BrandMiddleware)
            .exclude(
                {
                    path: `${GlobalPrefix.API}/${RefixModule.merchant}/login`.trim(),
                    method: RequestMethod.POST,
                },
                {
                    path: `${GlobalPrefix.API}/${RefixModule.merchant}/register`.trim(),
                    method: RequestMethod.POST
                },
                {
                    path: `${GlobalPrefix.API}/${RefixModule.merchant}/send-mail-forgot-password`.trim(),
                    method: RequestMethod.POST
                },
                {
                    path: `${GlobalPrefix.API}/${RefixModule.merchant}/forgot-password`.trim(),
                    method: RequestMethod.POST
                },
                {
                    path: `${GlobalPrefix.API}/${RefixModule.merchant}/resend-mail`.trim(),
                    method: RequestMethod.POST
                })
            .forRoutes({ path: `${RefixModule.merchant}*`, method: RequestMethod.ALL, });
    }
}
