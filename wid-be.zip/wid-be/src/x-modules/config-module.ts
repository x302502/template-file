export const RefixModule = {
    public: "public",
    admin: "admin",
    merchant: "merchant"
}