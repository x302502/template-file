import { ChildModule } from '~/@core/decorator';
import { RefixModule } from '../config-module';
import { AuthController } from './controllers/auth.controller';
import { MiddlewareConsumer, NestModule, RequestMethod } from '@nestjs/common';
import { AdminMiddleware } from '~/@systems/middlewares';
import { GlobalPrefix } from '~/common/constants';
import { ApiKeyController } from './controllers/api-key.controller';
import { NftController } from './controllers/nft.controller';
import { TransactionController } from './controllers/transaction.controller';
import { UserController } from './controllers/user.controller';
import { MerchantsController } from './controllers/merchants.controller';
import { StoreController } from './controllers/store.controller';
import { ProgramsController } from './controllers/program.controller';
import { CampaignsController } from './controllers/campaign.controller';

@ChildModule({
    prefix: RefixModule.admin,
    controllers: [
        AuthController,
        MerchantsController,
        ApiKeyController,
        NftController,
        TransactionController,
        UserController,
        StoreController,
        ProgramsController,
        CampaignsController,
    ],
})
export class AdminModule implements NestModule {
    configure(consumer: MiddlewareConsumer) {
        consumer.apply(AdminMiddleware)
            .exclude(
                {
                    path: `${GlobalPrefix.API}/${RefixModule.admin}/login`.trim(),
                    method: RequestMethod.ALL,
                },
                {
                    path: `${GlobalPrefix.API}/${RefixModule.admin}/register`.trim(),
                    method: RequestMethod.ALL
                })
            .forRoutes({ path: `${RefixModule.admin}*`, method: RequestMethod.ALL, });

    }

}
