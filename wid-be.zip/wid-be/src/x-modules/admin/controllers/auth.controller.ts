import { Body } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { LoginReq, RegisterReq } from "~/dto/auth.dto";
import { AuthService } from "~/services";




@DefController("")
export class AuthController {


    @BindService("AuthService")
    private authService: AuthService

    @DefPost("register", { summary: 'Register for an admin user account'})
    register(@Body() body: RegisterReq) {
        return this.authService.register(body);
    }

    @DefPost("login", { summary: 'Account login'})
    login(@Body() body: LoginReq) {
        return this.authService.login(body);
    }


    @DefPost("authenticate", { summary: 'Get back login token'})
    authenticate() {
        return this.authService.authenticate();
    }



}