import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { ApiOkResponsePaginated } from "~/@systems/utils";
import { UUIDReq } from "~/dto/@common";
import { ListApiKeyByBrandReq, ListApiKeyReq, ListBrandReq } from "~/dto/brand.dto";
import { Merchant, MerchantApiKey } from "~/entities/primary";
import { AuthService, BrandService } from "~/services";




@DefController("merchants")
export class MerchantsController {


    @BindService("BrandService")
    private brandService: BrandService


    @DefPost("verify", { summary: 'Verify merchant' })
    verify(@Body() body: UUIDReq) {
        return this.brandService.verify(body);
    }


    @ApiOkResponsePaginated(Merchant)
    @DefGet("list", { summary: 'Get list merchant' })
    list(@Query() params: ListBrandReq) {
        return this.brandService.list(params);
    }


    @ApiOkResponsePaginated(MerchantApiKey)
    @DefGet("list-api-key", { summary: 'Get list API Key by merchant' })
    listApiKey(@Query() params: ListApiKeyByBrandReq) {
        return this.brandService.listApiKeyByBrand(params);
    }

}