import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { ApiOkResponsePaginated } from "~/@systems/utils";
import { UUIDReq } from "~/dto/@common";
import { ListCampaignReq } from "~/dto/campaign/campaign.dto";
import { Campaign } from "~/entities/primary";
import { CampaignService } from "~/services";


@DefController("campaigns")
export class CampaignsController {


    @BindService("CampaignService")
    private campaignService: CampaignService;




    @ApiOkResponsePaginated(Campaign)
    @DefGet("list", { summary: 'Get list campaign' })
    list(@Query() params: ListCampaignReq) {
        return this.campaignService.list(params);
    }

    @DefPost("verify-campaign", { summary: 'Verify campaign' })
    verify(@Body() body: UUIDReq) {
        return this.campaignService.verifyCampaign(body);
    }

    @DefPost("reject-request-campaign", { summary: 'reject-request-campaign' })
    rejectRequestProgram(@Body() body: UUIDReq) {
        return this.campaignService.rejectRequestCampaign(body);
    }

    @DefPost("suspend-campaign", { summary: 'suspend-campaign' })
    suspendCampaign(@Body() body: UUIDReq) {
        return this.campaignService.suspendCampaign(body);
    }

}