import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { ApiOkResponsePaginated } from "~/@systems/utils";
import { UUIDReq } from "~/dto/@common";
import { ListApiKeyByBrandReq, ListApiKeyReq, ListBrandReq } from "~/dto/brand.dto";
import { ListStoreAdminReq } from "~/dto/store.dto";
import { Merchant, MerchantApiKey } from "~/entities/primary";
import { AuthService, BrandService, StoreAdminService } from "~/services";




@DefController("stores")
export class StoreController {


    @BindService("StoreAdminService")
    private storeAdminService: StoreAdminService

    @DefGet("list")
    list(@Query() params: ListStoreAdminReq) {
        return this.storeAdminService.list(params);
    }
}