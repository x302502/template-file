import { Query } from "@nestjs/common";
import { BindService, DefController, DefGet } from "~/@core/decorator";
import { PageRequest } from "~/@systems/utils";
import { UserService, WidTransactionService } from "~/services";




@DefController("transactions")
export class TransactionController {


    @BindService("WidTransactionService")
    private widTransactionService: WidTransactionService


    @DefGet("list", { summary: 'Get list wid transaction'})
    list(@Query() params: PageRequest) {
        return this.widTransactionService.list(params);
    }

}