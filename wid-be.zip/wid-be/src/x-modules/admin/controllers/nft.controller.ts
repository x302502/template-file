import { Query } from "@nestjs/common";
import { BindService, DefController, DefGet } from "~/@core/decorator";
import { PageRequest } from "~/@systems/utils";
import { CheckPriceReq } from "~/dto/nft.dto";
import { NftCollectionService } from "~/services";



@DefController("nfts")
export class NftController {


    @BindService("NftCollectionService")
    private nftCollectionService: NftCollectionService

    @DefGet("check-price", { summary: 'Get Nft Information By Address'})
    checkPrice(@Query() params: CheckPriceReq) {
        return this.nftCollectionService.checkPrice(params);
    }


    @DefGet("list-collection", { summary: 'Get list NFT collection'})
    listCollection(@Query() params: PageRequest) {
        return this.nftCollectionService.listCollection(params);
    }
}