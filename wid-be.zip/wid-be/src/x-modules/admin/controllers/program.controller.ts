import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { ApiOkResponsePaginated } from "~/@systems/utils";
import { UUIDReq } from "~/dto/@common";
import { ListProgramReq } from "~/dto/program/program.dto";
import { Program } from "~/entities/primary";
import { ProgramService } from "~/services";


@DefController("programs")
export class ProgramsController {


    @BindService("ProgramService")
    private programService: ProgramService

    @ApiOkResponsePaginated(Program)
    @DefGet("list", { summary: 'Get list program' })
    list(@Query() params: ListProgramReq) {
        return this.programService.list(params);
    }


    @DefPost("verify-program", { summary: 'Verify program' })
    verify(@Body() body: UUIDReq) {
        return this.programService.verifyProgram(body);
    }

    @DefPost("reject-request-program", { summary: 'reject-request-program' })
    rejectRequestProgram(@Body() body: UUIDReq) {
        return this.programService.rejectRequestProgram(body);
    }

    @DefPost("suspend-program", { summary: 'suspend-program' })
    suspendProgram(@Body() body: UUIDReq) {
        return this.programService.suspendProgram(body);
    }

}