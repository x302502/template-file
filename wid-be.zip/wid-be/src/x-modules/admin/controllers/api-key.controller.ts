import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { ApiOkResponsePaginated } from "~/@systems/utils";
import { UUIDReq } from "~/dto/@common";
import { LoginReq, RegisterReq } from "~/dto/auth.dto";
import { ListApiKeyByBrandReq, ListApiKeyReq, ListBrandReq } from "~/dto/brand.dto";
import { Merchant, MerchantApiKey } from "~/entities/primary";
import { ApiKeyService, AuthService, BrandService } from "~/services";




@DefController("api-key")
export class ApiKeyController {


    @BindService("ApiKeyService")
    private apiKeyService: ApiKeyService


    @ApiOkResponsePaginated(MerchantApiKey)
    @DefGet("list", { summary: 'Get list of API Key'})
    list(@Query() params: ListBrandReq) {
        return this.apiKeyService.list(params);
    }



}