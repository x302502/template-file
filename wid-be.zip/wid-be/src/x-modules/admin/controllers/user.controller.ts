import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { PageRequest } from "~/@systems/utils";
import { LoginReq, RegisterReq } from "~/dto/auth.dto";
import { AuthService, UserService } from "~/services";




@DefController("users")
export class UserController {


    @BindService("UserService")
    private userService: UserService


    @DefGet("list", { summary: 'Get list user'})
    list(@Query() params: PageRequest) {
        return this.userService.list(params);
    }

}