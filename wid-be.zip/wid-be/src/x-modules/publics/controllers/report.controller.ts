import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { UUIDReq } from "~/dto/@common";
import { ListMerchantProgramReq, ProgramDto } from "~/dto/program/program.dto";
import { ListProgramPublishedReq } from "~/dto/program/program.dto";
import { WalletAddressReq } from "~/dto/user.dto";
import { ProgramService, ReportService } from "~/services";

@DefController("reports")

export class ReportController {

    @BindService("ReportService")
    private reportService: ReportService;


    @DefGet("summary-system", { summary: "summary-system" })
    summarySystem() {
        return this.reportService.summarySystem()
    }

    @DefGet("summary-user", { summary: "summary-user" })
    summaryUser(@Query() params: WalletAddressReq) {
        return this.reportService.summaryUser(params)
    }
}