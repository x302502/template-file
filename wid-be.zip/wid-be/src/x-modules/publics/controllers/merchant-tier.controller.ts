import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefDelete, DefGet, DefPost } from "~/@core/decorator";
import { CreateMerchantTierReq, ListMerchantTierDto, MerchantTierDto, MerchantTierProgramDto, UpdateMerchantTierReq } from "~/dto/merchant-tier/merchant-tier.dto";
import { MerchantTierService } from "~/services";
import { UUIDReq } from "~/dto/@common";

@DefController()
export class MerchantTierController {

    @BindService("MerchantTierService")
    private merchantTierService: MerchantTierService;

    @DefGet("list-merchant-tier-by-merchant", {summary: 'Get a list merchant tier by merchant'})
    listMerchantTierByMerchant(@Query() params: ListMerchantTierDto) {
        return this.merchantTierService.findByMerchantId(params);
    }

    @DefPost("list-merchant-tier-by-ids", {summary: 'Get a list merchant tier by ids'})
    listMerchantTierByIds(@Body() params: MerchantTierProgramDto) {
        return this.merchantTierService.findByIds(params);
    }
}