import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { UUIDReq } from "~/dto/@common";
import { DetailProgramReq, ListCampaignProgramDto, ListMerchantProgramReq, ListProgramExcludeDto, ListProgramTransactionReq, ProgramDto } from "~/dto/program/program.dto";
import { ListProgramPublishedReq } from "~/dto/program/program.dto";
import { ProgramService } from "~/services";

@DefController("programs")
export class ProgramController {

    @BindService("ProgramService")
    private programService: ProgramService;

    @DefPost("list-published", { summary: 'Get list program published for user' })
    listPublished(@Body() body: ListProgramPublishedReq) {
        return this.programService.listPublished(body);
    }

    @DefGet("detail-program", {summary: 'Get detail program'})
    getDetail(@Query() params: DetailProgramReq) {
        return this.programService.getDetailProgram(params)
    }

    @DefGet("list-program-by-merchant", {summary: 'Get program by merchant'})
    getListByMerchant(@Query() params: ListMerchantProgramReq) {
        return this.programService.listByMerchantId(params)
    }

    @DefPost("list-program-exclude-ids", {summary: 'Get program exclude ids'})
    getListProgramExcludeIds(@Body() params: ListProgramExcludeDto) {
        return this.programService.getListProgramExcludeIds(params)
    }

    @DefPost("list-published-for-user", { summary: 'Get list campaign published for user page' })
    listPublishedForUser(@Body() body: ListProgramPublishedReq) {
        return this.programService.listPublishedForUser(body);
    }
}