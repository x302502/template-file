import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { UUIDReq } from "~/dto/@common";
import { ListMerchantReq, ListProgramReq, ListStoreByMerchantReq, ListTransactionByUserReq, ListTransactionReq } from "~/dto/brand.dto";
import { ListCampaignReq } from "~/dto/campaign/campaign.dto";
import { CityDto } from "~/dto/city.dto";
import { CountryDto } from "~/dto/country.dto";
import { ListNftReq } from "~/dto/nft.dto";
import { ProgramDto } from "~/dto/program/program.dto";
import { ListMerchantTierByUserReq, ListOfferBySearchTypeReq, ScanWidReq, SpecialOfferReq, UpdateUserProfileReq, WalletAddressReq } from "~/dto/user.dto";
import { VerifyEmailReq } from "~/dto/users/verify-email.dto";
import { BrandService, CampaignService, CityService, CountryService, MerchantTierService, NftService, ProgramService, StoreService, UserService, WidTransactionService } from "~/services";




@DefController()
export class PublicController {


    @BindService("UserService")
    private userService: UserService;

    @BindService("NftService")
    private nftService: NftService;

    @BindService("ProgramService")
    private programService: ProgramService;

    @BindService("WidTransactionService")
    private widTransactionService: WidTransactionService;

    @BindService("CountryService")
    private countryService: CountryService;

    @BindService("CityService")
    private cityService: CityService;

    @BindService("BrandService")
    private brandService: BrandService;

    @BindService("CampaignService")
    private campaignService: CampaignService;

    @BindService("StoreService")
    private storeService: StoreService;


    @BindService("MerchantTierService")
    private merchantTierService: MerchantTierService;


    @DefPost("sync-wallet", { summary: 'Sync wallet with user account' })
    syncWallet(@Body() body: WalletAddressReq) {
        return this.userService.syncWallet(body)
    }

    @DefGet("list-nft", { summary: 'Get a list of NFTs by owner' })
    listNf(@Query() params: ListNftReq) {
        return this.nftService.listNf(params)
    }

    @DefGet("list-nft-summary", { summary: 'Get a limited list of NFTs by Owner' })
    listNfSummary(@Query() params: WalletAddressReq) {
        return this.nftService.listNfSummary(params)
    }

    @DefGet("user-info-by-wallet", { summary: 'Get user information by wallet address' })
    userInfoByWallet(@Query() params: WalletAddressReq) {
        return this.userService.userInfoByWallet(params)
    }

    @DefPost("update-user-profile", { summary: 'Update user profile' })
    updateUserProfile(@Body() body: UpdateUserProfileReq) {
        return this.userService.updateUserProfile(body)
    }


    @DefGet("special-offer", { summary: 'Get the list of Special Offers according to the user tier' })
    specialOffer(@Query() params: SpecialOfferReq) {
        return this.programService.specialOffer(params)
    }

    @DefGet("list-offer-by-search-type", { summary: 'Get a list of offers by type' })
    listOfferBySearchType(@Query() params: ListOfferBySearchTypeReq) {
        return this.programService.listOfferBySearchType(params)
    }


    @DefPost("scan-wid", { summary: 'Scan WID' })
    scanWid(@Body() body: ScanWidReq) {
        return this.userService.scanWid(body)
    }

    @DefGet("list-country", { summary: 'Get list country' })
    listCountry() {
        return this.countryService.listCountry();
    }

    @DefPost("list-city-by-country-code", { summary: 'Get list city' })
    listCityByCountryCode(@Body() params: CityDto) {
        return this.cityService.listCityByCountryCode(params);
    }

    @DefPost("verify-email", { summary: 'Verify Email Account Merchant' })
    verifyEmail(@Body() body: VerifyEmailReq) {
        return this.brandService.verifyEmail(body);
    }

    @DefPost("list-campaign-published", { summary: 'Get list campaign published for user' })
    listCampaignPublished(@Body() body: ListCampaignReq) {
        return this.campaignService.listCampaignPublished(body);
    }

    @DefPost("list-program-published", { summary: 'Get list program published for user' })
    listProgramPublished(@Body() body: ListProgramReq) {
        return this.programService.listProgramPublished(body);
    }

    @DefPost("list-merchant-by-type", { summary: 'Get merchant by type' })
    listMerchantForUserByType(@Body() body: ListMerchantReq) {
        return this.brandService.listMerchantByType(body);
    }

    @DefPost("detail-merchant", { summary: 'Get detail merchant' })
    getDetailMerchant(@Body() body: UUIDReq) {
        return this.brandService.getDetailMerchant(body);
    }

    @DefPost("list-store-by-merchant", { summary: 'Get list store by merchant' })
    listStoreByMerchant(@Body() body: ListStoreByMerchantReq) {
        return this.storeService.listStoreByMerchant(body);
    }

    @DefGet("list-program", { summary: 'Get a list program' })
    getListProgram(@Query() params: ProgramDto) {
        return this.programService.getListProgram(params)
    }

    @DefGet("list-merchant-tier-by-user", { summary: 'Get list merchant tier by user' })
    listMerchantTierByUser(@Query() params: ListMerchantTierByUserReq) {
        return this.merchantTierService.listMerchantTierByUser(params)
    }

    @DefGet("transaction-history-by-user", { summary: 'Gte transaction history by user' })
    transactionHistoryByUser(@Query() params: ListTransactionByUserReq) {
        return this.widTransactionService.transactionHistoryByUser(params)
    }

    @DefGet("list-store-by-program", { summary: 'Get list store by program' })
    listStoreByProgram(@Query() params: UUIDReq) {
        return this.storeService.listStoreByProgram(params);
    }
}