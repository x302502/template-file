import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { UUIDReq } from "~/dto/@common";
import { ListMerchantCampaignReq, ListProgramCampaignReq } from "~/dto/campaign/campaign.dto";
import { CampaignService } from "~/services";
import { ListCampaignProgramDto, ListProgramPublishedReq } from "~/dto/program/program.dto";

@DefController("campaigns")
export class CampaignController {

    @BindService("CampaignService")
    private campaignService: CampaignService;

    @DefGet("detail-campaign", { summary: 'Get detail campaign' })
    getDetail(@Query() params: UUIDReq) {
        return this.campaignService.getDetailCampaign(params);
    }

    @DefGet("program-by-campaign", { summary: 'Program by campaign' })
    programByCampaign(@Query() params: ListProgramCampaignReq) {
        return this.campaignService.listProgramByCampaign(params);
    }

    @DefGet("list-merchant-tier-by-campaign", { summary: 'Get list merchant tier by campaign' })
    listMerchantTierByCampaign(@Query() params: ListProgramCampaignReq) {
        return this.campaignService.listMerchantTiersByCampaign(params);
    }

    @DefGet("list-campaign-by-merchant", { summary: 'Get campaign by merchant' })
    getListByMerchant(@Query() params: ListMerchantCampaignReq) {
        return this.campaignService.listByMerchantId(params);
    }

    @DefPost("list-published", { summary: 'Get list campaign published for user' })
    listPublished(@Body() body: ListProgramPublishedReq) {
        return this.campaignService.listPublished(body);
    }

    @DefPost("list-published-for-user", { summary: 'Get list campaign published for user page' })
    listPublishedForUser(@Body() body: ListCampaignProgramDto) {
        return this.campaignService.listPublishedForUser(body);
    }
}