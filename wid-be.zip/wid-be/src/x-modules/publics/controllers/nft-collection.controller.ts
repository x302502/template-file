import { Body, Query } from "@nestjs/common";
import { BindService, DefController, DefGet, DefPost } from "~/@core/decorator";
import { NftCollectionDto } from "~/dto/nft-collection/program.dto";
import { NftCollectionService } from "~/services";

@DefController()
export class NftCollectionController {

    @BindService("NftCollectionService")
    private nftCollectionService: NftCollectionService;

    @DefGet("list-nft", {summary: 'Get a list nft collection'})
    listCollection(@Query() params: NftCollectionDto) {
        return this.nftCollectionService.listCollection(params)
    }
}