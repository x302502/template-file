import { Query } from "@nestjs/common";
import { BindService, DefController, DefGet } from "~/@core/decorator";
import { PageRequest } from "~/@systems/utils";
import { UUIDReq } from "~/dto/@common";
import { ListTransactionReq } from "~/dto/brand.dto";
import { UserService, WidTransactionService } from "~/services";




@DefController("transactions")
export class TransactionController {


    @BindService("WidTransactionService")
    private widTransactionService: WidTransactionService


    @DefGet("list-transaction-by-merchant", { summary: 'Get list transaction by merchant'})
    listByMerchant(@Query() params: ListTransactionReq) {
        return this.widTransactionService.listByMerchant(params);
    }

    @DefGet("list-transaction-by-campaign", { summary: 'Get list transaction by campaign'})
    listByCampaign(@Query() params: ListTransactionReq) {
        return this.widTransactionService.listByCampaign(params);
    }

    @DefGet("list-transaction-by-program", { summary: 'Get list transaction by program'})
    listByProgram(@Query() params: ListTransactionReq) {
        return this.widTransactionService.listByProgram(params);
    }


}