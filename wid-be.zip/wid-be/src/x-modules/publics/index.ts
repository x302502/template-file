import { ChildModule } from '~/@core/decorator';
import { RefixModule } from '../config-module';
import { CampaignController } from './controllers/campaign.controller';
import { MerchantTierController } from './controllers/merchant-tier.controller';
import { ProgramController } from './controllers/program.controller';
import { PublicController } from './controllers/public.controller';
import { ReportController } from './controllers/report.controller';
import { TransactionController } from './controllers/transaction.controller';


@ChildModule({
    prefix: RefixModule.public,
    controllers: [
        PublicController,
        ProgramController,
        CampaignController,
        MerchantTierController,
        ReportController,
        TransactionController
    ],
})
export class PublicModule {
}
