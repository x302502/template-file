export enum EPlatform {
    ANDROID = 'ANDROID',
    IOS = 'IOS',
    WEB = 'WEB'
}