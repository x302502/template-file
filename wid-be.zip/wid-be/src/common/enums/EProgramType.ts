export enum EProgramType {
    NORMAL = 0,
    UNDER_CAMPAIGN = 1
}