export enum EProgramStatus {
    DRAFT = 0,
    REQUEST_PUBLISHED = 1,
    PUBLISHED,
    REJECT,
    UNPUBLISHED,
    SUSPENDED,
}