export enum EMerchantTierStatus {
    PENDING = 1,
    VERIFY,
    RELEASE
}