export enum EUserStatus {
    INACTIVE = 0,
    ACTIVE,
};
