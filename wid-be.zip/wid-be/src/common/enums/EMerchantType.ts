export enum EMerchantType {
    MERCHART = 'MERCHANT',
    WEB3PROJECT = 'WEB3PROJECT'
}