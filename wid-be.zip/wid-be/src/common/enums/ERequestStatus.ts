export enum ERequestStatus {
    NOT_APPLY = 1,
    APPLY = 2,
    REJECT = 3
}