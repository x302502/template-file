export enum EAddressType {
    MERCHANT = 1,
    STORE = 2
}