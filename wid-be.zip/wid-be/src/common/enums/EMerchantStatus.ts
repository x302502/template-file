export enum EMerchantStatus {
    DRAFT = 0,
    PENDING = 1,
    VERIFY,
    RELEASE
}