export enum EUserAdminStatus {
  INACTIVE = 0,
  ACTIVE,
};
