export enum EUserTier {
    NONTIER = -1,
    TIER1 = 1,
    TIER2,
    TIER3,
    TIER4
}