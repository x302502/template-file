export enum EMerchantTierType {
    NFT = 1,
    TOKEN = 2
}