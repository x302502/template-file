export enum ENftType {
    ERC721 = "ERC721",
    ERC1155 = "ERC1155"
}