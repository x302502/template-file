export enum ENftTier {
    NONTIER = -1,
    TIER1 = 1,
    TIER2,
    TIER3
}