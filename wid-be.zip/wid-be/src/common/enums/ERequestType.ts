export enum ERequestType {
    "CAMPAIGN_INVITE",
    "PROGRAM_REQUEST"
}