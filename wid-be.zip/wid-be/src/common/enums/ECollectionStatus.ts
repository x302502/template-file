export enum ECollectionStatus {
    INACTIVE = 0,
    ACTIVE,
};
