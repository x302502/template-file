export const KeyHeader = {
    authorization: 'authorization',
    lang: 'lang',
}