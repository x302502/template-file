export const GlobalPrefix = {
    API: "api",
    STATIC_PATH: {
        public: "public",
        files: "files"
    }
}