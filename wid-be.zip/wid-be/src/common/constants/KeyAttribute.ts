export const KeyAttribute = {
    userSession: "userSession".trim(),
    merchantSession: "merchantSession".trim(),
}