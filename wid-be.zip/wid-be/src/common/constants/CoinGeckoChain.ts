import { EvmChain } from "@moralisweb3/common-evm-utils";

// ethereum => mạng eth
// binance-smart-chain => mạng bsc
// polygon-pos => mạng matic
// arbitrum-one => mạng arb
export const CoinGeckoChain = {
    [EvmChain.BSC.decimal]: "binance-smart-chain",
    [EvmChain.POLYGON.decimal]: "polygon-pos",
    [EvmChain.ETHEREUM.decimal]: "ethereum",
    [EvmChain.ARBITRUM.decimal]: "arbitrum-one",
}