// interface Window {
//   initialReduxState: any
// }

declare module "*.json" {
  const value: any;
  export default value;
}
declare module '*.css';
declare module '*.less';
declare module '*.scss';
declare module '*.sass';
declare module '*.svg';
declare module '*.png';
declare module '*.jpg';
declare module '*.jpeg';
declare module '*.gif';
declare module '*.bmp';
