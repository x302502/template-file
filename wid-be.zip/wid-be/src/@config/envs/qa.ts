import { join } from 'path';
import { EvmChain } from "@moralisweb3/common-evm-utils";
import { IEnvConfig } from '..';



const config: IEnvConfig = {
    APP: {
        dirResource: "./../resource-files/",
        requestTimeout: 30 * 60 * 1000,
        swaggerConfig: {
            rootPath: "swagger",
            info: {
                title: "FAM WID API",
                description: "The FAM WID API",
                version: "1.0",

            }
        },
        swaggerMerchantConfig: {
            rootPath: "swagger-merchant",
            info: {
                title: "FAM WID API",
                description: "The FAM WID API",
                version: "1.0",

            }
        }
    },
    CDN_URL: "",
    REDIS: {
        host: '127.0.0.1',
        port: 6379,
        password: '123456',

    },

    DBS: [
        {
            name: 'default',
            type: 'postgres',
            database: 'wid_db',
            host: '143.198.220.202',
            port: 5432,
            username: 'postgres',
            password: 'Abc@12345',
            entities: [join(__dirname, '../../entities/primary/**/**{.ts,.js}')],
            subscribers: [join(__dirname, '../../@subscribers/primary/**/**{.ts,.js}')],
            synchronize: true,
            logging: [
                "log",
                "error",
                "info",
                // "query"
            ],
        }
    ],
    CONNECTORS: {

    },
    GLOABL_CHAINS: [EvmChain.POLYGON, EvmChain.BSC, EvmChain.ETHEREUM, EvmChain.ARBITRUM],
    GMAIL_PASS: "vsxcrroptmdokmxn"
}

export default config;
