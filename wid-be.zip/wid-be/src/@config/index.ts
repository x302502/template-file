import { ConnectionOptions } from 'typeorm';
import { EvmChain } from "@moralisweb3/common-evm-utils";
import * as envs from './envs';

export interface IEnvConfig {
    NAME?: string,
    APP: {
        dirResource: string,
        requestTimeout: number,
        swaggerConfig: {
            rootPath: string,
            info: {
                title: string,
                description: string,
                version: string
            }
        },
        swaggerMerchantConfig: {
            rootPath: string,
            info: {
                title: string,
                description: string,
                version: string
            }
        }
    },
    CDN_URL: string,
    REDIS: {
        host: string, port: number, password?: string, prefix?: string, db?: number
    },
    DBS: ConnectionOptions[],
    CONNECTORS: {
    }
    GLOABL_CHAINS: EvmChain[],
    GMAIL_PASS: string
}

let envConfig: IEnvConfig = undefined;
export function configEnv(): IEnvConfig {
    if (envConfig) {
        return envConfig;
    }
    const envName = process.env.NODE_ENV || 'dev';
    const currentConfig = (envs)[envName];

    return {
        ...currentConfig,
        NAME: envName
    }
};

