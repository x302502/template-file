import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { MerchantApiKey } from "~/entities/primary";


@EntityRepository(MerchantApiKey)
export class MerchantApiKeyRepo extends PrimaryRepo<MerchantApiKey>{

}