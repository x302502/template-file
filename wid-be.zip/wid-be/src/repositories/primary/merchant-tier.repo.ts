import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { MerchantTier } from "~/entities/primary";


@EntityRepository(MerchantTier)
export class MerchantTierRepo extends PrimaryRepo<MerchantTier>{

}