import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { WidTransaction } from "~/entities/primary";


@EntityRepository(WidTransaction)
export class WidTransactionRepo extends PrimaryRepo<WidTransaction>{

}