import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { Store } from "~/entities/primary";


@EntityRepository(Store)
export class StoreRepo extends PrimaryRepo<Store>{

}