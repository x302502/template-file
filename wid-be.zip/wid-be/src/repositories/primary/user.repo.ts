import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { User } from "~/entities/primary";


@EntityRepository(User)
export class UserRepo extends PrimaryRepo<User>{

}