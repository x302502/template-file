import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { Merchant } from "~/entities/primary";


@EntityRepository(Merchant)
export class MerchantRepo extends PrimaryRepo<Merchant>{

}