import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { Country } from "~/entities/primary/country";


@EntityRepository(Country)
export class CountryRepo extends PrimaryRepo<Country>{

}