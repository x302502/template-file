import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { CampaignProgram } from "~/entities/primary/campaign-program";


@EntityRepository(CampaignProgram)
export class CampaignProgramRepo extends PrimaryRepo<CampaignProgram>{

}