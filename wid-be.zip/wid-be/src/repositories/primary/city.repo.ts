import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { City } from "~/entities/primary/city";


@EntityRepository(City)
export class CityRepo extends PrimaryRepo<City>{

}