import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { Address } from "~/entities/primary/address";


@EntityRepository(Address)
export class AddressRepo extends PrimaryRepo<Address>{

}