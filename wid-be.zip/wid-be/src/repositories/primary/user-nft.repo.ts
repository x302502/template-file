import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { UserNft } from "~/entities/primary";


@EntityRepository(UserNft)
export class UserNftRepo extends PrimaryRepo<UserNft>{

}