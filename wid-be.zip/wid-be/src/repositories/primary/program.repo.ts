import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { Program } from "~/entities/primary";


@EntityRepository(Program)
export class ProgramRepo extends PrimaryRepo<Program>{

}