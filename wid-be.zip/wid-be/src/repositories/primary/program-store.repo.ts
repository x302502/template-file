import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { ProgramStore} from "~/entities/primary";


@EntityRepository(ProgramStore)
export class ProgramStoreRepo extends PrimaryRepo<ProgramStore>{

}