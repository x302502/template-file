import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { UserAdmin } from "~/entities/primary";


@EntityRepository(UserAdmin)
export class UserAdminRepo extends PrimaryRepo<UserAdmin>{

}