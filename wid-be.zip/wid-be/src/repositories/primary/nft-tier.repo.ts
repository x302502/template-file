
import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { NftTier } from "~/entities/primary";


@EntityRepository(NftTier)
export class NftTierRepo extends PrimaryRepo<NftTier>{

}