import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { Campaign } from "~/entities/primary";


@EntityRepository(Campaign)
export class CampaignRepo extends PrimaryRepo<Campaign>{

}