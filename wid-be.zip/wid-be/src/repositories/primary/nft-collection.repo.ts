import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { NftCollection } from "~/entities/primary";


@EntityRepository(NftCollection)
export class NftCollectionRepo extends PrimaryRepo<NftCollection>{

}