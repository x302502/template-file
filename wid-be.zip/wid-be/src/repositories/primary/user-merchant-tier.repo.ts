import { EntityRepository } from "typeorm";
import { PrimaryRepo } from "../primary.repo";
import { UserMerchantTier } from "~/entities/primary";

@EntityRepository(UserMerchantTier)
export class UserMerchantTierRepo extends PrimaryRepo<UserMerchantTier>{

}