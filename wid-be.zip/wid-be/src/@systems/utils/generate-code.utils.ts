import { v4 } from 'uuid'

function uuidNoDash() {
    return v4().replace(/-/g, "").toUpperCase();
}


export default {
    uuidNoDash
}