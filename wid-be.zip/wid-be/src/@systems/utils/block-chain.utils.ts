

const compareAddress = (addressA: string, addressB: string) => {
    if (!addressA || !addressB) {
        return false;
    }
    return addressA.toLowerCase().trim() === addressB.toLowerCase().trim();
}


export default {
    compareAddress
}