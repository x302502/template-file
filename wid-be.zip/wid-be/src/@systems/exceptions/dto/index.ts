import { HttpException, HttpStatus } from "@nestjs/common";
import { ApiProperty } from "@nestjs/swagger";
import { ApiException } from "~/@core/dto";

export class BusinessException<T = any> extends ApiException<T> {
  constructor(message: string = "", businessCode: number = -1, errors: T = undefined) {
    super(message, HttpStatus.BAD_REQUEST, errors, "BUSINESS", businessCode)
  }
}
export class ValidateException extends HttpException {
  public messages: {
    [key: string]: string
  }
  constructor(messages: { [key: string]: string }, status: number) {
    super(JSON.stringify(messages), status);
    this.messages = messages
  }
}

export class SuccessVerifySuccessResponse {
  @ApiProperty()
  message: string = "Verify Email Success";
  @ApiProperty()
  isVerify: boolean = true;
}

export class SuccessVerifyFailResponse {
  @ApiProperty()
  message: string = "Verify Email Fail";
  @ApiProperty()
  isVerify: boolean = false;
}

export class SuccessForgotPasswordSuccessResponse {
  @ApiProperty()
  message: string = "Forgot Password Success";
}

export class FailForgotPasswordSuccessResponse {
  @ApiProperty()
  message: string = "Forgot Password Fail";
}

export class BusinessSuccessResponse<T = any> extends ApiException<T> {
  constructor(message: string = "", businessCode: number = -1, errors: T = undefined) {
    super(message, HttpStatus.OK, errors, "BUSINESS", businessCode)
  }
}