import { ArgumentMetadata, BadRequestException, Injectable, PipeTransform } from "@nestjs/common";
import { ValueTransformer } from "typeorm";

export const numberToBoolean = {
    from: (val: number) => {
        return !!val
    },
    to: (val: number) => val
}

// @Injectable()
export class RequiredPipe implements PipeTransform {
    transform(value: any, metadata: ArgumentMetadata) {
        const { data = '' } = metadata
        if (!value) {
            throw new BadRequestException(`${data} is required`);
        }
        return value;
    }
}

export class LowerCaseTransformer implements ValueTransformer {
    from(value: any) {
        if (typeof value === "string") {
            return value.toLowerCase();
        }
        return value;

    }
    to(value: string) {
        if (typeof value === "string") {
            return value.toLowerCase();
        }
        return value;
    }
}
