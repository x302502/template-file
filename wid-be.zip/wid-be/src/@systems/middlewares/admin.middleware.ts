

import { Injectable, NestMiddleware, UnauthorizedException } from '@nestjs/common';
import { Request, Response } from 'express';
import { RequestContext } from '~/@core/context';
import { BindRepo, BindService } from '~/@core/decorator';
import { KeyHeader, KeyAttribute } from '~/common/constants';
import { UserSessionDto } from '~/dto/auth.dto';
import { UserAdminRepo } from '~/repositories/primary';
import { AuthService, jwtService, memCacheService } from '~/services';

@Injectable()
export class AdminMiddleware implements NestMiddleware {

    @BindRepo(UserAdminRepo)
    private userAdminRepo: UserAdminRepo;

    @BindService('AuthService')
    private authService: AuthService;

    async use(req: Request, res: Response, next: Function) {
        console.log('--------AdminMiddleware-----------');
        try {
            const { headers = {} } = req;
            if (!headers || !headers[KeyHeader.authorization]) {
                throw new UnauthorizedException("[Auth]Unauthorized");
            }
            const accessTokenFull = headers[KeyHeader.authorization] as string;
            const accessToken = accessTokenFull.replace("Bearer", "").trim();
            const userPayload = jwtService.decode<UserSessionDto>(accessToken);

            if (!userPayload || !userPayload.payload) {
                throw new UnauthorizedException("[Auth]Unauthorized");
            }
            const { id, username = "" } = userPayload.payload;

            const user = await this.userAdminRepo.findOne(id);
            if (!user) {
                throw new UnauthorizedException("[Auth]Unauthorized");
            }
            const userSession = await this.authService.pipeUserSession(user);
            RequestContext.setAttribute(KeyAttribute.userSession, userSession)
            next();
        } catch (error) {
            console.log(`-------------------`);
            console.log(error);
            console.log(`-------------------`);
            next(new UnauthorizedException("[Auth]Unauthorized"));
        }
    }
}
