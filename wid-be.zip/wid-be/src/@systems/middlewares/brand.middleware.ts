

import { Injectable, NestMiddleware, UnauthorizedException } from '@nestjs/common';
import { Request, Response } from 'express';
import { RequestContext } from '~/@core/context';
import { BindRepo, BindService } from '~/@core/decorator';
import { KeyHeader, KeyAttribute } from '~/common/constants';
import { BrandSessionDto } from '~/dto/brand.dto';
import { MerchantRepo } from '~/repositories/primary';
import { BrandService, jwtService } from '~/services';

@Injectable()
export class BrandMiddleware implements NestMiddleware {

    @BindRepo(MerchantRepo)
    private merchantRepo: MerchantRepo;

    @BindService('BrandService')
    private brandService: BrandService;

    async use(req: Request, res: Response, next: Function) {
        console.log('--------BrandMiddleware-----------');
        try {
            const { headers = {} } = req;
            if (!headers || !headers[KeyHeader.authorization]) {
                throw new UnauthorizedException("[Auth]Unauthorized");
            }
            const accessTokenFull = headers[KeyHeader.authorization] as string;
            const accessToken = accessTokenFull.replace("Bearer", "").trim();
            const brandPayload = jwtService.decode<BrandSessionDto>(accessToken);

            if (!brandPayload || !brandPayload.payload) {
                throw new UnauthorizedException("[Auth]Unauthorized");
            }
            const { id, email = "" } = brandPayload.payload;

            const brand = await this.merchantRepo.findOne(id);
            if (!brand) {
                throw new UnauthorizedException("[Auth]Unauthorized");
            }
            const brandSession = await this.brandService.pipeBrandSession(brand);
            RequestContext.setAttribute(KeyAttribute.merchantSession, brandSession)
            next();
        } catch (error) {

            next(new UnauthorizedException("[Auth]Unauthorized"));
        }
    }
}
