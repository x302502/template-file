import { RequestContext } from "~/@core/context";
import { KeyAttribute } from "~/common/constants";
import { UserSessionDto } from "~/dto/auth.dto";



export class ContextSession {
    get userSession() {
        return RequestContext.getAttribute<UserSessionDto>(KeyAttribute.userSession);
    }
    get accessToken() {
        return this.userSession.accessToken;
    }

    get userId() {
        return this.userSession.id;
    }


    get brandSession() {
        return RequestContext.getAttribute<UserSessionDto>(KeyAttribute.merchantSession);
    }
    get brandAccessToken() {
        return this.brandSession.accessToken;
    }

    get merchantId() {
        return this.brandSession.id;
    }
}

export const contextSession = new ContextSession();;