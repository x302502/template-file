import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response } from 'express';
import * as cls from 'cls-hooked';
import { RequestContext } from '~/@core/context';
@Injectable()
export class ContextMiddleware implements NestMiddleware {
    async use(req: Request, res: Response, next: Function) {
        console.log('----------ContextMiddleware---------');
        try {
            const requestContext = new RequestContext(req, res);
            const session = cls.getNamespace(RequestContext.nsid) || cls.createNamespace(RequestContext.nsid);
            await session.runPromise(async () => {
                session.set(RequestContext.name, requestContext);
            });
            next();
        } catch (error) {
            next();
        }
    }
}
