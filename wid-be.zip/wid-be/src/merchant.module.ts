import { DynamicModule, MiddlewareConsumer, Module, NestModule, RequestMethod } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import * as allModules from './x-modules/merchant';
import { configEnv } from './@config';
import { TechUtils } from './@core/utils';
import { AdminMiddleware, ContextMiddleware, LoggerMiddleware } from './@systems/middlewares';


const envConfig = configEnv()
// const multipleDatabaseModule: DynamicModule[] = TechUtils.dbModules(envConfig.DBS);
const modules = Object.values(allModules);

const actionModules = [
    ScheduleModule.forRoot()
]
@Module({
    imports: [
        // ...multipleDatabaseModule,
        ...actionModules,
        ...modules
    ]
})
export class MerchantModule implements NestModule {
    configure(consumer: MiddlewareConsumer) {
        consumer
            .apply(ContextMiddleware, LoggerMiddleware)
            .forRoutes({ path: "*", method: RequestMethod.ALL })
    }
}

