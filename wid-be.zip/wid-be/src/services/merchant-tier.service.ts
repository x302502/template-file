import { BindRepo, DefTransaction, Service } from "~/@core/decorator";
import { BusinessException } from "~/@systems/exceptions";
import { contextSession } from "~/@systems/middlewares";
import { SuccessResponse } from "~/@systems/utils";
import { EMerchantTierStatus } from "~/common/enums/EMerchantTierStatus";
import { EMerchantTierType } from "~/common/enums/EMerchantTierType";
import { UUIDReq } from "~/dto/@common";
import { ConfigRankDto } from "~/dto/config-rank.dto";
import { CreateMerchantTierReq, ListMerchantTierCampaignDto, ListMerchantTierDto, MerchantTierDto, MerchantTierProgramDto, UpdateMerchantTierReq } from "~/dto/merchant-tier/merchant-tier.dto";
import { ListMerchantTierByUserReq, WalletAddressReq } from "~/dto/user.dto";
import { MerchantTier } from "~/entities/primary";
import { UserMerchantTierRepo } from "~/repositories/primary";
import { MerchantTierRepo } from "~/repositories/primary/merchant-tier.repo";


@Service()
export class MerchantTierService {


    @BindRepo(MerchantTierRepo)
    private merchantTierRepo: MerchantTierRepo;

    @BindRepo(UserMerchantTierRepo)
    private userMerchantTierRepo: UserMerchantTierRepo;

    async createListMerchantTier(body: CreateMerchantTierReq) {
        const { contractAddress, name, configRank, chainId, type } = body;
        const { merchantId } = contextSession;

        for (const rank of configRank) {
            let merchantTier = new MerchantTier();
            merchantTier.name = name;
            merchantTier.contractAddress = contractAddress;
            merchantTier.chainId = chainId;
            merchantTier.merchantId = merchantId;
            merchantTier.type = type;
            merchantTier.status = EMerchantTierStatus.PENDING;
            merchantTier.icon = rank.icon;
            merchantTier.tierName = rank.tierName;
            merchantTier.minQuantity = rank.minQuantity;
            merchantTier.benefit = rank.benefit;
            merchantTier.description = rank.description;
            await this.merchantTierRepo.save(merchantTier);
        }
        return { merchantId };
    }

    async getListMerchantTier(body: MerchantTierDto) {
        let sql = ` select * from "merchant_tier" ORDER BY "createdDate" desc `
        return await this.merchantTierRepo.paginationQuery(sql, body);
    }

    async getListMerchantTierPublished() {
        let sql = ` select mt.*, mc."companyName" "merchantName"
        from "merchant_tier" mt
        INNER JOIN merchant mc on mc.id = mt."merchantId"
        ORDER BY mt."createdDate" desc `
        return await this.merchantTierRepo.query(sql);
    }

    async merchartTierByMerchant() {
        const { merchantId } = contextSession;
        let sql = ` SELECT * 
        FROM merchant_tier mt
        WHERE "merchantId" = '${merchantId}' `
        let data = await this.merchantTierRepo.query(sql);
        console.log(data);
        let merchantTier = {};
        let configRank = []
        if (data.length > 0) {
            merchantTier = data[0];
            for (const item of data) {
                console.log("item", item);
                configRank.push(item);
            }
        }
        return { ...merchantTier, configRank: configRank };
    }

    async merchartTierDetail(body: UUIDReq) {
        let sql = ` SELECT mt.*, mc."companyName" "merchantName"
        FROM merchant_tier mt
        INNER JOIN merchant mc on mc.id = mt."merchantId"
        WHERE mt."id" = '${body.id}' `
        let data = await this.merchantTierRepo.queryOne(sql);
        return data;
    }

    @DefTransaction()
    async updateMerchantTier(body: UpdateMerchantTierReq) {
        const { id, ...restBody } = body;
        const merchantTier = await this.merchantTierRepo.findOne(id);
        if (!merchantTier) {
            throw new BusinessException("Merchant Tier not existed")
        }
        return this.merchantTierRepo.save({
            ...merchantTier,
            ...restBody
        })
    }

    @DefTransaction()
    async deleteMerchantTier(id: string) {
        await this.merchantTierRepo.delete({ id: id });
        return new SuccessResponse();
    }

    async findMerchantTiersByIds(body: ListMerchantTierCampaignDto) {
        let sql = ` SELECT *
        FROM merchant_tier tiers 
        where id in ('${body.ids}') `;

        console.log(sql);
        let merchantTiers = await this.merchantTierRepo.paginationQuery(sql, body);
        console.log(merchantTiers);
        return merchantTiers;
    }

    async findByMerchantId(body: ListMerchantTierDto) {
        let sql = ` SELECT *
        FROM merchant_tier tiers 
        where "merchantId" = '${body.merchantId}' `;

        let merchantTiers = await this.merchantTierRepo.paginationQuery(sql, body);
        return merchantTiers;
    }

    async findByIds(body: MerchantTierProgramDto) {
        const ids = body.ids.join("','");
        let sql = ` SELECT tiers.*, mc."companyName" "merchantName"
        FROM merchant_tier tiers 
        inner join merchant mc on mc.id = tiers."merchantId"
        where tiers."id" in ('${ids}') `;

        let merchantTiers = await this.merchantTierRepo.query(sql);
        return merchantTiers;
    }

    listMerchantTierByUser(params: ListMerchantTierByUserReq) {
        const sql = `
                SELECT 
                    mt.*,
                    mc."companyName" as "merchantName"
                FROM  
                    user_merchant_tier umt
                INNER JOIN merchant_tier mt ON mt.id = umt."merchantTierId"
                INNER JOIN merchant mc ON mc.id = umt."merchantId"
                INNER JOIN "user" u ON u.id = umt."userId"
                WHERE u."walletAddress" = LOWER('${params.walletAddress}')
            `;
        return this.userMerchantTierRepo.paginationQuery(sql, params);
    }
}