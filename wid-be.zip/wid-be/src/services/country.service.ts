import { BindRepo, DefTransaction, Service } from "~/@core/decorator";
import { CountryRepo } from "~/repositories/primary/country.repo";
import { CountryDto } from "~/dto/country.dto";

@Service()
export class CountryService {

    @BindRepo(CountryRepo)
    private countryRepo: CountryRepo;

    listCountry() {
        const sql = `
            SELECT * FROM country 
        `
        return this.countryRepo.query(sql);
    }

}