import { BindRepo, Service } from "~/@core/decorator";
import { BusinessException } from "~/@systems/exceptions";
import { EUserTier } from "~/common/enums";
import { WalletAddressReq } from "~/dto/user.dto";
import { WidTransaction } from "~/entities/primary";
import { MerchantRepo, ProgramRepo, StoreRepo, UserNftRepo, UserRepo, WidTransactionRepo } from "~/repositories/primary";
import { CampaignRepo } from "~/repositories/primary/campaign.repo";





@Service()
export class ReportService {

    @BindRepo(MerchantRepo)
    private merchantRepo: MerchantRepo;

    @BindRepo(UserRepo)
    private userRepo: UserRepo;

    @BindRepo(StoreRepo)
    private storeRepo: StoreRepo;

    @BindRepo(ProgramRepo)
    private programRepo: ProgramRepo;

    @BindRepo(CampaignRepo)
    private campaignRepo: CampaignRepo;

    @BindRepo(UserNftRepo)
    private userNftRepo: UserNftRepo;

    @BindRepo(WidTransactionRepo)
    private widTransactionRepo: WidTransactionRepo;

    async summaryUser(params: WalletAddressReq) {
        const { walletAddress } = params;
        const user = await this.userRepo.findOne({
            where: {
                walletAddress: walletAddress.toLowerCase()
            }
        })
        if (!user) {
            throw new BusinessException("User not existed system")
        }
        const { tier, id } = user;
        const sqlNft = `
            SELECT 
                CAST( SUM (coalesce(nc."floorPrice",0)) as FLOAT) as "totalNftValue"
            FROM user_nft un
            LEFT JOIN nft_collection nc ON un.address = nc.address
                WHERE "owner" = LOWER('${walletAddress}')
        `;

        const sqlPromotionOffer = ` 
                SELECT CAST( count(*) as integer ) as total 
                FROM program 
                WHERE ${tier} = ANY("w3wTiers")
            `

        const sqlTransaction = ` 
            SELECT CAST( count(*) as integer ) as total 
            FROM wid_transaction 
            WHERE "userId" = '${id}'
        `

        const [
            totalNftValue,
            totalPromotionOffer,
            totalTransaction,
            totalNftMint,
        ] = await Promise.all([
            this.userNftRepo.queryOneOrFail(sqlNft)
                .then(({ totalNftValue }) => totalNftValue).catch(_ => 0),
            this.programRepo.queryOneOrFail(sqlPromotionOffer)
                .then(({ total }) => Number(total)).catch(_ => 0),
            this.widTransactionRepo.queryOneOrFail(sqlTransaction)
                .then(({ total }) => Number(total)).catch(_ => 0),
            (async () => 0)()
        ]);

        return {
            totalNftValue,
            totalPromotionOffer,
            totalTransaction,
            totalNftMint,
        }

    }
    async summarySystem() {
        const sqlCountry = ` 
            SELECT
                COUNT(DISTINCT (ar."countryCode")) as total
            FROM
                merchant mc 
            INNER JOIN address ar ON mc."addressId" = ar."id"
        `;
        const [
            totalCountry,
            totalPromotion,
            totalCampaign,
            totalStore,
        ] = await Promise.all([
            this.programRepo.queryOneOrFail(sqlCountry)
                .then(({ total }) => Number(total)).catch(_ => 0),
            this.programRepo.count().catch(_ => 0),
            this.campaignRepo.count().catch(_ => 0),
            this.storeRepo.count().catch(_ => 0),
        ]);

        return {
            totalCountry,
            totalPromotion,
            totalCampaign,
            totalStore,
        }
    }

}