import { BindRepo, BindService, DefTransaction, Service } from "~/@core/decorator";
import { CreateCampaignReq, UpdateCampaignReq } from "~/dto/brand.dto";
import generateCodeUtils from "~/@systems/utils/generate-code.utils";
import { contextSession } from "~/@systems/middlewares";
import { CampaignRepo } from "~/repositories/primary/campaign.repo";
import { BusinessException } from "~/@systems/exceptions";
import { UUIDReq } from "~/dto/@common";
import { PageResponse, SuccessResponse } from "~/@systems/utils";
import { EMerchantType } from "~/common/enums/EMerchantType";
import { MerchantRepo, UserMerchantTierRepo, UserRepo } from "~/repositories/primary";
import { EProgramStatus } from "~/common/enums/EProgramStatus";
import { getKeyEnumByValue } from "~/@systems/utils/common.utils";
import { ListCampaignReq, ListMerchantCampaignReq, ListProgramCampaignReq } from "~/dto/campaign/campaign.dto";
import { Campaign } from "~/entities/primary";
import { MerchantTierService } from "./merchant-tier.service";
import { ListCampaignProgramDto, ListProgramPublishedReq } from "~/dto/program/program.dto";
import { EMerchantStatus, ERequestStatus, EUserTier } from "~/common/enums";
import { StoreService } from "./store.service";

@Service()
export class CampaignService {



    @BindRepo(CampaignRepo)
    private campaignRepo: CampaignRepo;

    @BindRepo(UserMerchantTierRepo)
    private userMerchantTierRepo: UserMerchantTierRepo;


    @BindRepo(UserRepo)
    private userRepo: UserRepo;

    @BindRepo(MerchantRepo)
    private merchantRepo: MerchantRepo;

    @BindService("MerchantTierService")
    private merchantTierService: MerchantTierService;

    @BindService("StoreService")
    private storeService: StoreService;

    @DefTransaction()
    async createCampaign(body: CreateCampaignReq) {
        let merchant = await this.merchantRepo.findOne(contextSession.merchantId);
        if (!merchant) throw new BusinessException("Merchant account not exist");
        if (!merchant && merchant.type != EMerchantType.MERCHART) throw new BusinessException("No permission to create campaign");
        return this.campaignRepo.save({
            ...body,
            status: EProgramStatus.DRAFT,
            merchantId: contextSession.merchantId,
            code: generateCodeUtils.uuidNoDash()
        })
    }

    async requestPublishCampaign(body: UUIDReq) {
        let campaign = await this.campaignRepo.findOne(body.id);
        if (!campaign) throw new BusinessException("Campaign not exist");
        if (campaign && campaign.status != EProgramStatus.DRAFT) throw new BusinessException("Your campaign status is invalid for publishing.");
        let merchant = await this.merchantRepo.findOne(contextSession.merchantId);
        if (!merchant) throw new BusinessException("Merchant account not exist");
        if (!merchant && merchant.type != EMerchantType.WEB3PROJECT) throw new BusinessException("No permission to create campaign");
        if (merchant.id != campaign.merchantId) throw new BusinessException("You do not own this campaign");
        campaign.status = EProgramStatus.REQUEST_PUBLISHED;
        return await this.campaignRepo.save(campaign);
    }

    async verifyCampaign(body: UUIDReq) {
        const campaign = await this.campaignRepo.findOne(body.id);
        if (!campaign) {
            throw new BusinessException("Campaign not existed");
        }

        if (campaign.status > EProgramStatus.REQUEST_PUBLISHED) {
            throw new BusinessException(`Campaign is ${getKeyEnumByValue(EProgramStatus, campaign.status)}`);
        }
        campaign.status = EProgramStatus.PUBLISHED;

        return await this.campaignRepo.save(campaign);
    }

    async rejectRequestCampaign(body: UUIDReq) {
        const campaign = await this.campaignRepo.findOne(body.id);
        if (!campaign) throw new BusinessException("Campaign not exist");
        campaign.status = EProgramStatus.REJECT;
        return await this.campaignRepo.save(campaign);
    }

    listByMerchant(params: ListCampaignReq) {
        const { merchantId } = contextSession;
        const sql = `
            SELECT * FROM campaign 
            where "merchantId" = '${merchantId}'
            ORDER BY "createdDate" DESC
        `
        return this.campaignRepo.paginationQuery<Campaign>(sql, params);
    }

    @DefTransaction()
    async updateCampaign(body: UpdateCampaignReq) {
        const { id, ...restBody } = body;
        const campaign = await this.campaignRepo.findOne(id);
        if (!campaign) {
            throw new BusinessException("Campaign not existed")
        }
        return this.campaignRepo.save({
            ...campaign,
            ...restBody
        })
    }


    campaignDetail(params: UUIDReq) {
        return this.campaignRepo.findOne(params.id);
    }

    @DefTransaction()
    async deleteCampaign(id: string) {
        await this.campaignRepo.delete({ id: id });
        return new SuccessResponse();
    }

    // api public for user
    listCampaignPublished(params: ListCampaignReq) {
        const sql = `SELECT cam.*, mc."companyName" "merchantName"
            FROM campaign cam
            inner join merchant mc on mc.id = cam."merchantId"
            where cam."status" = '${EProgramStatus.PUBLISHED}'
            ORDER BY cam."createdDate" DESC
        `
        return this.campaignRepo.paginationQuery<Campaign>(sql, params);
    }

    async getDetailCampaign(body: UUIDReq) {
        const sql = ` SELECT cam.*, mc."companyName" "merchantName"
        FROM campaign cam
        INNER JOIN merchant mc on mc.id = cam."merchantId"
        where cam.id = '${body.id}'
        ORDER BY cam."createdDate" desc `;

        const campaign = await this.campaignRepo.queryOne(sql);
        if (!campaign) {
            throw new BusinessException("Campaign not existed")
        }

        const numberStores = await this.countStoreOfCampaign(body.id);
        Object.assign(campaign, {
            numberStores: numberStores,
            numberOfCountries: 1,
            numberOfCities: 1
        })
        console.log(campaign);

        return campaign;
    }

    async listProgramByCampaign(body: ListProgramCampaignReq) {
        const { walletAddress } = body;
        let tier = EUserTier.NONTIER;

        let userMerchantTierIds = [];
        if (walletAddress) {
            const user = await this.userRepo.findOne({
                where: {
                    walletAddress: walletAddress.toLowerCase()
                }
            })
            if (user) {
                tier = user.tier;
                const userMerchantTiers = await this.userMerchantTierRepo.find({
                    select: ["merchantTierId"],
                    where: {
                        userId: user.id
                    }
                });
                if (userMerchantTiers) {
                    userMerchantTierIds = userMerchantTiers.map(v => v.merchantTierId);
                }
            }
        }

        let selectCanJoin = `
            ${tier} = ANY(pro."w3wTiers") 
        `;

        if (userMerchantTierIds.length > 0) {
            selectCanJoin += ` OR ${userMerchantTierIds.map(merchantTierId => `'${merchantTierId}' = ANY(pro."merchantTiers")`).join(" OR ")}`
        }

        let sql = ` SELECT pro.*, mc."companyName" "merchantName",
        ( ${selectCanJoin} ) as "canJoin"
        FROM (select * from campaign_program where "campaignId" = '${body.campaignId}' and status = ${ERequestStatus.APPLY}) cp
        INNER JOIN program pro on pro."id" = cp."programId"
        INNER JOIN merchant mc on mc.id = pro."merchantId"
        ORDER BY pro."createdDate" desc `;

        let programs = await this.campaignRepo.paginationQuery(sql, body);
        return programs;
    }

    async listMerchantTiersByCampaign(body: ListProgramCampaignReq) {
        const sql = ` SELECT cam.*, mc."companyName" "merchantName"
        FROM campaign cam
        INNER JOIN merchant mc on mc.id = cam."merchantId"
        where cam.id = '${body.campaignId}'
        ORDER BY cam."createdDate" desc `;

        const campaign = await this.campaignRepo.queryOne(sql);
        if (!campaign) {
            throw new BusinessException("Campaign not existed")
        }

        if (campaign.merchantTiers.length > 0) {
            const ids = campaign.merchantTiers.join("','");
            const { data } = await this.merchantTierService.findMerchantTiersByIds({ ...body, ids });
            Object.assign(campaign, { merchantTiers: data })
        }

        return campaign;
    }

    async listByMerchantId(params: ListMerchantCampaignReq) {
        const { merchantId } = params;
        const merchant = await this.merchantRepo.findOne(merchantId);
        let sql = '';
        if (merchant.type == EMerchantType.WEB3PROJECT) {
            sql = `
                SELECT cam.*, mc."companyName" "merchantName"
                FROM campaign cam
                inner join merchant mc on mc.id = cam."merchantId"
                where cam."merchantId" = '${merchantId}'
                GROUP BY cam."id", mc."companyName"
                ORDER BY cam."createdDate" DESC
            `
        } else {
            sql = `
                SELECT cam.*, mc."companyName" "merchantName"
                FROM campaign cam
                INNER JOIN campaign_program cp on cp."campaignId" = cam."id"
                INNER JOIN program pro on cp."programId" = pro."id"
                INNER JOIN merchant mc on pro."merchantId" = mc."id"
                WHERE mc."id" = '${params.merchantId}'
                GROUP BY cam."id", mc."companyName"
                ORDER BY cam."createdDate" DESC
            `
        }
        console.log(sql);
        
        return await this.campaignRepo.paginationQuery<Campaign>(sql, params);
    }

    list(params: ListCampaignReq) {
        const sql = `
        SELECT
            cp.*,
            mc."companyName" "merchantName",
            to_json ( mc.* ) AS merchant,
            COALESCE ( json_agg ( mt.* ) FILTER ( WHERE mt.ID IS NOT NULL ), '[]' ) AS "listMerchantTier" 
        FROM
            campaign cp
            INNER JOIN merchant mc ON cp."merchantId" = mc.id
            LEFT JOIN merchant_tier mt ON mt."id" = ANY ( cp."merchantTiers" ) 
        GROUP BY
            cp."id",
            mc.ID 
        ORDER BY
            "createdDate" DESC
        `
        return this.campaignRepo.paginationQuery(sql, params);
    }


    async suspendCampaign(body: UUIDReq) {
        const campaign = await this.campaignRepo.findOne(body.id);
        if (!campaign) {
            throw new BusinessException("Campaign not exist");
        }
        campaign.status = EProgramStatus.SUSPENDED;
        return this.campaignRepo.save(campaign);
    }



    async listPublished(body: ListProgramPublishedReq) {
        try {
            const { walletAddress } = body;
            let tier = EUserTier.NONTIER;
            if (walletAddress) {
                const user = await this.userRepo.findOne({
                    where: {
                        walletAddress: walletAddress.toLowerCase()
                    }
                })
                if (user) {
                    tier = user.tier;
                }
            }

            let sql = `
                SELECT cam."id", cam.banner, cam.cover, cam.logo, cam."name",
                mc."companyName" "merchantName",
                ${tier} = ANY(cam."w3wTiers") as "canJoin"
                FROM campaign cam
                inner join merchant mc on mc.id = cam."merchantId"
                where cam."status" = '${EProgramStatus.PUBLISHED}' `

            sql += ` ORDER BY cam."startTime" ASC `


            console.log(`-------------------`);
            console.log(sql);
            console.log(`-------------------`);

            return this.campaignRepo.paginationQuery(sql, body);
        } catch (error) {
            return new PageResponse();
        }
    }

    async countStoreOfCampaign(id: string) {
        let sql = ` SELECT CAST( count(*) as integer ) as count
        FROM campaign cam
        INNER JOIN campaign_program cp on cp."campaignId" = cam."id"
        INNER JOIN program pro on cp."programId" = pro."id"
        INNER JOIN program_store ps on ps."programId" = pro."id"
        INNER JOIN store st on ps."storeId" = st."id"
        WHERE cam.id = '${id}' 
        group by cam.id `
        let { count } = await this.campaignRepo.queryOne(sql) || { count: 0 };
        return count;
    }

    async listPublishedForUser(body: ListCampaignProgramDto) {
        try {
            let sql = `
                SELECT cam.*, 
                mc."companyName" "merchantName", mc.logo "merchantLogo",
                cp."noOfProgram"
                
                FROM campaign cam
                inner join merchant mc on mc.id = cam."merchantId"
                left JOIN (
                    SELECT count(*) as "noOfProgram", cam."id"
                    FROM campaign cam
                    INNER JOIN campaign_program cp on cp."campaignId" = cam."id"
                    WHERE cp.status = ${ERequestStatus.APPLY}
                    GROUP BY cam."id"
                ) as cp on cp."id" = cam."id"
                where cam."status" = '${EProgramStatus.PUBLISHED}' `

            sql += ` ORDER BY cam."createdDate" DESC `

            return this.campaignRepo.paginationQuery(sql, body);
        } catch (error) {
            return new PageResponse();
        }
    }
}