import { configEnv } from "~/@config";
import { BindRepo, DefTransaction, Service } from "~/@core/decorator";
import { ListNftReq, NftByAddress } from "~/dto/nft.dto";
import { WalletAddressReq } from "~/dto/user.dto";
import moralisConnector from "./@common/moralis.connector";
import { optionalApiService } from "./@common";
import { NftCollection, UserNft } from "~/entities/primary";
import { NftCollectionRepo, UserNftRepo } from "~/repositories/primary";
import coingeckoConnector, { ICoingeckoNftInfo } from "./@common/coingecko.connector";
import { In } from "typeorm";
import { EUserTier } from "~/common/enums";


const { GLOABL_CHAINS } = configEnv();


const FAM_NFT_ADDRESS = "0x2bb0a6fd9336470c75D15ca751D40afb657f358F".toLowerCase();

@Service()
export class NftService {

    @BindRepo(UserNftRepo)
    private userNftRepo: UserNftRepo;

    @BindRepo(NftCollectionRepo)
    private nftCollectionRepo: NftCollectionRepo

    listNf(params: ListNftReq) {
        const { walletAddress } = params;
        const sql = `
            SELECT * FROM user_nft 
            WHERE owner = LOWER('${walletAddress}')
            ORDER BY "createdDate" DESC
        `
        return this.userNftRepo.paginationQuery(sql, params);
    }



    @DefTransaction()
    async synNftByWalletAddress(body: WalletAddressReq) {
        try {
            console.log(`-------------------`);
            console.log(Object.values(GLOABL_CHAINS).map(v => v.display()));
            console.log(`-------------------`);
            const { walletAddress } = body;
            const resList = await moralisConnector.listNftByAddress({ address: walletAddress, chains: GLOABL_CHAINS });
            const list = resList.filter(v => v.tokenUri);
            const getMetadataByTokenUri = async (input: NftByAddress) => {
                const checkUrlImage = (url: string) => {
                    return Boolean(url.match(/\.(jpeg|jpg|gif|png)$/));
                }
                if (checkUrlImage(input.tokenUri)) {
                    return {
                        ...input,
                        image: input.tokenId
                    }
                }
                if (input.metadata && input.metadata.image) {
                    return {
                        ...input,
                        image: input.metadata.image,
                        description: input.metadata?.description || "",
                    }
                }
                try {
                    const res = await optionalApiService.get(input.tokenUri);
                    const { description, image, data, name: nameMetadata } = res;
                    return {
                        ...input,
                        name: nameMetadata || name,
                        description: description ? description : (data.description || ""),
                        image: image ? image : (data.image || ""),
                    }
                } catch (error) {
                    return undefined
                }
            }
            const promises = [];

            for (const item of list) {
                promises.push(getMetadataByTokenUri(item))
            }
            const result = await Promise.all(promises);

            const dataInserts: NftByAddress[] = result.filter(v => v && v.name);


            const mapData = dataInserts.map(({ address, chainId }) => ({ address, chainId }))
                .byMap(["address"]);

            const promisesNft = [];

            Object.values(mapData).forEach(item => {
                promisesNft.push(
                    coingeckoConnector.getNftInfoByAddress({ address: item.address, chainId: item.chainId })
                        .catch(err => {
                            //console.error(err)
                            return undefined;
                        })
                )
            })

            const dataRes = await Promise.all(promisesNft);

            const dataCollection: ICoingeckoNftInfo[] = dataRes.filter(v => v);

            let maxPrice = 0;
            if (dataCollection.length > 0) {
                maxPrice = Math.max(...dataCollection.map(v => v.floorPrice))
                await this.nftCollectionRepo.delete({
                    address: In(dataCollection.map(v => v.address.toLowerCase()))
                })

                await this.nftCollectionRepo.insert(dataCollection);
            }

            const resDel = await this.userNftRepo.delete({
                owner: walletAddress.toLowerCase()
            });
            await this.userNftRepo.insert(dataInserts);

            return {
                maxPrice,
                totalQtyNft: dataInserts.reduce((acc, item) => {
                    acc += item.amount;
                    return acc;
                }, 0),
                specialTier: Object.keys(mapData).map(key => key.toLowerCase())
                    .includes(FAM_NFT_ADDRESS)
            }

        } catch (error) {
            return {
                maxPrice: 0
            }
        }
    }

    async listNfSummary(params: WalletAddressReq) {
        const sql = `
            SELECT * FROM (
                SELECT 
                    "name",address,CAST( SUM(amount) as integer ) as amount 
                FROM user_nft 
                    WHERE "owner" = LOWER('${params.walletAddress}')
                GROUP BY "name",address
            ) tmp 
            ORDER BY "amount" DESC
        `

        const data: UserNft[] = await this.userNftRepo.query(sql);

        const sqlTotal = `
            SELECT 
                CAST( SUM(un.amount) as integer ) as "totalAmount",
                CAST( SUM (coalesce(nc."floorPrice",0)) as FLOAT) as "totalWorths"
            FROM user_nft un
            LEFT JOIN nft_collection nc ON un.address = nc.address
                WHERE "owner" = LOWER('${params.walletAddress}')
        `
        const { totalAmount = 0, totalWorths = 0 } = await this.userNftRepo.queryOne(sqlTotal) || { totalAmount: 0, totalWorths: 0 };

        return {
            data,
            totalAmount: totalAmount || 0,
            totalWorths: totalWorths || 0
        }
    }

}