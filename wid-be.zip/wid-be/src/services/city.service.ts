import { BindRepo, DefTransaction, Service } from "~/@core/decorator";
import { CityDto } from "~/dto/city.dto";
import { CityRepo } from "~/repositories/primary/city.repo";

@Service()
export class CityService {

    @BindRepo(CityRepo)
    private cityRepo: CityRepo;

    listCityByCountryCode(params: CityDto) {
        const sql = `
            SELECT * FROM city 
            where "countryCode" = '${params.countryCode}'
            ORDER BY "createdDate" DESC
        `
        return this.cityRepo.query(sql);
    }

}