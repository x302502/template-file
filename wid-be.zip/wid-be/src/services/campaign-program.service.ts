import { BindRepo, BindService, DefTransaction, Service } from "~/@core/decorator";
import { BusinessException } from "~/@systems/exceptions";
import { contextSession } from "~/@systems/middlewares";
import { EProgramStatus } from "~/common/enums/EProgramStatus";
import { EProgramType } from "~/common/enums/EProgramType";
import { ERequestStatus } from "~/common/enums/ERequestStatus";
import { ERequestType } from "~/common/enums/ERequestType";
import { UUIDReq } from "~/dto/@common";
import { ListCampaignProgramDto, ListRequestProgramDto, RequestProgramDto } from "~/dto/program/program.dto";
import { CampaignProgram } from "~/entities/primary/campaign-program";
import { ProgramRepo } from "~/repositories/primary";
import { CampaignProgramRepo } from "~/repositories/primary/campaign-program.repo";
import { CampaignRepo } from "~/repositories/primary/campaign.repo";


@Service()
export class CampaignProgramService {

    @BindRepo(CampaignProgramRepo)
    private campaignProgramRepo: CampaignProgramRepo;

    @BindRepo(CampaignRepo)
    private campaignRepo: CampaignRepo;

    @BindRepo(ProgramRepo)
    private programRepo: ProgramRepo;

    @DefTransaction()
    async createCampaignInviteProgram(body: RequestProgramDto) {
        const { campaignId, programId } = body;
        let programRequest = await this.campaignProgramRepo.findOne({
            programId: body.programId,
            campaignId: body.campaignId
        });
        if (programRequest) {
            throw new BusinessException("You have received a request from this program");
        }
        const campaign = await this.campaignRepo.findOne(campaignId);
        if (campaign.status !== EProgramStatus.PUBLISHED) {
            throw new BusinessException("Campaign is not published yet");
        }
        const program = await this.programRepo.findOne(programId);
        if (program.status !== EProgramStatus.PUBLISHED) {
            throw new BusinessException("Program is not published yet");
        }

        let isProgramValid = await this.checkProgramValid(body.programId);
        if (!isProgramValid) {
            throw new BusinessException("You have invited in the program before.");
        }
        let campaignInvite = new CampaignProgram();
        campaignInvite.campaignId = campaignId;
        campaignInvite.programId = programId;
        campaignInvite.status = ERequestStatus.NOT_APPLY;
        campaignInvite.type = ERequestType.CAMPAIGN_INVITE;
        campaignInvite = await this.campaignProgramRepo.save(campaignInvite);
        return campaignInvite;
    }

    @DefTransaction()
    async createProgramRequestCampaign(body: RequestProgramDto) {
        const { campaignId, programId } = body;
        let campaignInvite = await this.campaignProgramRepo.findOne({
            programId: body.programId,
            campaignId: body.campaignId
        });
        const campaign = await this.campaignRepo.findOne(campaignId);
        if (campaign.status !== EProgramStatus.PUBLISHED) {
            throw new BusinessException("Campaign is not published yet");
        }
        const program = await this.programRepo.findOne(programId);
        if (program.status !== EProgramStatus.PUBLISHED) {
            throw new BusinessException("Program is not published yet");
        }
        if (campaignInvite) {
            throw new BusinessException("You have received an invitation from this campaign");
        }

        let isProgramValid = await this.checkProgramValid(body.programId);
        if (!isProgramValid) {
            throw new BusinessException("You have participated in the campaign before.");
        }
        let programRequest = new CampaignProgram();
        programRequest.campaignId = campaignId;
        programRequest.programId = programId;
        programRequest.status = ERequestStatus.NOT_APPLY;
        programRequest.type = ERequestType.PROGRAM_REQUEST;
        programRequest = await this.campaignProgramRepo.save(body);
        return programRequest;
    }

    async checkProgramValid(programId: string) {
        const campaignPrograms = await this.campaignProgramRepo.find({
            programId: programId
        });
        let isValid = true;
        for (const cp of campaignPrograms) {
            if (cp.status != ERequestStatus.REJECT) {
                return false;
            }
        }
        return isValid;
    }

    async findCampaignInvte(body: RequestProgramDto) {
        let campaignInvite = await this.campaignProgramRepo.findOne({
            programId: body.programId,
            campaignId: body.campaignId,
            type: ERequestType.CAMPAIGN_INVITE
        });
        if (!campaignInvite) throw new BusinessException("Request campaign not existed");

        return campaignInvite;
    }

    async findProgramRequest(body: RequestProgramDto) {
        let programRequest = await this.campaignProgramRepo.findOne({
            programId: body.programId,
            campaignId: body.campaignId,
            type: ERequestType.PROGRAM_REQUEST
        });
        if (!programRequest) throw new BusinessException("Request campaign not existed");

        return programRequest;
    }

    async getAcceptProgramRequest(body: ListRequestProgramDto) {
        const { merchantId } = contextSession;
        // console.log("id", body.id);
        // let merchantId = '4e0bc301-ec82-47b8-912f-c01d92ef4f55';
        let sql = ` select mc."companyName" "merchantName", mc.id "merchantId",
        cam.name "campaignName", cam."startTime", cam."endTime", cam.id "campaignId",
        pro.name "programName", pro.code "programCode", pro."programType", pro."startTime", pro."endTime", pro.id "programId",
        req.status "applyStatus"
        from merchant mc
        inner join campaign cam on cam."merchantId" = mc.id
        inner join (select * from campaign_program where type = '${ERequestType.PROGRAM_REQUEST}' ) req on req."campaignId" = cam.id
        inner join program pro on req."programId" = pro.id
        where mc.id = '${merchantId}' and cam.id = '${body.id}' `
        console.log(sql);
        let acceptProgramList = await this.campaignProgramRepo.paginationQuery(sql, body);

        return acceptProgramList;
    }

    async getListAcceptProgramRequest(body: ListCampaignProgramDto) {
        const { merchantId } = contextSession;
        // console.log("id", body.id);
        // let merchantId = '4e0bc301-ec82-47b8-912f-c01d92ef4f55';
        let sql = ` select mc."companyName" "merchantName", mc.id "merchantId",
        cam.name "campaignName", cam."startTime" "campaignStartTime", cam."endTime" "campaignEndTime", cam.id "campaignId",
        pro.name "programName", pro.code "programCode", pro."programType", pro."startTime" "programStartTime", pro."endTime" "programEndTime", pro.id "programId",
        req.status "applyStatus", req."createdDate"
        from (select * from campaign_program where type = '${ERequestType.PROGRAM_REQUEST}' ) req
        inner join program pro on req."programId" = pro.id
        INNER JOIN merchant mc on mc.id = pro."merchantId"
        inner join campaign cam on cam.id = req."campaignId"
        where 1=1 and cam."merchantId" = '${merchantId}' 
        ORDER BY req."createdDate" DESC `
        console.log(sql);
        let acceptProgramList = await this.campaignProgramRepo.paginationQuery(sql, body);

        return acceptProgramList;
    }

    async getAcceptCampaignInvite(body: ListRequestProgramDto) {
        const { merchantId } = contextSession;
        let sql = ` select mc."companyName" "merchantName", mc.id "merchantId",
        cam.name "campaignName", cam."startTime", cam."endTime", cam.id "campaignId",
        pro.name "programName", pro.code "programCode", pro."programType", pro."startTime", pro."endTime", pro.id "programId",
        invite.status "applyStatus"
        from merchant mc
        inner join program pro on pro."merchantId" = mc.id
        inner join (select * from campaign_program where type = '${ERequestType.CAMPAIGN_INVITE}' ) invite on invite."programId" = pro.id
        inner join campaign cam on cam.id = invite."campaignId"
        where mc.id = '${merchantId}' and pro.id = '${body.id}' `

        let campaignInviteList = await this.campaignProgramRepo.paginationQuery(sql, body);
        console.log(sql);

        return campaignInviteList;
    }

    async getListAcceptCampaignInvite(body: ListCampaignProgramDto) {
        const { merchantId } = contextSession;
        let sql = ` select mc."companyName" "merchantName", mc.id "merchantId",
        cam.name "campaignName", cam."startTime" "campaignStartTime", cam."endTime" "campaignEndTime", cam.id "campaignId",
        pro.name "programName", pro.code "programCode", pro."programType", pro."startTime" "programStartTime", pro."endTime" "programEndTime", pro.id "programId",
        invite.status "applyStatus", invite."createdDate"
        from (select * from campaign_program where type = '${ERequestType.CAMPAIGN_INVITE}' ) invite
        INNER JOIN campaign cam on cam.id = invite."campaignId"
        INNER JOIN merchant mc on mc.id = cam."merchantId"
        inner join program pro on pro.id = invite."programId"
        where 1=1 and pro."merchantId" = '${merchantId}'
        ORDER BY invite."createdDate" DESC
         `

        let campaignInviteList = await this.campaignProgramRepo.paginationQuery(sql, body);
        console.log(sql);

        return campaignInviteList;
    }

    async acceptProgramRequest(body: RequestProgramDto) {
        let programRequest = await this.campaignProgramRepo.findOne({
            programId: body.programId,
            campaignId: body.campaignId,
            type: ERequestType.PROGRAM_REQUEST,
            status: ERequestStatus.NOT_APPLY
        });
        if (!programRequest) throw new BusinessException("Request program not existed");
        programRequest.status = ERequestStatus.APPLY;
        programRequest = await this.campaignProgramRepo.save(programRequest);
        let program = await this.programRepo.findOne(programRequest.programId);
        if (program.type == EProgramType.UNDER_CAMPAIGN) {
            let campaign = await this.campaignRepo.findOne(programRequest.campaignId);
            program.w3wTiers = campaign.w3wTiers;
            program.merchantTiers = campaign.merchantTiers;
            await this.programRepo.save(program);
        }
        return programRequest;
    }

    async rejectProgramRequest(body: RequestProgramDto) {
        let programRequest = await this.campaignProgramRepo.findOne({
            programId: body.programId,
            campaignId: body.campaignId,
            type: ERequestType.PROGRAM_REQUEST
        });
        if (!programRequest) throw new BusinessException("Request program not existed");
        programRequest.status = ERequestStatus.REJECT;
        programRequest = await this.campaignProgramRepo.save(programRequest);
        return programRequest;
    }

    async acceptCampaignInvite(body: RequestProgramDto) {
        let campaignInvite = await this.campaignProgramRepo.findOne({
            programId: body.programId,
            campaignId: body.campaignId,
            type: ERequestType.CAMPAIGN_INVITE
        });
        if (!campaignInvite) throw new BusinessException("Campaign invite not existed");
        campaignInvite.status = ERequestStatus.APPLY;
        campaignInvite = await this.campaignProgramRepo.save(campaignInvite);
        return campaignInvite;
    }

    async rejectCampaignInvite(body: RequestProgramDto) {
        let campaignInvite = await this.campaignProgramRepo.findOne({
            programId: body.programId,
            campaignId: body.campaignId,
            type: ERequestType.CAMPAIGN_INVITE
        });
        if (!campaignInvite) throw new BusinessException("Campaign invite not existed");
        campaignInvite.status = ERequestStatus.REJECT;
        campaignInvite = await this.campaignProgramRepo.save(campaignInvite);
        return campaignInvite;
    }

    async getListProgramInCampaign(body: UUIDReq) {
        // const { merchantId } = contextSession;
        // console.log("id", body.id);
        // let merchantId = '4e0bc301-ec82-47b8-912f-c01d92ef4f55';
        let sql = ` SELECT cp."campaignId", pro.*, mc."companyName" "merchantName"
        FROM campaign_program cp
        INNER JOIN program pro on pro.id = cp."programId"
        INNER JOIN merchant mc on mc.id = pro."merchantId"
        WHERE cp."campaignId" = '${body.id}' and cp.status = ${ERequestStatus.APPLY} `
        console.log(sql);
        let acceptProgramList = await this.campaignProgramRepo.query(sql);

        return acceptProgramList;
    }

    async listAllCampaignByTiers(body: ListRequestProgramDto) {
        let program = await this.programRepo.findOne(body.id);
        if (!program) throw new BusinessException("Program not existed");

        const { merchantTiers, w3wTiers } = program;

        const sqlWhereMerchantTier = merchantTiers.map(merchantTierId => ` '${merchantTierId}' =  ANY(cam."merchantTiers") `);

        const sqlWhereW3wTier = w3wTiers.map(tier => `${tier} =   ANY(cam."w3wTiers")  `);

        const arr = sqlWhereMerchantTier.concat(sqlWhereW3wTier);

        let sql = '';

        let sql1 = ` 						
            SELECT mc."companyName" "merchantName", mc.id "merchantId",
            cam.name "campaignName", cam."startTime" "campaignStartTime", cam."endTime" "campaignEndTime", cam.id "campaignId",
                        cp.status as "applyStatus"
            FROM (SELECT * from campaign WHERE status = 2) cam
            INNER JOIN merchant mc on mc."id" = cam."merchantId"
            INNER JOIN (SELECT * FROM campaign_program WHERE "programId" = '${body.id}' and status in (1,2)) cp on cp."campaignId" = cam."id"
        `
        if (arr.length > 0 && program.type != 1) {
            sql1 += `AND ( ${arr.join(` OR `)} )`
        }
        console.log(sql1);
        sql1 += ` GROUP BY mc."name", mc."id", cam.name , cam."startTime" , cam."endTime" , cam.id, cp.status `;
        // sql1 += ` ORDER BY cam."createdDate" DESC `;

        let sql2 = ` SELECT mc."companyName" "merchantName", mc.id "merchantId",
        cam.name "campaignName", cam."startTime" "campaignStartTime", cam."endTime" "campaignEndTime", cam.id "campaignId",
        0 as "applyStatus"
        FROM (SELECT * from campaign WHERE status = 2) cam
        INNER JOIN merchant mc on mc."id" = cam."merchantId"
        WHERE cam."id" not in (
                SELECT cp."campaignId"
                FROM campaign_program cp
                WHERE "programId" = '${body.id}' and status in (1,2)
                GROUP BY cp."id"
        )
        `
        if (arr.length > 0 && program.type != 1) {
            sql2 += `AND ( ${arr.join(` OR `)} )`
        }
        console.log(sql2);
        sql2 += `  GROUP BY mc."name", mc."id", cam.name , cam."startTime" , cam."endTime" , cam.id `
        // sql2 += ` ORDER BY cam."createdDate" DESC `;

        sql = sql1 + ' UNION ' + sql2;

        console.log(sql);
        
        return this.campaignRepo.paginationQuery(sql, body);
    }

    async listAllProgramByTiers(body: ListRequestProgramDto) {
        let campaign = await this.campaignRepo.findOne(body.id);
        if (!campaign) throw new BusinessException("Campaign not existed");
        const { merchantTiers, w3wTiers } = campaign;

        const sqlWhereMerchantTier = merchantTiers.map(merchantTierId => ` '${merchantTierId}' =  ANY(pro."merchantTiers") `);

        const sqlWhereW3wTier = w3wTiers.map(tier => `${tier} =   ANY(pro."w3wTiers")  `);

        const sqlUnderCampaign = ` pro.type = 1 `;

        const arr = sqlWhereMerchantTier.concat(sqlWhereW3wTier, sqlUnderCampaign);

        let sql1 = ` 						
            SELECT mc."companyName" "merchantName", mc.id "merchantId",
            pro.name "programName", pro.code "programCode", pro."programType", pro."startTime" "programStartTime", pro."endTime" "programEndTime", pro.id "programId",
            cp.status as "applyStatus"
            FROM (SELECT * from program WHERE status = 2) pro
            INNER JOIN merchant mc on mc."id" = pro."merchantId"
            INNER JOIN (SELECT * FROM campaign_program WHERE "campaignId" = '${body.id}' and status in (1,2)) cp on cp."programId" = pro."id"
            WHERE 1=1 
        `
        if (arr.length > 0) {
            sql1 += `AND ( ${arr.join(` OR `)} )`
        }

        sql1 += ` GROUP BY mc."name", mc."id", pro.name, pro.code, pro."programType", pro."startTime" , pro."endTime" , pro.id, cp.status `;

        let sql2 = ` SELECT mc."companyName" "merchantName", mc.id "merchantId",
        pro.name "programName", pro.code "programCode", pro."programType", pro."startTime" "programStartTime", pro."endTime" "programEndTime", pro.id "programId",
        0 as "applyStatus"
        FROM (SELECT * from program WHERE status = 2) pro
        INNER JOIN merchant mc on mc."id" = pro."merchantId"
        WHERE pro."id" not in (
                SELECT cp."programId"
                FROM campaign_program cp
                WHERE status in (1,2)
                GROUP BY cp."id"
        )
        `
        if (arr.length > 0) {
            sql2 += `AND ( ${arr.join(` OR `)} )`
        }

        sql2 += `  GROUP BY mc."name", mc."id", pro.name, pro.code, pro."programType" , pro."startTime" , pro."endTime" , pro.id `
        
        let sql = sql1 + ' UNION ' + sql2;
        console.log(sql);
        
        return this.programRepo.paginationQuery(sql, body);
    }

    async listCampaignJoinedProgram(body: UUIDReq) {
        let sql = ` SELECT cp."campaignId", cam.*, mc."companyName" "merchantName", cam.name "campaignName"
        FROM campaign_program cp
        INNER JOIN campaign cam on cam.id = cp."campaignId"
        INNER JOIN merchant mc on mc.id = cam."merchantId"
        WHERE cp."programId" = '${body.id}' and cp.status = ${ERequestStatus.APPLY} `
        console.log(sql);
        let acceptProgramList = await this.campaignProgramRepo.query(sql);

        return acceptProgramList;
    }
}