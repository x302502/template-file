
import Moralis from "moralis";
import { EvmAddressish, EvmChain, Erc20Value, EvmNative, EvmChainish, GetWalletNFTsRequest } from "@moralisweb3/common-evm-utils";
import { NftByAddress } from "~/dto/nft.dto";
import { moralisApiService } from ".";
import { formatUnits } from "ethers/lib/utils";


const Enpoint = {
    getNftByAccount: '{{account}}/nft',
}
class MoralisConnector {
    async listNftByAddressV1(body: { address: string; chains: EvmChain[] }): Promise<NftByAddress[]> {
        const { address, chains = [] } = body
        let nfts = [];
        for (const chain of chains) {
            const path = Enpoint.getNftByAccount.replace('{{account}}', address).trim()
            const res = await moralisApiService.get(path, {
                chain: chain.hex,
                format: 'decimal',
            })
            const result: any[] = res?.result || []
            nfts = nfts.concat(result)
        }

        return nfts.map(item => {
            const {
                chainId,
                token_address: address,
                token_id: tokenId,
                owner_of: owner,
                amount,
                contract_type: contractType,
                name,
                symbol,
                token_uri: tokenUri,
                metadata
            } = item
            return {
                chainId,
                address,
                tokenId,
                owner,
                amount: Number(amount),
                contractType,
                name,
                symbol,
                tokenUri: tokenUri || '',
                metadata: JSON.parse(metadata || '{}')
            } as NftByAddress
        })


    }


    async listNftByAddress(body: { address: string; chains: EvmChain[] }): Promise<NftByAddress[]> {
        const { address, chains = [] } = body
        let nfts = [];
        for (const chain of chains) {
            const response = await Moralis.EvmApi.nft.getWalletNFTs({
                address,
                chain,
                format: 'decimal',
                limit: 100
            });
            const result = response.toJSON().result.map(v => ({ ...v, chainId: chain.decimal }))
            nfts = nfts.concat(result)
        }

        return nfts.map(item => {
            const {
                chainId,
                token_address: address,
                token_id: tokenId,
                owner_of: owner,
                amount,
                contract_type: contractType,
                name,
                symbol,
                token_uri: tokenUri,
                metadata
            } = item
            return {
                chainId,
                address,
                tokenId,
                owner,
                amount: Number(amount),
                contractType,
                name,
                symbol,
                tokenUri: tokenUri || '',
                metadata: JSON.parse(metadata || '{}')
            } as NftByAddress
        })


    }

    async getWalletTokenBalances({ walletAddress: address, chainId, listTokenAddress = [] }: { walletAddress: string; chainId: number, listTokenAddress?: EvmAddressish[]; }) {
        const response = await Moralis.EvmApi.token.getWalletTokenBalances({
            address,
            chain: chainId,
            tokenAddresses: listTokenAddress
        });

        const result = response.toJSON() || [];
        return result.map(({ token_address: tokenAddress, possible_spam: possibleSpam, balance: balanceBigNumber, decimals, ...reseItem }) => ({
            ...reseItem,
            chainId,
            tokenAddress,
            possibleSpam,
            balanceBigNumber,
            balance: Number.parseFloat(formatUnits(balanceBigNumber, decimals))
        }))
    }

    async getWalletNftBalances(body: { walletAddress: string; chainIds: number[], listNfAddress?: EvmAddressish[]; }) {
        const { walletAddress: address, chainIds = [], listNfAddress = undefined } = body
        let nfts = [];
        const where: GetWalletNFTsRequest = {
            address,
            format: 'decimal',
            mediaItems: false,
            limit: 100
        }
        if (listNfAddress) {
            Object.assign(where, {
                tokenAddresses: listNfAddress,
            })
        }
        for (const chain of chainIds) {
            const response = await Moralis.EvmApi.nft.getWalletNFTs({
                chain,
                ...where
            });
            const result = response.toJSON().result.map(v => ({ ...v, chainId: chain }))
            nfts = nfts.concat(result)
        }
        const res = nfts.map(item => {
            const {
                chainId,
                token_address: address,
                token_id: tokenId,
                amount,
            } = item
            return {
                chainId,
                address,
                tokenId,
                amount: Number(amount),
            }
        })

        const mapRes = res.byMapArrayJsonKey(["chainId", "address"])
        const result = Object.keys(mapRes).map(key => {
            const balance = mapRes[key].reduce((acc, item) => acc + Number(item.amount), 0);
            const { chainId, address } = JSON.parse(key);
            return {
                chainId: Number(chainId),
                tokenAddress: address,
                balance: Number(balance)
            }
        });
        return result;


    }
}

export default new MoralisConnector()