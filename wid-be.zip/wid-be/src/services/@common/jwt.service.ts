
import { JWTHelper } from "~/@core/helpers";

const config = {
    privateKey: `-----BEGIN RSA PRIVATE KEY-----
  MIICXQIBAAKBgQC8Q1SECYxtNztpsAzVf/U5VRdjrkrXF1zkjsAIHx0ORimu6Igy
  OFIYpo0XXESzfb0a8LJ2FA2Z/n6PjAQLDz6J+kcldL65Ev661mabEHu6zTYRLPrJ
  0AznEoX7Q7UQwwpbw9OiJXmXE7RbfrPmh1Lr736ofRRnO68fJsnvN/3GLQIDAQAB
  AoGBALBx7lE93cYywNViMfUb00qjrKM5JF2JQP/ZprM17faF3eVXfOaMkK0X1B6z
  1JPhYg5QzwIJ82GD+zwwf02aQQJW7Hfi9WfTZ1g7xLnKQ2eCPINwelG8AABO3LBX
  9/eMLhYGLcns/r3dTX7gUYHGJF2TrCmsj/urlsvn5yPyD32hAkEA3hGsG1tFr4wc
  bbOtw2DgHMDWMRlXAsJC7B9kVJiruqMxdU2d5yycUQnrCm2OvnjtNVWAnyhRUlem
  E0SFrxZ/OQJBANkHUgQDfeNUB0u9uCLzZO/3km3RPjpLLXWbIvhULtV5SCwW+iIU
  73lJH8UodqLgwaOo6ANK1OhkxkpgtxjZipUCQQCtlkjflYgygiaSxjpVGHv3XfHQ
  rYsrd+jSJHPMAQ90NC7sEAEXfPKwEj2tiBhl4aci4rRJNT3kTOlf9Fc/lylZAkBm
  oMaQ7VHHgUHd+D4uEOjnbSxKUAtcJ5a8qXr08WIgQrT1XHw2R64irYifhA3t4djP
  2py0idt6dcUrAOc0khKtAkBbJsg3ZQCEB23d7hv0lJMMYdSgKXL9wrzsueGiB2wH
  IdmpaBnboEzdmF0bwXnZW34AymeuJuknvyF3uj3IP7s8
  -----END RSA PRIVATE KEY-----
  `,
    publicKey: `-----BEGIN PUBLIC KEY-----
  MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC8Q1SECYxtNztpsAzVf/U5VRdj
  rkrXF1zkjsAIHx0ORimu6IgyOFIYpo0XXESzfb0a8LJ2FA2Z/n6PjAQLDz6J+kcl
  dL65Ev661mabEHu6zTYRLPrJ0AznEoX7Q7UQwwpbw9OiJXmXE7RbfrPmh1Lr736o
  fRRnO68fJsnvN/3GLQIDAQAB
  -----END PUBLIC KEY-----
  `,
    tokenExpire: 10 * 24 * 60 * 60,
};
export const jwtService = new JWTHelper(config.privateKey, config.publicKey);


