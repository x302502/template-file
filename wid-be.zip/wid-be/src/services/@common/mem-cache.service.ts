import { MemoryCacheHelper } from "~/@core/helpers";


const userSessionCache = new MemoryCacheHelper();

export const memCacheService = {
    userSessionCache
}