import * as nodeMailer from 'nodemailer';
require('dotenv').config();
import { configEnv } from "~/@config";

const { GMAIL_PASS } = configEnv();


class MailService {
    async sendMailVerify(verifyCode: number, email: string, subject: string) {

        let transporter = nodeMailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true,
            auth: {
                user: 'ftechnology.singapore@gmail.com',
                pass: `${GMAIL_PASS}`
            }
        });
        let mailOptions = {
            from: '"W3W Protocol" <ftechnology.singapore@gmail.com>', // sender address
            to: `${email}`, // list of receivers
            subject: `${subject}`, // Subject line
            // text: '', // plain text body
            html: `<!DOCTYPE html>
            <html>
                <head>
                    <title>Verify your W3ID account!</title>
                </head>
                <body>
                    <table>
                        <tbody>
                            <tr height="27">
                                <td rowspan="24" colspan="17">Your verification code:
                                    <strong><p style="font-size: 30px; color: #5356FB;">${verifyCode}</p></strong>
                                    The verification code will be valid for 3 minutes. Please do not share this code with anyone.<br><br>This is
                                    an automated message, please do not reply.<br><br>W3W Protocol that helps to create COMPATIBILITY
                                    between the two environments of Web2 and Web3<br>W3ID is a decentralized digital identity for users in
                                    the Web3 World, and with this identity, W3ID holders can participate and use promotional programs
                                    offered by brands on the W3W network.<br><br>Risk warning: Web3 inherently carries many risks; however,
                                    we will make every effort to help you have safe experiences in the wonderful environment of Web3, but
                                    will not be responsible for your trading purpose.<br>Kindly note: Please be aware of phishing sites and
                                    always make sure you are visiting the official&nbsp;<a href="https://w3id.link/" target="_blank">W3ID</a> website when
                                    entering sensitive data.<br><br>&copy; 2023 <a href="https://w3id.link/" target="_blank">W3ID</a>, All Rights Reserved.
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </body>
            </html>
            ` // html body
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
            console.log('Message %s sent: %s', info.messageId, info.response);
        });
    }

    async sendMailWelcome(email: string, subject: string) {

        let transporter = nodeMailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true,
            auth: {
                user: 'ftechnology.singapore@gmail.com',
                pass: `${GMAIL_PASS}`
            }
        });
        let mailOptions = {
            from: '"W3W Protocol" <ftechnology.singapore@gmail.com>', // sender address
            to: `${email}`, // list of receivers
            subject: `${subject}`, // Subject line
            html: `<!DOCTYPE html>
            <html>
            <head>
                <title>Welcome to W3W Protocol!</title>
            </head>
            <body>
            <tbody>
                <tr height="284">
                    <td>Hello,<br>Welcome to W3W Protocol!<br>We are delighted to welcome you to W3W Protocol! We hope you will have unique experiences with NFTs on our platform. We believe that NFTSquare is an excellent way for our members to showcase their creativity and connect with other like-minded individuals. We encourage you to explore this platform and see what it has to offer.<br>If you have any questions or need assistance, our customer support team is always ready to help. Please feel free to contact us at&nbsp;<a href="mailto:hotline@nftsquare.io">hotline@nftsquare.io</a> or social channel and we will do our best to assist you.<br>Once again, thank you for joining W3W Protocol. We look forward to seeing your contributions to our community!<br><br>Best regards,<br>W3W Protocol Team</td>
                </tr>
                <tr height="178">
                    <td><img src="https://api.nft-square.io/files/banner-nft.png" width="1280" height="256"></td>
                </tr>
                <tr height="128">
                    <td><strong>W3W Protocol - Enjoy NFT In Your Real Life</strong><br>W3W Protocol - &quot;the next generation NFT e-commerce marketplace&quot; is an e-commerce platform and marketplace for &ldquo;NFT as a product&rdquo;. We are aiming to create a new shopping experience for a wider global audience of end-users and are creating new business solutions for brands, corporates, creators, etc.<br><a href="https://nft-square.io/" target="_blank">@2023 W3W Protocol</a></td>
                </tr>
            </tbody>
            </body>
            </html>
            ` // html body
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
            console.log('Message %s sent: %s', info.messageId, info.response);
        });
    }

    async sendMailAccountRegisterComplete(email: string, subject: string) {

        let transporter = nodeMailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true,
            auth: {
                user: 'ftechnology.singapore@gmail.com',
                pass: `${GMAIL_PASS}`
            }
        });
        let mailOptions = {
            from: '"W3W Protocol" <ftechnology.singapore@gmail.com>', // sender address
            to: `${email}`, // list of receivers
            subject: `${subject}`, // Subject line
            html: `<!DOCTYPE html>
            <html>
                <head>
                    <title>Welcome to W3ID - A decentralized digital identity for users in the Web3 World!</title>
                </head>
                <body>
                    <table>
                        <tbody>
                            <tr height="331">
                                <td>Hello,<br><br>Welcome to W3W Protocol!&nbsp;<br>We are delighted to have you on our platform and hope
                                    that you will have a unique experience.&nbsp;<br>We believe that W3W Protocol is an excellent way for
                                    W3ID holders to participate in and use Your &nbsp;promotional programs offered on the W3W
                                    network.&nbsp;<br>We encourage you to explore the platform and see what it has to offer.<br><br>If you
                                    have any questions or need assistance, our customer support team is always ready to
                                    help.&nbsp;<br>Please feel free to contact us at&nbsp;<a
                                        href="mailto:w3w.services@fam3.io">w3w.services@fam3.io</a> or through our social channels, and we
                                    will do our best to assist you.<br>Once again, thank you for joining W3W Protocol and Web3 World. We
                                    hope that you will have miraculous experiences!<br><br>Best regards,<br><br>W3ID Team<br>
                                    <img height="300px" width="800px" src="https://qa.wid.famcentral.io/static/media/logo.05de9860.png" />
                                    <br>
                                    W3W Protocol that helps to create COMPATIBILITY between the two environments of Web2 and
                                    Web3<br>W3ID is a decentralized digital identity for users in the Web3 World, and with this identity,
                                    W3ID holders can participate and use promotional programs offered by brands on the W3W network.</td>
                            </tr>
                        </tbody>
                    </table>
                </body>
            </html>
            ` // html body
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
            console.log('Message %s sent: %s', info.messageId, info.response);
        });
    }

    async sendMailForgotPassword(verifyCode: number, email: string, subject: string) {

        let transporter = nodeMailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true,
            auth: {
                user: 'ftechnology.singapore@gmail.com',
                pass: `${GMAIL_PASS}`
            }
        });
        let mailOptions = {
            from: '"W3W Protocol" <ftechnology.singapore@gmail.com>', // sender address
            to: `${email}`, // list of receivers
            subject: `${subject}`, // Subject line
            // text: '', // plain text body
            html: `<!DOCTYPE html>
            <html>
                <head>
                    <title>W3ID Reset Password</title>
                </head>
                <body>
                    <table>
                        <tbody>
                            <tr height="27">
                                <td rowspan="13" colspan="10">Hi,<br>
                                    Your W3W Account &nbsp;password can be reset by inserting the code
                                    below. If you did not request a new password, please ignore this email.<br><br>Your reset password
                                    code:
                                    <strong>
                                        <p style="font-size: 30px; color: #5356FB;">${verifyCode}</p>
                                    </strong>
                                </td>
                            </tr>
                            <tr>
                                
                            </tr>
                        </tbody>
                    </table>
                </body>
            </html>
            ` // html body
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
            console.log('Message %s sent: %s', info.messageId, info.response);
        });
    }
}
export const mailService = new MailService();;