
import { optionalApiService } from ".";
import { CoinGeckoChain } from "~/common/constants/CoinGeckoChain";



export interface ICoingeckoNftInfo {
    chainId: number
    address: string;
    name: string;
    symbol: string;
    image: string;
    description: string;
    floorPrice: number;
    totalSupply: number;
    links?: string;
}

const Enpoint = {
    getNftInfoByAddress: 'https://api.coingecko.com/api/v3/nfts/{{chainCode}}/contract/{{address}}',
}


class MoralisConnector {
    async getNftInfoByAddress(body: { address: string; chainId: number }) {
        const { address, chainId } = body;

        const chainCode = CoinGeckoChain[chainId];
        const url = Enpoint.getNftInfoByAddress
            .replace("{{chainCode}}", chainCode)
            .replace("{{address}}", address);
        const nftRes = await optionalApiService.get(url);

        console.log(`-------------------`);
        console.log(nftRes);
        console.log(`-------------------`);

        return {
            chainId,
            address,
            name: nftRes.name || "",
            symbol: nftRes.symbol || "",
            image: nftRes?.image?.small || "",
            description: nftRes.description || "",
            floorPrice: nftRes?.floor_price.usd || 0,
            totalSupply: nftRes?.total_supply || 0,
            links: JSON.stringify(nftRes?.links || {})
        }


    }




}

export default new MoralisConnector()