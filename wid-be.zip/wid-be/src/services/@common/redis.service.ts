
import { configEnv } from "~/@config";
import { RedisHelper } from "~/@core/helpers";
const { REDIS } = configEnv()
export const redisService = new RedisHelper(REDIS);


