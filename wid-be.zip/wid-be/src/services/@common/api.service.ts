

import { configEnv } from "~/@config";
import { IObjectPromise } from "~/@core/dto";
import { AxiosHttpClient, IAxiosRequestOptions } from "~/@core/network/axios-http-client";
import * as FormData from "form-data";
import { EMediaType } from "~/@core/constants";

export class ApiService {
    private httpClient: AxiosHttpClient
    constructor(config: {
        baseurl: string, options: IAxiosRequestOptions, interceptors?: IObjectPromise
    }) {
        this.httpClient = new AxiosHttpClient(config)
    }
    async get<T = any>(endpoint: string, params: any = {}, headerEnpoint = {}): Promise<T> {
        try {
            const res = await this.httpClient.get<T>(endpoint, params, headerEnpoint);

            return res.data
        } catch (error) {
            throw error;
        }
    }
    async getByBody<T = any>(endpoint: string, body: any = {}): Promise<T> {
        try {
            const res = await this.httpClient.getByBody<T>(endpoint, body);
            return res.data
        } catch (error) {
            throw error;
        }
    }
    async post<T = any>(endpoint: string, body: any = {}, headerEnpoint = {}): Promise<T> {
        try {
            const res = await this.httpClient.post<T>(endpoint, body, headerEnpoint);
            return res.data;
        } catch (error) {
            throw error;
        }
    }

    async put<T = any>(endpoint: string, body: any = {}): Promise<T> {
        try {
            const res = await this.httpClient.put<T>(endpoint, body);
            return res.data
        } catch (error) {
            throw error;
        }
    }
    async uploadFile<T = any>(endpoint: string, formData: FormData, onUploadProgress?: (event: any) => void): Promise<T> {
        try {
            const res = await this.httpClient.uploadFile<T>(endpoint, formData, onUploadProgress);
            return res.data
        } catch (error) {
            throw error;
        }
    }

}


const { } = configEnv().CONNECTORS;

// export const authApiService = new ApiService({
//   baseurl: AUTH.baseUrl,
//   options: {
//     timeout: 120000,
//     headers: {
//       "Content-Type": EMediaType.APPLICATION_FORM_URLENCODED
//     }
//   },
//   interceptors: {
//   }
// });
export const optionalApiService = new ApiService({
    baseurl: "",
    options: {
        timeout: 2 * 60 * 1000,
        headers: {
            "Content-Type": EMediaType.APPLICATION_JSON,
            "accept": EMediaType.APPLICATION_JSON,
        },
    },
    interceptors: {

    },
});

export const moralisApiService = new ApiService({
    baseurl: "https://deep-index.moralis.io/api/v2/",
    options: {
        timeout: 2 * 60 * 1000,
        headers: {
            "Content-Type": EMediaType.APPLICATION_JSON,
            "accept": EMediaType.APPLICATION_JSON,
            // "X-API-Key": "MV7JbXKJt7deSyr41Z9aIjgufsSJhNW2kySLGQOjl3hRpp5w8mZqxY3LBzGqkStW"
            "X-API-Key": "lC30PGBQwmDFtMKQ8j0mVH4mknQtn55JsgoRP6vSGK300ImdVpTKKtlYADktaL2L"
        },
    },
    interceptors: {

    },
});