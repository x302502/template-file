import { configEnv } from "~/@config";
import { BindRepo, BindService, DefTransaction, Service } from "~/@core/decorator";
import { ListOfferBySearchTypeReq, SpecialOfferReq } from "~/dto/user.dto";
import { Program } from "~/entities/primary";
import { ProgramRepo, UserNftRepo, UserRepo, ProgramStoreRepo, MerchantRepo, UserMerchantTierRepo } from "~/repositories/primary";
import { ApplyStoreInProgramReq, CreateProgramReq, ListProgramByBrandReq, UpdateProgramReq } from "~/dto/brand.dto";
import { UUIDReq } from "~/dto/@common";
import generateCodeUtils from "~/@systems/utils/generate-code.utils";
import { PageResponse, SuccessResponse } from "~/@systems/utils";
import { contextSession } from "~/@systems/middlewares";
import { BusinessException } from "~/@systems/exceptions";
import { EProgramType, EUserTier } from "~/common/enums";
import { EMerchantType } from "~/common/enums/EMerchantType";
import { EProgramStatus } from "~/common/enums/EProgramStatus";
import { getKeyEnumByValue } from "~/@systems/utils/common.utils";
import { DetailProgramReq, ListCampaignProgramDto, ListMerchantProgramReq, ListProgramExcludeDto, ListProgramPublishedReq, ListProgramReq, ProgramDto } from "~/dto/program/program.dto";
import { ApiKeyService } from "./api-key.service";


@Service()
export class ProgramService {



    @BindRepo(ProgramStoreRepo)
    private programStoreRepo: ProgramStoreRepo;

    @BindRepo(ProgramRepo)
    private programRepo: ProgramRepo;

    @BindRepo(UserRepo)
    private userRepo: UserRepo;

    @BindRepo(MerchantRepo)
    private merchantRepo: MerchantRepo;


    @BindRepo(UserMerchantTierRepo)
    private userMerchantTierRepo: UserMerchantTierRepo;

    @BindService("ApiKeyService")
    private apiKeyService: ApiKeyService;


    listProgramByMerchant(params: ListProgramByBrandReq) {
        const sql = `
            SELECT * FROM program 
            WHERE "merchantId" = '${params.merchantId}'
            ORDER BY "createdDate" DESC
        `
        return this.programRepo.paginationQuery(sql, params);
    }

    @DefTransaction()
    async createProgram(body: CreateProgramReq) {
        let merchant = await this.merchantRepo.findOne(contextSession.merchantId);
        if (!merchant) throw new BusinessException("Merchant account not exist");
        if (!merchant && merchant.type != EMerchantType.MERCHART) throw new BusinessException("No permission to create program");
        return this.programRepo.save({
            ...body,
            status: EProgramStatus.DRAFT,
            merchantId: contextSession.merchantId,
            code: generateCodeUtils.uuidNoDash()
        })
    }

    async requestPublishProgram(body: UUIDReq) {
        let program = await this.programRepo.findOne(body.id);
        if (!program) throw new BusinessException("Program not exist");
        if (program && program.status != EProgramStatus.DRAFT) throw new BusinessException("Your program status is invalid for publishing.");
        let merchant = await this.merchantRepo.findOne(contextSession.merchantId);
        if (!merchant) throw new BusinessException("Merchant account not exist");
        if (!merchant && merchant.type != EMerchantType.MERCHART) throw new BusinessException("No permission to create program");
        if (merchant.id != program.merchantId) throw new BusinessException("You do not own this program");
        program.status = EProgramStatus.REQUEST_PUBLISHED;
        return await this.programRepo.save(program);
    }

    async verifyProgram(body: UUIDReq) {
        const program = await this.programRepo.findOne(body.id);
        if (!program) {
            throw new BusinessException("Program not existed");
        }

        if (program.status > EProgramStatus.REQUEST_PUBLISHED) {
            throw new BusinessException(`Program is ${getKeyEnumByValue(EProgramStatus, program.status)}`);
        }
        program.status = EProgramStatus.PUBLISHED;
        // program = await this.programRepo.save(program);
        // let mailSubject = "Your account has been approved!";
        // mailService.sendMailAccountRegisterComplete(program.email, mailSubject);
        return await this.programRepo.save(program);
    }

    async rejectRequestProgram(body: UUIDReq) {
        const program = await this.programRepo.findOne(body.id);
        if (!program) throw new BusinessException("Program not exist");
        program.status = EProgramStatus.REJECT;
        return await this.programRepo.save(program);
    }

    async suspendProgram(body: UUIDReq) {
        const program = await this.programRepo.findOne(body.id);
        if (!program) {
            throw new BusinessException("Program not exist");
        }
        program.status = EProgramStatus.SUSPENDED;
        return this.programRepo.save(program);
    }

    list(params: ListProgramReq) {
        const sql = `
        SELECT
            pr.*,
            mc."companyName" "merchantName",
            to_json(mc.*) as merchant,
            COALESCE( json_agg(mt.*)  FILTER (WHERE mt.id IS NOT NULL), '[]') as "listMerchantTier"  
        FROM
            program pr
            INNER JOIN merchant mc ON pr."merchantId" = mc.id
            LEFT JOIN merchant_tier mt ON mt."id" = ANY ( pr."merchantTiers" ) 
        GROUP BY pr."id",mc.id
        ORDER BY
            "createdDate" DESC
        `
        return this.programRepo.paginationQuery<Program>(sql, params);
    }

    @DefTransaction()
    async updateProgram(body: UpdateProgramReq) {
        const { id, ...restBody } = body;
        const program = await this.programRepo.findOne(id);
        if (!program) {
            throw new BusinessException("Program not existed")
        }
        return this.programRepo.save({
            ...program,
            ...restBody
        })
    }

    async programDetail(params: UUIDReq) {
        const program = await this.programRepo.findOne({
            id: params.id
        });

        if (!program) {
            throw new BusinessException("Program not existed")
        }
        const { apiKey: firstApiKey } = await this.apiKeyService.firstApiByMerchant({ merchantId: program.merchantId });
        return {
            ...program,
            firstApiKey
        }
    }

    @DefTransaction()
    async deleteProgram(id: string) {
        await this.programRepo.delete({ id: id });
        return new SuccessResponse();
    }


    @DefTransaction()
    async applyStoreInProgram(body: ApplyStoreInProgramReq) {
        const { storeIds = [], programId } = body;
        const { merchantId } = contextSession;
        for (const storeId of storeIds) {
            const programStore = await this.programStoreRepo.findOne({
                where: {
                    merchantId,
                    storeId,
                    programId
                }
            })
            if (!programStore) {
                await this.programStoreRepo.insert({
                    merchantId,
                    programId,
                    storeId
                });
            }
        }
        return new SuccessResponse();
    }


    async specialOffer(params: SpecialOfferReq) {
        try {
            const { walletAddress } = params;
            let tier = EUserTier.NONTIER;

            if (walletAddress) {
                const user = await this.userRepo.findOne({
                    where: {
                        walletAddress: walletAddress.toLowerCase()
                    }
                })
                if (user) {
                    tier = user.tier;
                }
            }

            const sql = `
            SELECT *,${tier} = ANY("w3wTiers") as "canJoin" FROM program 
            ORDER BY "startTime" DESC
            LIMIT 3
        `
            return this.programRepo.query(sql);
        } catch (error) {
            return []
        }
    }


    async listOfferBySearchType(params: ListOfferBySearchTypeReq) {
        try {
            const { walletAddress, searchType = "ALL" } = params;
            let tier = EUserTier.NONTIER;

            if (walletAddress) {
                const user = await this.userRepo.findOne({
                    where: {
                        walletAddress: walletAddress.toLowerCase()
                    }
                })
                if (user) {
                    tier = user.tier;
                }
            }

            const sql = `
                SELECT *,${tier} = ANY("w3wTiers") as "canJoin" FROM program
            `;

            const select = `SELECT * FROM ( ${sql} ) tmp `

            if (searchType === "YOUR_OFFER") {

                return this.programRepo.query(`
                    ${select} WHERE "canJoin" = true
                    ORDER BY "startTime" DESC
                    LIMIT 10
                `)
            }

            if (searchType === "COMMING") {
                return this.programRepo.query(`
                    ${select} WHERE "startTime" >= NOW()
                    ORDER BY "startTime" DESC
                    LIMIT 10
                `)
            }

            console.log(`-------------------`);
            console.log(` ${select} 
            ORDER BY "startTime" DESC
            LIMIT 10`);
            console.log(`-------------------`);

            return this.programRepo.query(`
                    ${select} 
                    ORDER BY "startTime" DESC
                    LIMIT 10
            `);

        } catch (error) {
            return []
        }
    }

    async getListProgram(body: ProgramDto) {
        let sql = ` select * from "program" ORDER BY "createdDate" desc `
        return await this.programRepo.paginationQuery(sql, body);
    }

    // api public for user
    listProgramPublished(params: ListProgramPublishedReq) {
        const sql = ` select pro.*, mc."companyName" "merchantName"
            FROM program pro
            inner join merchant mc on mc.id = pro."merchantId"
            where pro."status" = '${EProgramStatus.PUBLISHED}'
            ORDER BY pro."createdDate" DESC
        `
        return this.programRepo.paginationQuery<Program>(sql, params);
    }

    async getDetailProgram(body: DetailProgramReq) {
        const { walletAddress, id } = body;
        let tier = EUserTier.NONTIER;

        let userMerchantTierIds = [];
        if (walletAddress) {
            const user = await this.userRepo.findOne({
                where: {
                    walletAddress: walletAddress.toLowerCase()
                }
            })
            if (user) {
                tier = user.tier;
                const userMerchantTiers = await this.userMerchantTierRepo.find({
                    select: ["merchantTierId"],
                    where: {
                        userId: user.id
                    }
                });
                if (userMerchantTiers) {
                    userMerchantTierIds = userMerchantTiers.map(v => v.merchantTierId);
                }
            }
        }

        let selectCanJoin = `
            ${tier} = ANY(pro."w3wTiers") 
        `;

        if (userMerchantTierIds.length > 0) {
            selectCanJoin += ` OR ${userMerchantTierIds.map(merchantTierId => `'${merchantTierId}' = ANY(pro."merchantTiers")`).join(" OR ")}`
        }

        const rootSql = ` 
            select 
                pro.*, 
                mc."companyName" "merchantName",
                ( ${selectCanJoin} ) as "canJoin"
            FROM program pro
            inner join merchant mc on mc.id = pro."merchantId"
            where pro.id = '${id}' `

        let sql = `
            SELECT * FROM ( ${rootSql} ) tmp 
        `;

        sql += ` ORDER BY "startTime" ASC `;

        return await this.programRepo.queryOne(sql);
    }

    async listByMerchantId(params: ListMerchantProgramReq) {
        try {
            const { walletAddress } = params;
            let tier = EUserTier.NONTIER;

            let userMerchantTierIds = [];
            if (walletAddress) {
                const user = await this.userRepo.findOne({
                    where: {
                        walletAddress: walletAddress.toLowerCase()
                    }
                })
                if (user) {
                    tier = user.tier;
                    const userMerchantTiers = await this.userMerchantTierRepo.find({
                        select: ["merchantTierId"],
                        where: {
                            userId: user.id
                        }
                    });
                    if (userMerchantTiers) {
                        userMerchantTierIds = userMerchantTiers.map(v => v.merchantTierId);
                    }
                }
            }

            let selectCanJoin = `
                ${tier} = ANY(pro."w3wTiers") 
            `;

            if (userMerchantTierIds.length > 0) {
                selectCanJoin += ` OR ${userMerchantTierIds.map(merchantTierId => `'${merchantTierId}' = ANY(pro."merchantTiers")`).join(" OR ")}`
            }

            const rootSql = ` 
                select 
                    pro.*, 
                    CAST( count(DISTINCT (ps."storeId")  ) as integer ) as "noOfStore",
                    mc."companyName" "merchantName",
                    ( ${selectCanJoin} ) as "canJoin"
                FROM program pro
                    inner join merchant mc on mc.id = pro."merchantId"
                    LEFT JOIN program_store ps on ps."programId" = pro."id"
                where pro."status" = '${EProgramStatus.PUBLISHED}' 
                and pro."merchantId" = '${params.merchantId}'
                and pro.type = ${EProgramType.NORMAL}
                GROUP BY pro.id,mc.id

                `

            let sql = `
                SELECT * FROM ( ${rootSql} ) tmp 
            `;

            // sql += ` ORDER BY "startTime" ASC `;

            const sqlUnderCampaign = ` 
                select 
                    pro.*, 
                    CAST( count(DISTINCT (ps."storeId")  ) as integer ) as "noOfStore",
                    mc."companyName" "merchantName",
                    ( ${selectCanJoin} ) as "canJoin"
                FROM program pro
                inner join merchant mc on mc.id = pro."merchantId"
                LEFT JOIN program_store ps on ps."programId" = pro."id"
                where pro."status" = ${EProgramStatus.PUBLISHED} 
                and pro."merchantId" = '${params.merchantId}' 
                and pro.type = ${EProgramType.UNDER_CAMPAIGN} and ( pro."w3wTiers" != '{}' or pro."merchantTiers" != '{}' ) 
                GROUP BY pro.id,mc.id
                `

            let selectUnderCampaign = `
                SELECT * FROM ( ${sqlUnderCampaign} ) tmp 
            `;

            // if (isCanJoin) {
            //     selectUnderCampaign += ` WHERE  "canJoin" = true `
            // }

            let finalQuery = sql + ' UNION ' + selectUnderCampaign + ' ORDER BY "startTime" ASC ';

            return this.programRepo.paginationQuery(finalQuery, params);
        } catch (error) {
            return new PageResponse();
        }
    }

    async listPublished(body: ListProgramPublishedReq) {
        try {
            const { walletAddress, isCanJoin } = body;
            let tier = EUserTier.NONTIER;

            let userMerchantTierIds = [];
            if (walletAddress) {
                const user = await this.userRepo.findOne({
                    where: {
                        walletAddress: walletAddress.toLowerCase()
                    }
                })
                if (user) {
                    tier = user.tier;
                    const userMerchantTiers = await this.userMerchantTierRepo.find({
                        select: ["merchantTierId"],
                        where: {
                            userId: user.id
                        }
                    });
                    if (userMerchantTiers) {
                        userMerchantTierIds = userMerchantTiers.map(v => v.merchantTierId);
                    }
                }
            }

            let selectCanJoin = `
                ${tier} = ANY(pro."w3wTiers") 
            `;

            if (userMerchantTierIds.length > 0) {
                selectCanJoin += ` OR ${userMerchantTierIds.map(merchantTierId => `'${merchantTierId}' = ANY(pro."merchantTiers")`).join(" OR ")}`
            }

            const rootSql = ` 
                select 
                    pro.*, 
                    mc."companyName" "merchantName",
                    ( ${selectCanJoin} ) as "canJoin"
                FROM program pro
                inner join merchant mc on mc.id = pro."merchantId"
                where pro."status" = '${EProgramStatus.PUBLISHED}' and pro.type = ${EProgramType.NORMAL} `

            let sql = `
                SELECT * FROM ( ${rootSql} ) tmp 
            `;

            if (isCanJoin) {
                sql += ` WHERE  "canJoin" = true `
            }

            // sql += ` ORDER BY "startTime" ASC `;

            const sqlUnderCampaign = ` 
                select 
                    pro.*, 
                    mc."companyName" "merchantName",
                    ( ${selectCanJoin} ) as "canJoin"
                FROM program pro
                inner join merchant mc on mc.id = pro."merchantId"
                where pro."status" = '${EProgramStatus.PUBLISHED}' 
                and pro.type = ${EProgramType.UNDER_CAMPAIGN} and ( pro."w3wTiers" != '{}' or pro."merchantTiers" != '{}' ) `

            let selectUnderCampaign = `
                SELECT * FROM ( ${sqlUnderCampaign} ) tmp 
            `;

            if (isCanJoin) {
                selectUnderCampaign += ` WHERE  "canJoin" = true `
            }

            // selectUnderCampaign += ` ORDER BY "startTime" ASC `;

            let finalQuery = sql + ' UNION ' + selectUnderCampaign + ' ORDER BY "startTime" ASC ';

            console.log(`-------------------`);
            console.log(finalQuery);
            console.log(`-------------------`);
            return this.programRepo.paginationQuery(finalQuery, body);
        } catch (error) {
            return new PageResponse();
        }
    }

    async getListProgramExcludeIds(params: ListProgramExcludeDto) {
        const { walletAddress, ids } = params;
        let tier = EUserTier.NONTIER;

        let sqlWhereProgramIds = ` `;
        if (ids.length > 0) {
            sqlWhereProgramIds = ` and pro.id not in ( '${ids.join("','")}' ) `;
        }

        let userMerchantTierIds = [];
        if (walletAddress) {
            const user = await this.userRepo.findOne({
                where: {
                    walletAddress: walletAddress.toLowerCase()
                }
            })
            if (user) {
                tier = user.tier;
                const userMerchantTiers = await this.userMerchantTierRepo.find({
                    select: ["merchantTierId"],
                    where: {
                        userId: user.id
                    }
                });
                if (userMerchantTiers) {
                    userMerchantTierIds = userMerchantTiers.map(v => v.merchantTierId);
                }
            }
        }

        let selectCanJoin = `
            ${tier} = ANY(pro."w3wTiers") 
        `;

        if (userMerchantTierIds.length > 0) {
            selectCanJoin += ` OR ${userMerchantTierIds.map(merchantTierId => `'${merchantTierId}' = ANY(pro."merchantTiers")`).join(" OR ")}`
        }

        const rootSql = ` 
            select 
                pro.*, 
                CAST( count(DISTINCT (ps."storeId")  ) as integer ) as "noOfStore",
                mc."companyName" "merchantName",
                ( ${selectCanJoin} ) as "canJoin"
            FROM program pro
                inner join merchant mc on mc.id = pro."merchantId"
                LEFT JOIN program_store ps on ps."programId" = pro."id"
            where pro."status" = '${EProgramStatus.PUBLISHED}' and pro.type = ${EProgramType.NORMAL} 
            ${sqlWhereProgramIds}
            GROUP BY pro.id,mc.id

            `

        let sql = `
            SELECT * FROM ( ${rootSql} ) tmp 
        `;

        // sql += ` ORDER BY "startTime" ASC `;

        const sqlUnderCampaign = ` 
            select 
                pro.*, 
                CAST( count(DISTINCT (ps."storeId")  ) as integer ) as "noOfStore",
                mc."companyName" "merchantName",
                ( ${selectCanJoin} ) as "canJoin"
            FROM program pro
            inner join merchant mc on mc.id = pro."merchantId"
            LEFT JOIN program_store ps on ps."programId" = pro."id"
            where pro."status" = ${EProgramStatus.PUBLISHED}
            and pro.type = ${EProgramType.UNDER_CAMPAIGN} and ( pro."w3wTiers" != '{}' or pro."merchantTiers" != '{}' ) 
            ${sqlWhereProgramIds}
            GROUP BY pro.id,mc.id
            `

        let selectUnderCampaign = `
            SELECT * FROM ( ${sqlUnderCampaign} ) tmp 
        `;

        let finalQuery = sql + ' UNION ' + selectUnderCampaign + ' ORDER BY "startTime" ASC ';

        return this.programRepo.paginationQuery(finalQuery, params);
    }

    async listPublishedForUser(body: ListProgramPublishedReq) {
        try {
            const { walletAddress, isCanJoin } = body;
            let tier = EUserTier.NONTIER;

            let userMerchantTierIds = [];
            if (walletAddress) {
                const user = await this.userRepo.findOne({
                    where: {
                        walletAddress: walletAddress.toLowerCase()
                    }
                })
                if (user) {
                    tier = user.tier;
                    const userMerchantTiers = await this.userMerchantTierRepo.find({
                        select: ["merchantTierId"],
                        where: {
                            userId: user.id
                        }
                    });
                    if (userMerchantTiers) {
                        userMerchantTierIds = userMerchantTiers.map(v => v.merchantTierId);
                    }
                }
            }

            let selectCanJoin = `
                ${tier} = ANY(pro."w3wTiers") 
            `;

            if (userMerchantTierIds.length > 0) {
                selectCanJoin += ` OR ${userMerchantTierIds.map(merchantTierId => `'${merchantTierId}' = ANY(pro."merchantTiers")`).join(" OR ")}`
            }

            const rootSql = ` 
                select 
                    pro.*, 
                    CAST( count(DISTINCT (ps."storeId")  ) as integer ) as "noOfStore",
                    mc."companyName" "merchantName",
                    ( ${selectCanJoin} ) as "canJoin"
                FROM program pro
                    inner join merchant mc on mc.id = pro."merchantId"
                    LEFT JOIN program_store ps on ps."programId" = pro."id"
                where pro."status" = '${EProgramStatus.PUBLISHED}' and pro.type = ${EProgramType.NORMAL}
                GROUP BY pro.id,mc.id

                `

            let sql = `
                SELECT * FROM ( ${rootSql} ) tmp 
            `;

            // sql += ` ORDER BY "startTime" ASC `;

            const sqlUnderCampaign = ` 
                select 
                    pro.*, 
                    CAST( count(DISTINCT (ps."storeId")  ) as integer ) as "noOfStore",
                    mc."companyName" "merchantName",
                    ( ${selectCanJoin} ) as "canJoin"
                FROM program pro
                inner join merchant mc on mc.id = pro."merchantId"
                LEFT JOIN program_store ps on ps."programId" = pro."id"
                where pro."status" = ${EProgramStatus.PUBLISHED}
                and pro.type = ${EProgramType.UNDER_CAMPAIGN} and ( pro."w3wTiers" != '{}' or pro."merchantTiers" != '{}' ) 
                GROUP BY pro.id,mc.id
                `

            let selectUnderCampaign = `
                SELECT * FROM ( ${sqlUnderCampaign} ) tmp 
            `;

            if (isCanJoin) {
                selectUnderCampaign += ` WHERE  "canJoin" = true `
            }

            let finalQuery = sql + ' UNION ' + selectUnderCampaign + ' ORDER BY "startTime" ASC ';

            return this.programRepo.paginationQuery(finalQuery, body);
        } catch (error) {
            return new PageResponse();
        }
    }

}