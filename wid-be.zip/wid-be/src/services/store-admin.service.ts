import { configEnv } from "~/@config";
import { BindRepo, DefTransaction, Service } from "~/@core/decorator";
import { ListNftReq, NftByAddress } from "~/dto/nft.dto";
import { WalletAddressReq } from "~/dto/user.dto";
import moralisConnector from "./@common/moralis.connector";
import { optionalApiService } from "./@common";
import { UserNft } from "~/entities/primary";
import { MerchantRepo, StoreRepo, UserNftRepo } from "~/repositories/primary";
import { contextSession } from "~/@systems/middlewares";
import { BusinessException } from "~/@systems/exceptions";
import { UUIDReq } from "~/dto/@common";
import { SuccessResponse } from "~/@systems/utils";
import { EMerchantStatus } from "~/common/enums";
import { Address } from "~/entities/primary/address";
import { StoreAddress } from "~/entities/primary/store-address";
import { AddressRepo } from "~/repositories/primary/address.repo";
import { EAddressType } from "~/common/enums/EAddressType";
import { ListStoreAdminReq } from "~/dto/store.dto";


const { GLOABL_CHAINS } = configEnv();
@Service()
export class StoreAdminService {


    @BindRepo(StoreRepo)
    private storeRepo: StoreRepo;

    @BindRepo(MerchantRepo)
    private merchantRepo: MerchantRepo;

    @BindRepo(AddressRepo)
    private addressRepo: AddressRepo;



    list(params: ListStoreAdminReq) {
        const sql = `
            SELECT * FROM store 
            ORDER BY "updatedDate" DESC
        `
        return this.storeRepo.paginationQuery(sql, params);
    }


}