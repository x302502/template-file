import { BindRepo, BindService, Service } from "~/@core/decorator";
import { PageRequest } from "~/@systems/utils";
import { ScanWidReq, UpdateUserProfileReq, WalletAddressReq } from "~/dto/user.dto";
import { MerchantApiKeyRepo, StoreRepo, UserRepo, WidTransactionRepo, ProgramRepo, ProgramStoreRepo, MerchantTierRepo, UserMerchantTierRepo, CampaignProgramRepo } from "~/repositories/primary";
import { NftService } from "./nft.service";
import generateCodeUtils from "~/@systems/utils/generate-code.utils";
import { EMerchantTierType, EProgramStatus, ERequestStatus, EUserStatus, EUserTier } from "~/common/enums";
import { BusinessException } from "~/@systems/exceptions";
import moralisConnector from "./@common/moralis.connector";
import { MerchantTier, User, UserMerchantTier } from "~/entities/primary";
import { In } from "typeorm";





@Service()
export class UserService {



    @BindRepo(UserRepo)
    private userRepo: UserRepo;

    @BindRepo(MerchantApiKeyRepo)
    private merchantApiKeyRepo: MerchantApiKeyRepo;

    @BindRepo(ProgramRepo)
    private programRepo: ProgramRepo;

    @BindRepo(ProgramStoreRepo)
    private programStoreRepo: ProgramStoreRepo;

    @BindRepo(StoreRepo)
    private storeRepo: StoreRepo;

    @BindRepo(WidTransactionRepo)
    private widTransactionRepo: WidTransactionRepo;

    @BindRepo(MerchantTierRepo)
    private merchantTierRepo: MerchantTierRepo;

    @BindRepo(UserMerchantTierRepo)
    private userMerchantTierRepo: UserMerchantTierRepo;


    @BindRepo(CampaignProgramRepo)
    private campaignProgramRepo: CampaignProgramRepo;


    @BindService("NftService")
    private nftService: NftService;



    // 01: > 101K
    // 02: 50K => 
    // 03: 10k =>
    // 04: 1 NFT

    // FAM NFT address: 0xB182d2ab5336e081D3338d361613A1e3Ff64462E POLYGON

    getTierUser({ maxPrice, totalQtyNft, specialTier = false }: { maxPrice: number, totalQtyNft: number, specialTier: boolean }) {
        if (totalQtyNft === 0) {
            return EUserTier.NONTIER;
        }
        if (maxPrice >= 101_000) {
            return EUserTier.TIER1;
        }
        if (maxPrice >= 50_000) {
            return EUserTier.TIER2;
        }
        if (maxPrice >= 10_000) {
            return EUserTier.TIER3;
        }
        if (specialTier) {
            return EUserTier.TIER3;
        }
        if (totalQtyNft >= 1) {
            return EUserTier.TIER4
        }
        return EUserTier.NONTIER;
    }


    async syncMerchantTierTokenType(user: User) {

        try {
            const { walletAddress, id: userId } = user;
            // loai la token
            const merchantTiers = await this.merchantTierRepo.find({
                type: EMerchantTierType.TOKEN
            });

            // can check nhung merchant da dc verify 
            // TODO

            const mapChain = merchantTiers.byMapArray(["chainId"])

            const chainIds = Object.keys(mapChain).map(v => Number(v));


            const listUpdate: MerchantTier[] = [];
            const listMerchatIdDelete = [];
            const checkTier = (inputs: MerchantTier[], balance = 0) => {
                if (balance <= 0) {
                    return undefined
                }
                const tiers = inputs.sort((x, y) => y.minQuantity - x.minQuantity);
                for (let index = 0; index < tiers.length; index++) {
                    const { minQuantity } = tiers[index];
                    if (balance >= minQuantity) {
                        return tiers[index];
                    }
                }
                return undefined;
            }

            for (const chainId of chainIds) {
                const listMcTier = mapChain[chainId];
                const mapMerchantTier = listMcTier.byMapArray(["contractAddress"]);
                const listTokenAddress = Object.keys(mapMerchantTier);
                const tokenValues = await moralisConnector.getWalletTokenBalances({
                    chainId: chainId,
                    walletAddress,
                    listTokenAddress
                });

                const mapTokenValue = tokenValues.byMap(["tokenAddress"])
                for (const tokenAddress of listTokenAddress) {
                    const tokenValue = mapTokenValue[tokenAddress];
                    const balance = tokenValue ? tokenValue.balance : 0;

                    const tiers = mapMerchantTier[tokenAddress] || [];
                    const item = checkTier(tiers, balance)
                    if (item) {
                        listUpdate.push(item)
                    } else {
                        if (tiers && tiers.length > 0) {
                            listMerchatIdDelete.push(tiers[0].merchantId)
                        }

                    }
                }
            }

            // update merchant tier

            const dataUpdates = [];
            for (const { id: merchantTierId, tierName, type, merchantId } of listUpdate) {

                let userMerchantTier = await this.userMerchantTierRepo.findOne({
                    where: {
                        merchantId,
                        userId,
                    }
                });
                if (userMerchantTier) {
                    userMerchantTier.merchantTierId = merchantTierId;
                } else {
                    userMerchantTier = new UserMerchantTier();
                    userMerchantTier.userId = userId;
                    userMerchantTier.merchantId = merchantId;
                    userMerchantTier.merchantTierId = merchantTierId;
                }
                dataUpdates.push(userMerchantTier);

            }



            const resultUpdate = await this.userMerchantTierRepo.save(dataUpdates);
            console.log(`=====UpdateOK=====`);

            // bo tier sau khi value token thay doi
            if (listMerchatIdDelete.length) {
                const resultDel = await this.userMerchantTierRepo.delete({
                    merchantId: In(listMerchatIdDelete),
                    userId
                })
                console.log(`=====DeleteOK=====`);
            }


        } catch (error) {
            console.log(`=====SYNC MERCHANT TIER ERROR=====`);
            console.error(error);
        }


    }

    async syncMerchantTierNftType(user: User) {

        try {
            const { walletAddress, id: userId } = user;
            // loai la token
            const merchantTiers = await this.merchantTierRepo.find({
                type: EMerchantTierType.NFT
            });

            // can check nhung merchant da dc verify 
            // TODO

            const mapChain = merchantTiers.byMapArray(["chainId"])

            const chainIds = Object.keys(mapChain).map(v => Number(v));


            const listUpdate: MerchantTier[] = [];
            const listMerchatIdDelete = [];
            const checkTier = (inputs: MerchantTier[], balance = 0) => {
                if (balance <= 0) {
                    return undefined
                }
                const tiers = inputs.sort((x, y) => y.minQuantity - x.minQuantity);
                for (let index = 0; index < tiers.length; index++) {
                    const { minQuantity } = tiers[index];
                    if (balance >= minQuantity) {
                        return tiers[index];
                    }
                }
                return undefined;
            }

            for (const chainId of chainIds) {
                const listMcTier = mapChain[chainId];
                const mapMerchantTier = listMcTier.byMapArray(["contractAddress"]);
                const listTokenAddress = Object.keys(mapMerchantTier);
                const tokenValues = await moralisConnector.getWalletNftBalances({
                    chainIds: [chainId],
                    walletAddress,
                    listNfAddress: listTokenAddress
                });
                const mapTokenValue = tokenValues.byMap(["tokenAddress"])
                for (const tokenAddress of listTokenAddress) {
                    const tokenValue = mapTokenValue[tokenAddress];
                    const balance = tokenValue ? tokenValue.balance : 0;
                    const tiers = mapMerchantTier[tokenAddress] || [];
                    const item = checkTier(tiers, balance)
                    if (item) {
                        listUpdate.push(item)
                    } else {
                        if (tiers && tiers.length > 0) {
                            listMerchatIdDelete.push(tiers[0].merchantId)
                        }

                    }
                }
            }

            // update merchant tier

            const dataUpdates = [];
            for (const { id: merchantTierId, tierName, type, merchantId } of listUpdate) {

                let userMerchantTier = await this.userMerchantTierRepo.findOne({
                    where: {
                        merchantId,
                        userId,
                    }
                });
                if (userMerchantTier) {
                    userMerchantTier.merchantTierId = merchantTierId;
                } else {
                    userMerchantTier = new UserMerchantTier();
                    userMerchantTier.userId = userId;
                    userMerchantTier.merchantId = merchantId;
                    userMerchantTier.merchantTierId = merchantTierId;
                }
                dataUpdates.push(userMerchantTier);

            }



            const resultUpdate = await this.userMerchantTierRepo.save(dataUpdates);
            console.log(`=====UpdateOK=====`);

            // bo tier sau khi value token thay doi
            if (listMerchatIdDelete.length) {
                const resultDel = await this.userMerchantTierRepo.delete({
                    merchantId: In(listMerchatIdDelete),
                    userId
                })
                console.log(`=====DeleteOK=====`);
            }

        } catch (error) {
            console.log(`=====SYNC MERCHANT NFT TIER ERROR=====`);
            console.error(error);
        }


    }

    async syncWallet(body: WalletAddressReq) {
        const walletAddress = body.walletAddress.toLowerCase();
        let user = await this.userRepo.findOne({
            where: {
                walletAddress
            }
        })
        if (!user) {
            user = await this.userRepo.save({
                walletAddress,
                wid: generateCodeUtils.uuidNoDash()
            })
        }

        let isSync = true;
        if (user.lastTimeSyncTier) {
            const chaneTime = Date.now() - user.lastTimeSyncTier.getTime();

            // 10p update neu gan nhau 
            if (chaneTime < 10 * 60 * 1000) {
                isSync = false;
            }
        }
        if (isSync) {
            const { maxPrice, totalQtyNft, specialTier } = await this.nftService.synNftByWalletAddress(body);
            const tier = this.getTierUser({ maxPrice, totalQtyNft, specialTier });
            user.tier = tier;
            user.lastTimeSyncTier = new Date();
            return this.userRepo.save(user);
        }

        await this.syncMerchantTierTokenType(user);
        await this.syncMerchantTierNftType(user);
        return user;
    }
    async userInfoByWallet(params: WalletAddressReq) {
        const walletAddress = params.walletAddress.toLowerCase();
        let user = await this.userRepo.findOne({
            where: {
                walletAddress
            }
        })
        if (!user) {
            user = await this.userRepo.save({
                walletAddress,
                wid: generateCodeUtils.uuidNoDash()
            })
        }
        const merchantTiers = await this.userMerchantTierRepo.query(`
            SELECT 
                mc."companyName" as merchantName,
                mt.*
            FROM  
                user_merchant_tier umt
            INNER JOIN merchant_tier mt ON mt.id = umt."merchantTierId"
            INNER JOIN merchant mc ON mc.id = umt."merchantId"
            WHERE umt."userId" = '${user.id}'
        `).catch(_ => [])
        return {
            ...user,
            merchantTiers
        };
    }

    async updateUserProfile(body: UpdateUserProfileReq) {
        const { walletAddress, email, fullName } = body;
        let user = await this.userRepo.findOne({
            where: {
                walletAddress: walletAddress.toLowerCase()
            }
        })
        if (!user) {
            user = await this.userRepo.save({
                walletAddress: walletAddress.toLowerCase(),
                wid: generateCodeUtils.uuidNoDash()
            })
        }
        return this.userRepo.save({
            ...user,
            status: EUserStatus.ACTIVE,
            email,
            fullName
        })
    }
    async scanWid(body: ScanWidReq) {

        const { apiKey, storeCode, programCode, wid } = body;
        const nowTime = Date.now();

        const merchantApiKey = await this.merchantApiKeyRepo.findOne({
            where: {
                apiKey
            }
        })
        if (!merchantApiKey) {
            throw new BusinessException("Apikey invalid")
        }
        const { merchantId } = merchantApiKey;

        const store = await this.storeRepo.findOne({
            where: {
                storeCode,
                merchantId
            }
        });

        if (!store) {
            throw new BusinessException("Store not existed in merchant")
        }

        const program = await this.programRepo.findOne({
            where: {
                merchantId,
                code: programCode
            }
        });

        if (!program) {
            throw new BusinessException("Program not existed in merchant")
        }

        if (program.startTime.getTime() > nowTime) {
            throw new BusinessException("Program not start")
        }

        if (program.endTime.getTime() < nowTime) {
            throw new BusinessException("Program not ended")
        }

        if (program.status !== EProgramStatus.PUBLISHED) {
            throw new BusinessException("Program not PUBLISHED")
        }

        // kiem tra program co su dung campaign hay khong
        let campaignId = null;

        const campaignProgram = await this.campaignProgramRepo.findOne({
            programId: program.id,
            status: ERequestStatus.APPLY
        });
        if (campaignProgram) {
            campaignId = campaignProgram.campaignId;
        }

        const programStore = await this.programStoreRepo.findOne({
            merchantId,
            storeId: store.id,
            programId: program.id
        });

        if (!programStore) {
            throw new BusinessException("Program not apply in store")
        }

        const user = await this.userRepo.findOne({
            where: {
                wid
            }
        });

        if (!user) {
            throw new BusinessException("User not existed system")
        }

        if (user.status === EUserStatus.INACTIVE) {
            throw new BusinessException("User not active system")
        }

        const { tier = EUserTier.NONTIER } = user;

        const userMerchatTier = await this.userMerchantTierRepo.findOne({
            where: {
                userId: user.id,
                merchantTierId: In(program.merchantTiers)
            }
        });


        const checkTier = () => {
            if (program.w3wTiers.includes(tier)) {
                return true;
            }
            if (!program.merchantTiers || program.merchantTiers.length === 0 || !userMerchatTier) {
                return false;
            }
            return true;
        }

        if (!checkTier()) {
            throw new BusinessException("Tier user not apply program")
        }
        const tx = await this.widTransactionRepo.save({
            userId: user.id,
            merchantId,
            programId: program.id,
            storeId: store.id,
            storeCode,
            programCode,
            campaignId,
            apiKey,
            wid
        });

        return tx;

    }

    list(params: PageRequest) {
        const sql = `
            SELECT * FROM "user" 
       `
        return this.userRepo.paginationQuery(sql, params);
    }
}