import { BindRepo, Service } from "~/@core/decorator";
import { CheckPriceReq } from "~/dto/nft.dto";
import { NftCollectionRepo } from "~/repositories/primary";
import coingeckoConnector from "./@common/coingecko.connector";
import { PageRequest } from "~/@systems/utils";



@Service()
export class NftCollectionService {




    @BindRepo(NftCollectionRepo)
    private nftCollectionRepo: NftCollectionRepo;

    async checkPrice(params: CheckPriceReq) {
        return coingeckoConnector.getNftInfoByAddress({
            ...params
        })
    }

    listCollection(params: PageRequest) {
        const sql = `
            SELECT * FROM nft_collection 
        `
        return this.nftCollectionRepo.paginationQuery(sql, params);
    }

}