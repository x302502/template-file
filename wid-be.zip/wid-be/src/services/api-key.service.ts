import { BindRepo, DefTransaction, Service } from "~/@core/decorator";
import securityHelper from "~/@core/helpers/security.helper";
import { BusinessException } from "~/@systems/exceptions";
import { MerchantApiKeyRepo, MerchantRepo } from "~/repositories/primary";
import { jwtService } from "./@common";
import { Merchant, MerchantApiKey } from "~/entities/primary";
import { BrandLoginReq, BrandRegisterReq, ListApiKeyByBrandReq, ListApiKeyReq, ListBrandReq, ListTransactionReq } from "~/dto/brand.dto";
import { EMerchantStatus } from "~/common/enums";
import { contextSession } from "~/@systems/middlewares";
import { UUIDReq } from "~/dto/@common";
import { getKeyEnumByValue } from "~/@systems/utils/common.utils";
import { v4 } from "uuid";
import { SuccessResponse } from "~/@systems/utils";





@Service()
export class ApiKeyService {




    @BindRepo(MerchantRepo)
    private merchantRepo: MerchantRepo;


    @BindRepo(MerchantApiKeyRepo)
    private merchantApiKeyRepo: MerchantApiKeyRepo


    list(params: ListApiKeyReq) {
        const sql = `
            SELECT bak.*,b."companyName" as "merchantName"
            FROM merchant_api_key bak
            INNER JOIN merchant b ON  bak."merchantId" = b.id
            ORDER BY bak."createdDate" DESC
        `
        return this.merchantApiKeyRepo.paginationQuery(sql, params);
    }


    async firstApiByMerchant({ merchantId }: { merchantId: string }) {
        const firstApiKey = await this.merchantApiKeyRepo.findOne({
            where: {
                merchantId,
            },
            order: {
                createdDate: "DESC"
            }
        });

        if (!firstApiKey) {
            return {
                apiKey: ""
            }
        }
        return {
            apiKey: firstApiKey.apiKey
        }
    }
}

