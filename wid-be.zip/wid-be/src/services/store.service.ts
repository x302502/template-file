import { configEnv } from "~/@config";
import { BindRepo, DefTransaction, Service } from "~/@core/decorator";
import { ListNftReq, NftByAddress } from "~/dto/nft.dto";
import { WalletAddressReq } from "~/dto/user.dto";
import moralisConnector from "./@common/moralis.connector";
import { optionalApiService } from "./@common";
import { UserNft } from "~/entities/primary";
import { MerchantRepo, StoreRepo, UserNftRepo } from "~/repositories/primary";
import { CreateStoreReq, ListStoreApplyProgramReq, ListStoreByMerchantReq, ListStoreApplyCampaignReq, UpdateStoreReq } from "~/dto/brand.dto";
import { contextSession } from "~/@systems/middlewares";
import { BusinessException } from "~/@systems/exceptions";
import { UUIDReq } from "~/dto/@common";
import { SuccessResponse } from "~/@systems/utils";
import { EMerchantStatus } from "~/common/enums";
import { Address } from "~/entities/primary/address";
import { StoreAddress } from "~/entities/primary/store-address";
import { AddressRepo } from "~/repositories/primary/address.repo";
import { EAddressType } from "~/common/enums/EAddressType";


const { GLOABL_CHAINS } = configEnv();
@Service()
export class StoreService {

    @BindRepo(StoreRepo)
    private storeRepo: StoreRepo;

    @BindRepo(MerchantRepo)
    private merchantRepo: MerchantRepo;

    @BindRepo(AddressRepo)
    private addressRepo: AddressRepo;


    listStoreByMerchant(params: ListStoreByMerchantReq) {
        const sql = `
            SELECT st.*,  
            ct.name "countryName", 
            city.name "cityName"
            FROM store st
            LEFT JOIN address addr on addr.id = st."addressId" and addr.type = '${EAddressType.STORE}'
            LEFT JOIN country ct on ct.code = addr."countryCode"
            LEFT JOIN city on city.code = addr."cityCode" 
            WHERE "merchantId" = '${params.merchantId}'
            ORDER BY "createdDate" DESC
        `
        return this.storeRepo.paginationQuery(sql, params);
    }


    @DefTransaction()
    async createStore(body: CreateStoreReq) {
        const { address, name, storeCode, cityCode, countryCode } = body;
        const { merchantId } = contextSession;
        const merchant = await this.merchantRepo.findOne(merchantId);

        if (!merchant) {
            throw new BusinessException("Merchant not existed")
        }

        if (merchant.status < EMerchantStatus.VERIFY) {
            throw new BusinessException("Please contact admin verify merchant")
        }
        let store = await this.storeRepo.findOne({ storeCode, merchantId });


        if (store) {
            throw new BusinessException(`storeCode: ${storeCode} already existed`)
        }
        store = await this.storeRepo.save({ address, name, storeCode, merchantId });
        // save address
        let storeAddress = new Address();
        storeAddress.objectId = store.id;
        storeAddress.cityCode = cityCode;
        storeAddress.countryCode = countryCode;
        storeAddress.type = EAddressType.STORE;
        storeAddress = await this.addressRepo.save(storeAddress);

        store.addressId = storeAddress.id;
        store = await this.storeRepo.save(store);
        return store;
    }


    @DefTransaction()
    async updateStore(body: UpdateStoreReq) {
        const { id, storeCode, address, name } = body;
        const { merchantId } = contextSession;
        const brand = await this.merchantRepo.findOne(merchantId);

        if (!brand) {
            throw new BusinessException("Brand not existed")
        }

        if (brand.status < EMerchantStatus.VERIFY) {
            throw new BusinessException("Please contact admin verify merchant")
        }
        const store = await this.storeRepo.findOne(id);
        if (!store) {
            throw new BusinessException(`Store not existed`)
        }
        if (store.merchantId !== merchantId) {
            throw new BusinessException(`User not permission update store`)
        }
        const storeCheckCode = await this.storeRepo.findOne({ storeCode, merchantId });
        if (storeCheckCode) {
            throw new BusinessException(`storeCode: ${storeCode} already existed`)
        }
        return this.storeRepo.save({
            ...store,
            storeCode, address, name
        })
    }

    async storeDetail(params: UUIDReq) {
        let sql = ` SELECT st.*, 
        ct.code "countryCode", ct.name "countryName", 
        city.code "cityCode", city.name "cityName"
        FROM store st
        LEFT JOIN address addr on addr.id = st."addressId" and addr.type = '${EAddressType.STORE}'
        LEFT JOIN country ct on ct.code = addr."countryCode"
        LEFT JOIN city on city.code = addr."cityCode" 
        where st.id = '${params.id}' `;

        let storeInfo = await this.merchantRepo.query(sql);
        return storeInfo;
    }

    @DefTransaction()
    async deleteStore(id: string) {

        const { merchantId } = contextSession;
        const brand = await this.merchantRepo.findOne(merchantId);

        if (!brand) {
            throw new BusinessException("Brand not existed")
        }

        if (brand.status < EMerchantStatus.VERIFY) {
            throw new BusinessException("Please contact admin verify merchant")
        }
        await this.storeRepo.delete(id);
        return new SuccessResponse();
    }


    listStoreApplyProgram(params: ListStoreApplyProgramReq) {
        const { merchantId } = contextSession;
        const { programId } = params;
        const sql = `
            SELECT 
            *,
            '${programId}' = ANY("programIds")  as "isApply"
            FROM (
            SELECT 
                st.*,
                ARRAY_AGG(pp."programId") as "programIds"
            FROM
                store st LEFT JOIN program_store pp ON st."id" = pp."storeId" 
            WHERE
                st."merchantId" = '${merchantId}' 
            GROUP BY st."id" 
            ) tmp 
            ORDER BY "createdDate"
        `
        return this.storeRepo.paginationQuery(sql, params);
    }

    // listStoreApplyCampaign(params: ListStoreApplyCampaignReq) {
    //     const { merchantId } = contextSession;
    //     const { campaignId } = params;
    //     const sql = `
    //         SELECT 
    //         *,
    //         '${campaignId}' = ANY("campaignIds")  as "isApply"
    //         FROM (
    //         SELECT 
    //             st.*,
    //             ARRAY_AGG(pp."campaignId") as "campaignIds"
    //         FROM
    //             store st LEFT JOIN campaign_store pp ON st."id" = pp."storeId" 
    //         WHERE
    //             st."merchantId" = '${merchantId}' 
    //         GROUP BY st."id" 
    //         ) tmp 
    //         ORDER BY "createdDate"
    //     `
    //     return this.storeRepo.paginationQuery(sql, params);
    // }

    async countStoresByMerchant(body: UUIDReq) {
        let sql = ` SELECT CAST( count(*) as integer ) as count
        FROM store 
        WHERE "merchantId" = '${body.id}' `;
        let { count } = await this.storeRepo.queryOne(sql) || { count: 0 };
        return count;
    }

    async listStoreByProgram(body: UUIDReq) {
        let sql = ` SELECT st.*, 
        ct.code "countryCode", ct.name "countryName", 
        city.code "cityCode", city.name "cityName"
        FROM store st
        INNER JOIN program_store ps on ps."storeId" = st."id"
        LEFT JOIN address addr on addr.id = st."addressId" and addr.type = '${EAddressType.STORE}'
        LEFT JOIN country ct on ct.code = addr."countryCode"
        LEFT JOIN city on city.code = addr."cityCode" 
        WHERE ps."programId" = '${body.id}' `
        let stores = await this.storeRepo.query(sql);
        return stores;
    }
}