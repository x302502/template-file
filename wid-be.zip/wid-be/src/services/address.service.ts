import { BindRepo, DefTransaction, Service } from "~/@core/decorator";
import { AddressRepo } from "~/repositories/primary/address.repo";
import { Address } from "~/entities/primary/address";
import { UUIDReq } from "~/dto/@common";

@Service()
export class AddressService {

    @BindRepo(AddressRepo)
    private addressRepo: AddressRepo;

    @DefTransaction()
    async createAddress(body: Address) {
        return await this.addressRepo.save(body);
    }

    async listAddress() {
        let sql = ` select * from address `;
        return await this.addressRepo.query(sql);
    }

    async getDetail(params: UUIDReq) {
        return await this.addressRepo.findOne(params.id);
    }
}

