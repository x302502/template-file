import { BindRepo, BindService, DefTransaction, Service } from "~/@core/decorator";
import securityHelper from "~/@core/helpers/security.helper";
import { BusinessException, BusinessSuccessResponse, FailForgotPasswordSuccessResponse, SuccessForgotPasswordSuccessResponse, SuccessVerifyFailResponse, SuccessVerifySuccessResponse } from "~/@systems/exceptions";
import { MerchantApiKeyRepo, MerchantRepo } from "~/repositories/primary";
import { jwtService } from "./@common";
import { Merchant, MerchantApiKey } from "~/entities/primary";
import { BrandLoginReq, BrandRegisterReq, ForgotPasswordDto, ForgotPasswordReq, ListApiKeyByBrandReq, ListApiKeyReq, ListBrandReq, ListMerchantReq, UpdateMerchantReq } from "~/dto/brand.dto";
import { EMerchantStatus } from "~/common/enums";
import { contextSession } from "~/@systems/middlewares";
import { UUIDReq } from "~/dto/@common";
import { getKeyEnumByValue } from "~/@systems/utils/common.utils";
import { v4 } from "uuid";
import { SuccessResponse } from "~/@systems/utils";
import { SendEmailReq, VerifyEmailReq } from "~/dto/users/verify-email.dto";
import { mailService } from "./@common/mail.service";
import { isNotEmpty } from "class-validator";
import { AddressRepo } from "~/repositories/primary/address.repo";
import { Address } from "~/entities/primary/address";
import { EAddressType } from "~/common/enums/EAddressType";
import { MerchantTierService } from "./merchant-tier.service";
import { StoreService } from "./store.service";


@Service()
export class BrandService {

    @BindRepo(MerchantRepo)
    private merchantRepo: MerchantRepo;


    @BindRepo(MerchantApiKeyRepo)
    private merchantApiKeyRepo: MerchantApiKeyRepo;

    @BindRepo(AddressRepo)
    private addressRepo: AddressRepo;

    @BindService("MerchantTierService")
    private merchantTierService: MerchantTierService;

    @BindService("StoreService")
    private storeService: StoreService;

    async pipeBrandSession(brand: Merchant) {
        delete brand.password;
        const accessToken = await jwtService.sign(brand);
        Object.assign(brand, {
            accessToken,
        });
        return brand;
    }

    @DefTransaction()
    async register(body: BrandRegisterReq) {

        const { email, password, companyName, name, addressId, website = "", logo = "", countryCode, cityCode, type } = body;

        const brand = await this.merchantRepo.findOne({
            where: {
                email
            }
        });

        if (brand) {
            throw new BusinessException("Your email has already been used, please try another email.");
        }

        const hashPassword = await securityHelper.hash(password);

        let verifyCode = Math.floor(100000 + Math.random() * 900000);
        let isVerifyEmail = false;
        let res = await this.merchantRepo.save({
            email, password: hashPassword, companyName, name, website, logo, verifyCode, isVerifyEmail, addressId, type, status: EMerchantStatus.DRAFT
        });

        // save address
        let merchantAddress = new Address();
        merchantAddress.objectId = res.id;
        merchantAddress.cityCode = cityCode;
        merchantAddress.countryCode = countryCode;
        merchantAddress.type = EAddressType.MERCHANT;
        merchantAddress = await this.addressRepo.save(merchantAddress);

        res.addressId = merchantAddress.id;
        res = await this.merchantRepo.save(res);

        let mailSubject = "Verify your email to connect W3W Protocol";
        mailService.sendMailVerify(verifyCode, email, mailSubject);
        return this.pipeBrandSession(res);
    }

    async sendMailVerifyCode(req: SendEmailReq) {
        const merchant = await this.merchantRepo.findOne({
            where: {
                email: req.email
            }
        });
        if (!merchant) {
            throw new BusinessException("Account does not exist.");
        }

        let verifyCode = Math.floor(100000 + Math.random() * 900000);
        merchant.verifyCode = verifyCode;
        await this.merchantRepo.save(merchant);
        let mailSubject = "Verify your email to connect W3W Protocol";
        mailService.sendMailVerify(verifyCode, req.email, mailSubject);
        console.log("Sent an email to: ", req.email);

    }
    async verifyEmail(req: VerifyEmailReq) {
        let merchant = await this.merchantRepo.findOne({ email: req.email });
        if (merchant.isVerifyEmail) throw new BusinessException("Merchant has verified email");
        if (merchant.verifyCode == req.verifyCode) {
            merchant.verifyCode = null;
            merchant.isVerifyEmail = true;
            if (merchant.status == EMerchantStatus.DRAFT) {
                merchant.status = EMerchantStatus.PENDING;
            }

            await this.merchantRepo.save(merchant);
            return new SuccessVerifySuccessResponse();
        }
        return new SuccessVerifyFailResponse();
    }

    async login(body: BrandLoginReq) {
        const { email, password, } = body;
        const brand = await this.merchantRepo.findOne({
            where: {
                email
            }
        });
        if (!brand) {
            throw new BusinessException("Merchant account not exist");
        }

        if (brand.status == EMerchantStatus.PENDING || brand.status == EMerchantStatus.DRAFT) {
            throw new BusinessException("Merchant account not verify");
        }


        const checkPass = await securityHelper.compare(password, brand.password);
        if (!checkPass) {
            throw new BusinessException("Invalid password");
        }

        // if (brand.status < EMerchantStatus.VERIFY) {
        //     throw new BusinessException("Brand is pending verify");
        // }
        return this.pipeBrandSession(brand);
    }



    authenticate() {
        return contextSession.brandSession;
    }


    async verify(body: UUIDReq) {
        const merchantInfo = await this.merchantRepo.findOne(body.id);
        if (!merchantInfo) {
            throw new BusinessException("Merchant not existed");
        }

        if (merchantInfo.status > EMerchantStatus.PENDING) {
            throw new BusinessException(`Brand is ${getKeyEnumByValue(EMerchantStatus, merchantInfo.status)}`);
        }
        merchantInfo.status = EMerchantStatus.VERIFY;
        let merchant = await this.merchantRepo.save(merchantInfo);
        let mailSubject = "Welcome to Web3 World Protocol";
        mailService.sendMailAccountRegisterComplete(merchant.email, mailSubject);
        return merchant;
    }


    async infomation(params: UUIDReq) {
        let sql = ` SELECT mc.*, 
        ct.code "countryCode", ct.name "countryName", 
        city.code "cityCode", city.name "cityName"
        FROM merchant mc
        LEFT JOIN address addr on addr.id = mc."addressId" and addr.type = '${EAddressType.MERCHANT}'
        LEFT JOIN country ct on ct.code = addr."countryCode"
        LEFT JOIN city on city.code = addr."cityCode" 
        where mc.id = '${params.id}' `;

        let merchantInfo = await this.merchantRepo.query(sql);
        delete merchantInfo.password;
        return merchantInfo;
    }

    @DefTransaction()
    async createApiKey(keyName: string) {
        const { merchantId } = contextSession;

        const brand = await this.merchantRepo.findOne(merchantId);

        if (!brand) {
            throw new BusinessException("Merchant not existed")
        }

        if (brand.status < EMerchantStatus.VERIFY) {
            throw new BusinessException("Please contact admin verify merchant")
        }

        const brandApikey = await this.merchantApiKeyRepo.findOne({
            merchantId: merchantId,
            keyName
        });

        if (brandApikey) {
            throw new BusinessException("Key name existed")
        }

        const apiKey = securityHelper.md5(v4());
        return this.merchantApiKeyRepo.save({
            merchantId,
            keyName,
            expiredDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
            apiKey
        })
    }


    @DefTransaction()
    async deleteApiKey(id: string) {
        const { merchantId } = contextSession;
        const brand = await this.merchantRepo.findOne(merchantId);

        if (!brand) {
            throw new BusinessException("Merchant not existed")
        }

        if (brand.status < EMerchantStatus.VERIFY) {
            throw new BusinessException("Please contact admin verify merchant")
        }
        await this.merchantApiKeyRepo.delete(id);
        return new SuccessResponse();
    }

    listApiKeyByBrand(params: ListApiKeyByBrandReq) {
        const sql = `
            SELECT * FROM merchant_api_key 
            WHERE "merchantId" ='${params.merchantId}'
            ORDER BY "createdDate" DESC
        `
        return this.merchantApiKeyRepo.paginationQuery(sql, params);
    }

    list(params: ListBrandReq) {
        const sql = `
            SELECT * FROM merchant 
            ORDER BY "createdDate" DESC
        `
        return this.merchantRepo.paginationQuery<Merchant>(sql, params);
    }

    @DefTransaction()
    async updateMerchant(body: UpdateMerchantReq) {
        let merchantInfo = await this.merchantRepo.findOne(contextSession.merchantId);
        if (merchantInfo.email != body.email) throw new BusinessException("Can't change email");
        merchantInfo = { ...body, password: merchantInfo.password };
        let merchantAddress = await this.addressRepo.findOne(merchantInfo.addressId);
        if (merchantAddress) {
            merchantAddress.cityCode = body.cityCode;
            merchantAddress.countryCode = body.countryCode;
            merchantAddress = await this.addressRepo.save(merchantAddress);
        } else {
            // save address
            let merchantAddress = new Address();
            merchantAddress.objectId = merchantInfo.id;
            merchantAddress.cityCode = body.cityCode;
            merchantAddress.countryCode = body.countryCode;
            merchantAddress = await this.addressRepo.save(merchantAddress);

        }
        merchantInfo.addressId = merchantAddress.id;
        return await this.merchantRepo.save(merchantInfo);
    }

    listMerchantByType(params: ListMerchantReq) {
        const sql = `
            SELECT * FROM merchant 
            where type = '${params.type}' and status = '${EMerchantStatus.VERIFY}'
            ORDER BY "createdDate" DESC
        `
        return this.merchantRepo.paginationQuery<Merchant>(sql, params);
    }

    async getDetailMerchant(body: UUIDReq) {
        const merchant: Merchant = await this.merchantRepo.findOne(body.id);
        if (!merchant) {
            throw new BusinessException("Merchant not exists");
        }
        const numberStores = await this.storeService.countStoresByMerchant(body);
        Object.assign(merchant, {
            numberStores: numberStores,
            numberOfCountries: 1,
            numberOfCities: 1
        })
        return merchant;
    }

    async sendMailForgotPassword(params: ForgotPasswordReq) {
        const { email } = params;
        let verifyCode = Math.floor(100000 + Math.random() * 900000);
        const merchant = await this.merchantRepo.findOne({
            where: {
                email
            }
        });

        if (!merchant) {
            throw new BusinessException("Merchant account not exists.");
        }

        merchant.verifyCode = verifyCode
        await this.merchantRepo.save(merchant);
        let mailSubject = "W3W Protocol Account Reset Password";
        mailService.sendMailForgotPassword(verifyCode, email, mailSubject);
    }

    async forgotPassword(req: ForgotPasswordDto) {
        const { email, password } = req;
        let merchant = await this.merchantRepo.findOne({ email: email });
        if (merchant.verifyCode == req.verifyCode) {
            const hashPassword = await securityHelper.hash(password);
            merchant.verifyCode = null;
            merchant.password = hashPassword;
            await this.merchantRepo.save(merchant);
            return new BusinessSuccessResponse("Forgot Password Success", 1);
        }
        return new BusinessException("The verification code is incorrect");
    }
}

