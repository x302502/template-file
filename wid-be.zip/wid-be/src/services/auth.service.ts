import { BindRepo, DefTransaction, Service } from "~/@core/decorator";
import securityHelper from "~/@core/helpers/security.helper";
import { BusinessException } from "~/@systems/exceptions";
import { LoginReq, RegisterReq } from "~/dto/auth.dto";
import { UserAdminRepo } from "~/repositories/primary";
import { jwtService } from "./@common";
import { UserAdmin } from "~/entities/primary";
import { contextSession } from "~/@systems/middlewares";




@Service()
export class AuthService {

    @BindRepo(UserAdminRepo)
    private userAdminRepo: UserAdminRepo

    async pipeUserSession(user: UserAdmin) {
        delete user.password;
        const accessToken = await jwtService.sign(user);
        Object.assign(user, {
            accessToken,
        });
        return user;
    }

    @DefTransaction()
    async register(body: RegisterReq) {

        const { username, password, avatar = "", gender } = body;

        const user = await this.userAdminRepo.findOne({
            where: {
                username: username
            }
        });

        if (user) {
            throw new BusinessException("User existed");
        }

        const hashPassword = await securityHelper.hash(password);

        const res = await this.userAdminRepo.save({
            username,
            password: hashPassword,
            gender,
            avatar,
        });

        return this.pipeUserSession(res);
    }
    async login(body: LoginReq) {
        const { username, password, } = body;
        const user = await this.userAdminRepo.findOne({
            where: {
                username: username
            }
        });
        if (!user) {
            throw new BusinessException("User not exist");
        }

        console.log(`-------------------`);
        console.log(user);
        console.log(`-------------------`);
        const checkPass = await securityHelper.compare(password, user.password);
        if (!checkPass) {
            throw new BusinessException("Invalid password");
        }
        return this.pipeUserSession(user);
    }

    authenticate() {
        return contextSession.userSession;
    }

}

