import { UUID } from "crypto";
import { BindRepo, Service } from "~/@core/decorator";
import { PageRequest } from "~/@systems/utils";
import { UUIDReq } from "~/dto/@common";
import { ListTransactionByUserReq, ListTransactionReq } from "~/dto/brand.dto";
import { WalletAddressReq } from "~/dto/user.dto";
import { WidTransactionRepo } from "~/repositories/primary";




@Service()
export class WidTransactionService {


    @BindRepo(WidTransactionRepo)
    private widTransactionRepo: WidTransactionRepo


    list(params: PageRequest) {
        const sql = `
            SELECT 
                wt.*,
                mc."companyName" as "merchantName",
                pr.name as "programName",
                st.name as "storeName"
            FROM wid_transaction wt
            INNER JOIN merchant mc ON wt."merchantId" = mc.id
            INNER JOIN program pr ON wt."programId" = pr.id
            INNER JOIN store st ON wt."storeId" = st.id
        `
        return this.widTransactionRepo.paginationQuery(sql, params);
    }

    listByMerchant(params: ListTransactionReq) {
        const sql = `
            SELECT 
                wt.*,
                mc."companyName" as "merchantName",
                pr.name as "programName",
                st.name as "storeName"
            FROM (select * from wid_transaction where "merchantId" = '${params.id}' ) wt
            INNER JOIN merchant mc ON wt."merchantId" = mc.id
            INNER JOIN program pr ON wt."programId" = pr.id
            INNER JOIN store st ON wt."storeId" = st.id
            order by wt."createdDate" desc
        `
        console.log(sql);

        return this.widTransactionRepo.paginationQuery(sql, params);
    }

    listByCampaign(params: ListTransactionReq) {
        const sql = `
            SELECT 
                    wt.*,
                    mc."companyName" as "merchantName",
                    pro.name as "programName",
                    st.name as "storeName"
            FROM wid_transaction wt
            INNER JOIN merchant mc on mc."id" = wt."merchantId"
            INNER JOIN program pro on pro."id" = wt."programId"
            INNER JOIN campaign cam on cam."id" = wt."campaignId"
            INNER JOIN store st on st."id" = wt."storeId"
            WHERE cam."id" = '${params.id}'
            order by wt."createdDate" desc
        `
        console.log(sql);

        return this.widTransactionRepo.paginationQuery(sql, params);
    }

    transactionHistoryByUser(params: ListTransactionByUserReq) {
        const sql = `
            SELECT 
                wt.*,
                mc."companyName" as "merchantName",
                pr.name as "programName",
                st.name as "storeName"
            FROM wid_transaction wt
            INNER JOIN merchant mc ON wt."merchantId" = mc.id
            INNER JOIN program pr ON wt."programId" = pr.id
            INNER JOIN store st ON wt."storeId" = st.id
            INNER JOIN "user" u ON wt."userId" = u.id
            WHERE u."walletAddress" = LOWER('${params.walletAddress}')
            order by wt."createdDate" desc
        `
        return this.widTransactionRepo.paginationQuery(sql, params);
    }

    listByProgram(params: ListTransactionReq) {
        const sql = `
            SELECT 
                    wt.*,
                    mc."companyName" as "merchantName",
                    pro.name as "programName",
                    st.name as "storeName"
            FROM wid_transaction wt
            INNER JOIN merchant mc on mc."id" = wt."merchantId"
            INNER JOIN program pro on pro."id" = wt."programId"
            INNER JOIN store st on st."id" = wt."storeId"
            WHERE pro."id" = '${params.id}'
            order by wt."createdDate" desc
        `
        console.log(sql);

        return this.widTransactionRepo.paginationQuery(sql, params);
    }
}