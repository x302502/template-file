import { HttpStatus } from "@nestjs/common";
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";

export class ApiException<T = any>  {
  @ApiProperty()
  public type: string = "DEFAULT";

  public httpCode?: HttpStatus;

  @ApiPropertyOptional({ type: Number, example: -1 })
  public businessCode?: number = -1;

  @ApiPropertyOptional({ type: String })
  public message?: string;

  @ApiPropertyOptional()
  public errors?: T

  constructor(
    message: string,
    httpCode: HttpStatus = HttpStatus.INTERNAL_SERVER_ERROR,
    errors: T = undefined,
    type: string = "DEFAULT",
    businessCode: number = -1,
  ) {
    this.httpCode = httpCode;
    this.message = message;
    this.type = type;
    this.businessCode = businessCode;
    this.errors = errors;
  }
}