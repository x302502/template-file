import * as jwt from "jsonwebtoken";
export class JWTHelper {
    private privateKey: jwt.Secret;
    private publicKey: jwt.Secret;
    constructor(privateKey: jwt.Secret, publicKey: jwt.Secret) {
        this.privateKey = privateKey;
        this.publicKey = publicKey;
    }
    verify = (token: string): Promise<any> => {
        return new Promise((resolve, reject) => {
            jwt.verify(token, this.privateKey, {
                algorithms: ['HS256']
            }, (err, decoded) => {
                if (err) {
                    reject(new Error('Token not verify'));
                } else {
                    resolve(decoded);
                }
            });
        });
    }
    sign = (payload: string | Buffer | object, algorithm: jwt.Algorithm = 'HS256', expiresIn: string | number = '10h'): Promise<string> => {
        return new Promise((resolve, reject) => {
            jwt.sign({ payload }, this.privateKey, {
                algorithm,
                expiresIn
            }, (err, decoded) => {
                if (err) {
                    reject(new Error('NOT SIGN TOKEN'));
                } else {
                    resolve(decoded);
                }
            });
        });
    }

    decode = <T = any>(token: string, options?: jwt.DecodeOptions & { json: true }): jwt.JwtPayload & { payload?: T } => {
        return jwt.decode(token, options)
    }

}
