import * as amqp from 'amqplib';
import { Channel, Connection } from 'amqplib';
export interface IRabitMqConfig {
    hostname?: string, port?: number, username: string, password: string,
}



export class RabitMqHelper {
    public config: IRabitMqConfig;
    public connection: Connection;
    constructor(config: IRabitMqConfig) {
        this.config = config;
    }
    async init() {
        try {
            const { hostname = 'localhost', username, password, port = 15672 } = this.config;
            const connectionString = `amqp://${username}:${password}@${hostname}`
            console.log(`-------------------`);
            console.log({ connectionString });
            console.log(`-------------------`);
            const connection = await amqp.connect(connectionString);
            this.connection = connection;
            console.log(`=====RABIT MQ CONNECTED=====`);
        } catch (error) {
            console.log(`-------------------`);
            console.log("Connect rabit MQ error", error);
            console.log(`-------------------`);
        }
    }

    createChannel = async (): Promise<amqp.Channel> => {
        const channel = await this.connection.createChannel();
        return channel;
    }
    assertQueue = async (channel: Channel, queueName: string): Promise<void> => {
        await channel.assertQueue(queueName, { durable: false });
    }
}
