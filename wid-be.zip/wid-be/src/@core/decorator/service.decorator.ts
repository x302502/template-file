import { TClass } from "./types";
import * as services from '~/services'
import { Injectable, InjectableOptions, Inject } from "@nestjs/common";
let serviceDecoratorList = {

}
type KeyBindService = keyof typeof services;

export function Service(options: InjectableOptions & { defBindName?: string } = {}): ClassDecorator {
  return function (target: Function) {
    const { defBindName = "", ...restOptions } = options;
    Injectable(restOptions)
    const name = defBindName || target.name
    if (serviceDecoratorList[name]) {
      throw new Error(`Bean ${name} is existed`);
      // console.log(`Bean ${name} is existed`);
    }
    serviceDecoratorList[name] = target;
  }
}

export function getService<T = any>(className: KeyBindService): T {
  try {
    const currentService = serviceDecoratorList[className]();
    return currentService
  } catch (error) {
    return new serviceDecoratorList[className as string]();
  }
}

export function BindService(className: KeyBindService): PropertyDecorator {
  if (!className) {
    throw "EMPTY CLASS NAME"
  }

  return function (target: Object, propertyKey: string) {

    let val = target[propertyKey];
    Object.defineProperty(target, propertyKey, {
      get: () => {
        if (!serviceDecoratorList[className as string]) {
          throw "SERVICE NOT REGISTER BIND @Service " + className;
        }
        if (!val) {
          val = new serviceDecoratorList[className as string]();
        }
        return val;
      },
      set: (value: any) => {
        val = value;
      }
    })
  }
}


