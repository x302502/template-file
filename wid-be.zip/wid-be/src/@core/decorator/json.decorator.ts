import {
    JsonObject,
    JsonProperty,
    JsonConvert,
    OperationMode,
    ValueCheckingMode,
} from 'json2typescript'
import { Type } from '@nestjs/common';
type TJson = String | string | Number | number | Boolean | boolean | any | [String] | [string] | [Number] | [number] | [Boolean] | [boolean] | [any] | any


export function Json(name: string = ""): ClassDecorator {
    return function (target: any) {
        const nameIn = name || "";
        return JsonObject(nameIn)(target)
    }
}
export function JsonProp(name: string = "", type: Type<unknown> | Function | [Function] | string | Record<string, any> = String, isOptional: boolean = true): PropertyDecorator {
    return function (target: Object, propertyKey: string | symbol) {
        if (!name) {
            JsonProperty()(target, propertyKey as string)
        } else {
            JsonProperty(name, type, isOptional)(target, propertyKey as string)
        }
    }
}

export function deserializeObject<T extends object>(json: any, clazz: { new(): T }): T {
    try {
        const convert = new JsonConvert()
        convert.ignoreRequiredCheck = true;
        // convert.operationMode = OperationMode.LOGGING; // print some debug data
        // convert.ignorePrimitiveChecks = false; // don't allow assigning number to string etc.
        // convert.valueCheckingMode = ValueCheckingMode.DISALLOW_NULL; // never allow null
        const obj = convert.deserializeObject<T>(json, clazz)
        return obj;
    } catch (error) {
        // console.log('-------------------');
        // console.log(error);
        // console.log('-------------------');
        return new clazz()
    }
}