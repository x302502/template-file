

import { Column, Entity, Index } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";

@Entity()
export class MerchantApiKey extends PrimaryBaseEntity {

    @ApiProperty()
    @Column({ type: "uuid" })
    merchantId: string;

    @ApiProperty()
    @Column()
    keyName: string;

    @ApiProperty()
    @Index()
    @Column({ unique: true })
    apiKey: string;

    @Column({ type: 'date' })
    expiredDate: Date;

}
