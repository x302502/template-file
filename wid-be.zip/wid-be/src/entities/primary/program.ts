

import { Column, Entity, Index, JoinTable, ManyToMany } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { EUserTier } from "~/common/enums/EUserTier";
import { ENftTier } from "~/common/enums/ENftTier";
import { Campaign } from "./campaign";
import { EProgramStatus } from "~/common/enums/EProgramStatus";
import { MerchantTier } from "./merchant-tier";
import { EProgramType } from "~/common/enums/EProgramType";

@Entity()
export class Program extends PrimaryBaseEntity {

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    merchantId: string;

    @ApiProperty()
    @Column()
    name: string;

    @ApiProperty()
    @Index()
    @Column()
    code: string;

    @ApiProperty()
    @Column({ type: "int", array: true })
    w3wTiers: EUserTier[] = [];

    @ApiProperty()
    @Column({ type: "uuid", array: true, default: {} })
    merchantTiers: string[] = [];

    @ApiPropertyOptional()
    @Column({ nullable: true })
    programType?: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    desc?: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    banner?: string;

    @ApiProperty()
    @Column({ default: EProgramStatus.DRAFT })
    status: EProgramStatus;

    @ApiProperty()
    @Column()
    startTime: Date;

    @ApiProperty()
    @Column()
    endTime: Date;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    title?: string;

    @ApiPropertyOptional()
    @Column({ default: EProgramType.NORMAL })
    type?: EProgramType;
}
