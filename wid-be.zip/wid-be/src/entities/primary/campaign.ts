

import { Column, Entity, Index, JoinTable, ManyToMany } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { Program } from "./program";
import { EProgramStatus } from "~/common/enums/EProgramStatus";
import { EUserTier } from "~/common/enums";
import { MerchantTier } from "./merchant-tier";

@Entity()
export class Campaign extends PrimaryBaseEntity {
    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    merchantId: string;

    @ApiProperty()
    @Column({ type: "uuid", nullable: true })
    campaignAddressId?: string;

    @ApiProperty()
    @Column()
    name: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    countryCode: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    cityCode: string;

    @ApiProperty()
    @Column({ type: "int", array: true })
    w3wTiers: EUserTier[] = [];

    @ApiProperty()
    @Column({ type: "uuid", array: true, default: {} })
    merchantTiers: string[] = [];

    @ApiPropertyOptional()
    @Column({ nullable: true })
    banner: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    logo: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    cover: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    aboutCampaign: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    forMerchant: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    showForMerchant: boolean;

    @ApiProperty()
    @Column()
    startTime: Date;

    @ApiProperty()
    @Column()
    endTime: Date;

    @ApiPropertyOptional()
    @Column({ default: EProgramStatus.DRAFT })
    status: EProgramStatus;

    @ApiPropertyOptional()
    @Column({ type: "uuid", nullable: true })
    sourceId: string;
}
