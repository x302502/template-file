

import { Column, Entity, Index, Unique } from "typeorm"
import { ApiProperty } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";

@Entity()
@Unique('IDX_UNIQUE_USERID_MERCHANTID', ["userId", "merchantId"])
export class UserMerchantTier extends PrimaryBaseEntity {


    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    userId: string;

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    merchantId: string;

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    merchantTierId: string;


}
