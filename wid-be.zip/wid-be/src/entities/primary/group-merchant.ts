

import { Column, Entity } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { EMerchantStatus } from "~/common/enums";

@Entity()
export class GroupMerchant extends PrimaryBaseEntity {

    @ApiProperty()
    @Column({ unique: true })
    email: string;

    @ApiProperty()
    @Column()
    password: string;

    @ApiProperty()
    @Column()
    name: string;

    @ApiProperty()
    @Column()
    companyName?: string;

    @ApiPropertyOptional()
    @Column({ default: EMerchantStatus.PENDING })
    status?: EMerchantStatus;



    @ApiPropertyOptional()
    @Column({ nullable: true })
    logo?: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    website?: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    type?: string;

}
