

import { Column, Entity } from "typeorm"
import { ApiProperty } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";

@Entity()
export class City extends PrimaryBaseEntity {
    @ApiProperty()
    @Column({ nullable: true })
    name: string;

    @ApiProperty()
    @Column({ nullable: true })
    code: string;

    @ApiProperty()
    @Column({ nullable: true })
    countryCode: string;
}
