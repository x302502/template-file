

import { Column, Entity, Index } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { EAddressStatus } from "~/common/enums/EAddressStatus";

@Entity()
export class StoreAddress extends PrimaryBaseEntity {
    
    @ApiProperty()
    @Column({ type: "uuid", nullable: true })
    storeId: string;

    @ApiPropertyOptional()
    @Column({ default: EAddressStatus.ACTIVE })
    status: EAddressStatus;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    countryCode: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    cityCode: string;

}
