

import { Column, Entity, Index } from "typeorm"
import { ApiProperty } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";

@Entity()
export class WidTransaction extends PrimaryBaseEntity {


    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    userId: string;

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    merchantId: string;

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    programId: string;


    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    storeId: string;

    @ApiProperty()
    @Index()
    @Column()
    storeCode: string;

    @ApiProperty()
    @Index()
    @Column()
    programCode: string;

    @ApiProperty()
    @Index()
    @Column()
    apiKey: string;

    @ApiProperty()
    @Index()
    @Column()
    wid: string;


    @ApiProperty()
    @Column({ type: "uuid", nullable: true })
    campaignId?: string;

}
