

import { AfterLoad, BeforeInsert, BeforeUpdate, Column, Entity, Index } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { IsEthereumAddress } from "class-validator";
import { ENftTier } from "~/common/enums/ENftTier";
import { ConfigRankDto } from "~/dto/config-rank.dto";
import { EMerchantTierType } from "~/common/enums/EMerchantTierType";
import { EMerchantTierStatus } from "~/common/enums/EMerchantTierStatus";

@Entity()
export class MerchantTier extends PrimaryBaseEntity {
    @ApiProperty()
    @Index()
    @Column()
    name: string;

    @IsEthereumAddress()
    @ApiProperty()
    @Index()
    @Column()
    contractAddress: string;

    @ApiProperty()
    @Index()
    @Column()
    chainId: number;

    @ApiProperty()
    @Column({ type: "uuid", nullable: true })
    merchantId: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    type: EMerchantTierType;

    @ApiPropertyOptional()
    @Column({ default: EMerchantTierStatus.PENDING })
    status: EMerchantTierStatus;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    icon: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    tierName: string;

    @ApiPropertyOptional()
    @Column({ nullable: true, type: "double precision" })
    minQuantity: number;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    benefit: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    description: string;

    @BeforeInsert()
    @BeforeUpdate()
    @AfterLoad()
    lowercaseFields() {
        if (this.contractAddress) {
            this.contractAddress = this.contractAddress.toLowerCase();
        }

    }
}
