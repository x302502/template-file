

import { Column, Entity, Index } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";

@Entity()
export class Store extends PrimaryBaseEntity {

    @ApiProperty()
    @Column({ type: "uuid", nullable: true })
    addressId?: string;

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    merchantId: string;

    @ApiProperty()
    @Index()
    @Column()
    storeCode: string;

    @ApiProperty()
    @Column({})
    name: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    address?: string;

}
