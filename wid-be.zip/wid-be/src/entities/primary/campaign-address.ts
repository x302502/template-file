

import { Column, Entity } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { EAddressStatus } from "~/common/enums/EAddressStatus";

@Entity()
export class CampaignAddress extends PrimaryBaseEntity {
    @ApiProperty()
    @Column({ type: "uuid", nullable: true })
    addressId?: string;
    
    @ApiProperty()
    @Column({ type: "uuid", nullable: true })
    campaignId: string;

    @ApiPropertyOptional()
    @Column({ default: EAddressStatus.ACTIVE })
    status: EAddressStatus;
}
