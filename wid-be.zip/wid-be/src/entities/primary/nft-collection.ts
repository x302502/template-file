

import { AfterLoad, BeforeInsert, BeforeUpdate, Column, Entity, Index } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { IsEthereumAddress } from "class-validator";
import { ECollectionStatus } from "~/common/enums/ECollectionStatus";


@Entity()
export class NftCollection extends PrimaryBaseEntity {

    @ApiProperty()
    @Column()
    chainId: number;

    @IsEthereumAddress()
    @ApiProperty()
    @Index()
    @Column()
    address: string;

    @ApiProperty()
    @Column({ default: "" })
    name: string;


    @ApiPropertyOptional()
    @Column({ default: "" })
    description?: string;

    @ApiPropertyOptional()
    @Column({ nullable: true, })
    image?: string;

    @ApiPropertyOptional()
    @Column({ default: "" })
    symbol?: string;


    @Column({ default: 0, type: "float" })
    floorPrice: number;

    @ApiPropertyOptional()
    @Column({ default: ECollectionStatus.INACTIVE })
    status?: ECollectionStatus;

    @Column({ default: 0 })
    totalSupply: number;

    @Column({ default: '{}' })
    links?: string; // JSON.stringify


    @BeforeInsert()
    @BeforeUpdate()
    @AfterLoad()
    lowercaseFields() {
        if (this.address) {
            this.address = this.address.toLowerCase();
        }
    }

}
