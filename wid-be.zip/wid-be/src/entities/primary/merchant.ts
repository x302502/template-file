

import { Column, Entity, Index, ManyToMany } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { EMerchantStatus } from "~/common/enums";
import { EMerchantType } from "~/common/enums/EMerchantType";

@Entity()
export class Merchant extends PrimaryBaseEntity {

    @ApiProperty()
    @Column({ type: "uuid", nullable: true })
    addressId?: string;

    @ApiProperty()
    @Column({ unique: true })
    email: string;

    @ApiProperty()
    @Column()
    password: string;

    @ApiProperty()
    @Column()
    name: string;

    @ApiProperty()
    @Column()
    companyName?: string;

    @ApiPropertyOptional()
    @Column({ default: EMerchantStatus.DRAFT })
    status?: EMerchantStatus;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    logo?: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    banner?: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    website?: string;

    @ApiPropertyOptional()
    @Column({ default: EMerchantType.MERCHART })
    type?: EMerchantType;

    @ApiProperty()
    @Column({ nullable: true })
    store?: number;

    @ApiProperty()
    @Column({ nullable: true })
    industry?: string;

    @ApiProperty()
    @Column({ nullable: true })
    aboutUs?: string;

    @ApiProperty()
    @Column({ nullable: true })
    verifyCode?: number;

    @ApiProperty()
    @Column({ nullable: true })
    isVerifyEmail?: boolean;

    @ApiProperty()
    @Column({ nullable: true })
    description?: string;

    @ApiProperty()
    @Column({ nullable: true })
    link?: string;
}
