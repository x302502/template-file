

import { AfterLoad, BeforeInsert, BeforeUpdate, Column, Entity, Index } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { } from "~/common/enums";
import { IsEthereumAddress } from "class-validator";
import { ENftType } from "~/common/enums/ENftType";
import { Metadata } from "~/dto/nft.dto";

@Entity()
export class UserNft extends PrimaryBaseEntity {

    @ApiProperty()
    @Index()
    @Column()
    chainId: number;

    @IsEthereumAddress()
    @ApiProperty()
    @Index()
    @Column({})
    address: string;

    @ApiProperty()
    @Index()
    @Column()
    tokenId: string;

    @IsEthereumAddress()
    @ApiProperty()
    @Index()
    @Column({})
    owner: string;

    @ApiProperty()
    @Column()
    amount: number;

    @ApiProperty({ enum: ENftType })
    @Column()
    contractType: ENftType;

    @ApiProperty()
    @Column()
    name: string;


    @ApiPropertyOptional()
    @Column({ nullable: true, })
    description?: string;

    @ApiPropertyOptional()
    @Column({ nullable: true, })
    image?: string;

    @ApiPropertyOptional()
    @Column()
    symbol?: string;

    @ApiPropertyOptional()
    @Column()
    tokenUri?: string;

    @ApiPropertyOptional()
    @Column({ type: "jsonb", nullable: true })
    metadata?: Metadata;


    @BeforeInsert()
    @BeforeUpdate()
    @AfterLoad()
    lowercaseFields() {
        if (this.address) {
            this.address = this.address.toLowerCase();
        }
        if (this.owner) {
            this.owner = this.owner.toLowerCase();
        }
    }

}
