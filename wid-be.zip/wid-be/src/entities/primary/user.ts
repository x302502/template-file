

import { AfterLoad, BeforeInsert, BeforeUpdate, Column, Entity, Index } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { EUserStatus } from "~/common/enums";
import { EUserTier } from "~/common/enums/EUserTier";

@Entity()
export class User extends PrimaryBaseEntity {

    @ApiProperty()
    @Index({ unique: true })
    @Column({ unique: true })
    walletAddress: string;

    @ApiProperty()
    @Index({ unique: true })
    @Column({ unique: true })
    wid: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    email?: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    fullName?: string;


    @ApiPropertyOptional()
    @Index()
    @Column({ default: EUserTier.NONTIER })
    tier?: EUserTier;


    @ApiPropertyOptional()
    @Column({ default: EUserStatus.INACTIVE })
    status?: EUserStatus;

    @ApiProperty()
    @Column({ default: new Date() })
    lastTimeSyncTier: Date;


    @BeforeInsert()
    @BeforeUpdate()
    @AfterLoad()
    lowercaseFields() {
        if (this.walletAddress) {
            this.walletAddress = this.walletAddress.toLowerCase();
        }
    }

}
