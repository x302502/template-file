

import { Column, Entity, Index } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";

@Entity()
export class ProgramStore extends PrimaryBaseEntity {

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    merchantId: string;

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    programId: string;

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    storeId: string;

    @ApiProperty()
    @Column({ nullable: true })
    status: string;

}
