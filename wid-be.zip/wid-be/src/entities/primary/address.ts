

import { Column, Entity } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { EAddressType } from "~/common/enums/EAddressType";

@Entity()
export class Address extends PrimaryBaseEntity {
    @ApiProperty()
    @Column({ type: "uuid", nullable: true })
    objectId?: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    countryCode: string;

    @ApiPropertyOptional()
    @Column({ nullable: true })
    cityCode: string;


    @ApiPropertyOptional()
    @Column({ default: EAddressType.MERCHANT })
    type: EAddressType;
}
