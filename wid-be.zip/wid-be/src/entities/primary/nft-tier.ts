

import { AfterLoad, BeforeInsert, BeforeUpdate, Column, Entity, Index } from "typeorm"
import { ApiProperty } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { IsEthereumAddress } from "class-validator";
import { ENftTier } from "~/common/enums/ENftTier";

@Entity()
export class NftTier extends PrimaryBaseEntity {

    @IsEthereumAddress()
    @ApiProperty()
    @Index()
    @Column()
    address: string;

    @ApiProperty()
    @Index()
    @Column()
    chainId: number;

    @ApiProperty()
    @Index()
    @Column({ default: ENftTier.NONTIER })
    tier: ENftTier;


    @BeforeInsert()
    @BeforeUpdate()
    @AfterLoad()
    lowercaseFields() {
        if (this.address) {
            this.address = this.address.toLowerCase();
        }

    }
}
