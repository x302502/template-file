

import { Column, Entity } from "typeorm"
import { ApiProperty } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";

@Entity()
export class Country extends PrimaryBaseEntity {
    @ApiProperty()
    @Column()
    name: string;

    @ApiProperty()
    @Column()
    code: string;
}
