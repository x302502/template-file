

import { Column, Entity, Index } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { EMerchantStatus, EGender, EUserAdminStatus } from "~/common/enums";

@Entity()
export class UserAdmin extends PrimaryBaseEntity {


    @ApiProperty()
    @Index({ unique: true })
    @Column({ type: 'varchar', unique: true })
    username: string;

    @ApiProperty()
    @Column({ type: 'varchar' })
    password: string;


    @ApiProperty()
    @Column({ type: 'integer', default: EUserAdminStatus.INACTIVE })
    status?: number;

    @ApiPropertyOptional()
    @Column({ type: 'varchar', default: EGender.OTHER, nullable: true })
    gender?: string;


    @ApiPropertyOptional()
    @Column({ type: 'varchar', nullable: true })
    avatar?: string;

}
