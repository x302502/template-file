

import { Column, Entity, Index } from "typeorm"
import { ApiProperty, ApiPropertyOptional } from "@nestjs/swagger";
import { PrimaryBaseEntity } from "../primary-base.entity";
import { ERequestStatus } from "~/common/enums/ERequestStatus";
import { ERequestType } from "~/common/enums/ERequestType";

@Entity()
export class CampaignProgram extends PrimaryBaseEntity {

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    programId: string;

    @ApiProperty()
    @Index()
    @Column({ type: "uuid" })
    campaignId: string;

    @ApiProperty()
    @Column({ default: ERequestStatus.NOT_APPLY })
    status: ERequestStatus;

    @ApiProperty()
    @Column({ default: ERequestType.PROGRAM_REQUEST })
    type: ERequestType;

}
