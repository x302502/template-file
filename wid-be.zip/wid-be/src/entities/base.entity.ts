import { ApiProperty } from '@nestjs/swagger';
import { Exclude } from 'class-transformer';
import { IsUUID } from 'class-validator';
import { Column, CreateDateColumn, Index, ObjectID, PrimaryGeneratedColumn, UpdateDateColumn, VersionColumn } from 'typeorm';


// PostgreSQL
export class BaseEntityPostgreSql {
  @ApiProperty()
  @PrimaryGeneratedColumn("uuid")
  @IsUUID(4)
  id: string;

  @Index()
  @ApiProperty()
  @CreateDateColumn()
  createdDate: Date;

  @Index()
  @ApiProperty()
  @UpdateDateColumn()
  modifiedDate: Date;

  @Index()
  @ApiProperty()
  @Column("uuid", { name: "createdBy", nullable: true })
  createdBy: string | null;

  @Index()
  @ApiProperty()
  @Column("uuid", { name: "modifiedBy", nullable: true })
  modifiedBy: string | null;

  @Exclude()
  @VersionColumn({ default: 0 })
  version: number;

}

export abstract class BaseEntityMongo {

  @PrimaryGeneratedColumn('uuid')
  id: ObjectID;

  @Index()
  @ApiProperty()
  @CreateDateColumn()
  createdDate: Date;

  @Index()
  @ApiProperty()
  @UpdateDateColumn()
  modifiedDate: Date;

  @Index()
  @ApiProperty()
  @Column("uuid", { name: "createdBy", nullable: true })
  createdBy: string | null;

  @Index()
  @ApiProperty()
  @Column("uuid", { name: "modifiedBy", nullable: true })
  modifiedBy: string | null;

  @Exclude()
  @VersionColumn({ default: 0 })
  version: number;

}
export abstract class BaseEntitySql {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Index()
  @ApiProperty()
  @CreateDateColumn()
  createdDate: Date;

  @Index()
  @ApiProperty()
  @UpdateDateColumn()
  modifiedDate: Date;

  @Index()
  @ApiProperty()
  @Column("int", { name: "createdBy", nullable: true })
  createdBy: string | null;

  @Index()
  @ApiProperty()
  @Column("int", { name: "modifiedBy", nullable: true })
  modifiedBy: string | null;

  @Exclude()
  @VersionColumn({ default: 0 })
  version: number;

}
