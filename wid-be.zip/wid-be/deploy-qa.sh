
now="$(date +'%Y-%m-%d %H:%M:%S')"
message="update $now";
git add . ;
git commit -m "$message";
git push;

ssh root@143.198.220.202 "
    cd /opt/back-end/; 
    rm -rf qa.api.wid.famcentral.io;
    git clone -b qa --single-branch https://gitlab.com/f-holding/wid-be.git qa.api.wid.famcentral.io; 
    cd qa.api.wid.famcentral.io/;
    yarn; 
    yarn start:qa; 
    exit;
"