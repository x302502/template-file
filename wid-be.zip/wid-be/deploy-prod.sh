
now="$(date +'%Y-%m-%d %H:%M:%S')"
message="update $now";
git add . ;
git commit -m "$message";
git push;

ssh root@157.230.252.203 "
    cd /opt/back-end/; 
    rm -rf api.wid.famcentral.io;
    git clone -b prod --single-branch https://gitlab.com/f-holding/wid-be.git api.wid.famcentral.io; 
    cd api.wid.famcentral.io/;
    yarn; 
    yarn start:prod; 
    exit;
"