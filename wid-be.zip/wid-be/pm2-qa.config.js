module.exports = {
    apps: [
        {
            name: "qa.api.wid.famcentral.io",
            script: "./build/main.js",
            instances: "1", // "2" "max"
            autorestart: true,
            watch: false,
            max_memory_restart: "4G",
            out_file: "./../logs/back-end/qa.api.wid.famcentral.io/access.log",
            error_file: "./../logs/back-end/qa.api.wid.famcentral.io/error.log",
            log_date_format: "YYYY-MM-DD HH:mm:ss",
            merge_logs: true,
            env: {
                NODE_ENV: "qa",
                TZ: "UTC",
                PORT: 6001,
            },
        },
    ],
};