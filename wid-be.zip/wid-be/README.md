# SWM REPORT LOGS

## To run RABITMQ as Docker container

1. Start RABITMQ services

```
docker-compose up -d
```

2. Stop RABITMQ services

```
docker-compose down
```

## To run this project

```
npm run dev or npm start
```
