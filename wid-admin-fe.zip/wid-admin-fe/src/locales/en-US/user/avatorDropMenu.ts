export const enUS_avatorDropMenu = {
  'header.avator.account': 'Account',
  'header.avator.logout': 'Logout',
  'global.theme.switchTheme': 'Switch Theme',
  'global.theme.switchingTheme': 'Switching Theme...',
  'global.theme.switchThemeDone': 'Update theme successfully!',
  'global.theme.switchThemeFail': 'Update theme fail',
};
