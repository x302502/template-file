export const enUS_tagsViewDropMenu = {
  'tagsView.operation.closeCurrent': 'Close Current',
  'tagsView.operation.closeOther': 'Close Other',
  'tagsView.operation.closeAll': 'Close All',
  'tagsView.operation.dashboard': 'Dashboard',
};
