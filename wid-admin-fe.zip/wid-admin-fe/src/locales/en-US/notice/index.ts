export const enUS_notice = {
  'app.notice.messages': `Messages`,
  'app.notice.news': `News`,
  'app.notice.tasks': `Tasks`,
};
