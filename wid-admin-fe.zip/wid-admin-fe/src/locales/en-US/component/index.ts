export const en_US_component = {
  'component.search.request': 'Request',
  'component.search.reset': 'Reset',
  'component.search.name': 'Name',
  'component.search.sex': 'Sex',
  'component.search.male': 'Male',
  'component.search.female': 'Female',
};
