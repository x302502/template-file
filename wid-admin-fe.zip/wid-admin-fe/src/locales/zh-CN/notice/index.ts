export const zhCN_notice = {
  'app.notice.messages': `通知`,
  'app.notice.news': `消息`,
  'app.notice.tasks': `待办`,
};
