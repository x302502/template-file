export const zhCN_component = {
  'component.search.request': '查询',
  'component.search.reset': '重置',
  'component.search.name': '姓名',
  'component.search.sex': '性别',
  'component.search.male': '男',
  'component.search.female': '女',
};
