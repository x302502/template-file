export const zhCN_tagsViewDropMenu = {
  'tagsView.operation.closeCurrent': '关闭当前',
  'tagsView.operation.closeOther': '关闭其他',
  'tagsView.operation.closeAll': '关闭全部',
  'tagsView.operation.dashboard': '首页',
};
