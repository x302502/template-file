export const zhCN_avatorDropMenu = {
  'header.avator.account': '个人设置',
  'header.avator.logout': '退出登录',
  'global.theme.switchTheme': '切换主题',
  'global.theme.switchingTheme': '切换主题中...',
  'global.theme.switchThemeDone': '主题更新成功',
  'global.theme.switchThemeFail': '主题更新失败',
};
