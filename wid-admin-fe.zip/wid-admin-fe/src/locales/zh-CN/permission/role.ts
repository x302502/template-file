export const zhCN_permissionRole = {
  'app.permission.role.name': '角色名称',
  'app.permission.role.code': '角色编码',
  'app.permission.role.status': '状态',
  'app.permission.role.status.all': '全部',
  'app.permission.role.status.enabled': '启用',
  'app.permission.role.status.disabled': '禁用',
  'app.permission.role.nameRequired': '请输入角色名称',
  'app.permission.role.codeRequired': '请输入角色编码',
  'app.permission.role.statusRequired': '请选择角色启用状态',
};
