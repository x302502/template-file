
export class GridRow<T = any> {
  rowId: string;
  disabled: boolean = false;
  editable?: boolean = false;
  isLoading: boolean = false;
  item: T;
  prevItem?: T;
}
