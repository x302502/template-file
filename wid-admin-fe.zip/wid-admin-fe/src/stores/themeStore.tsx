
import { theme } from "antd";
import { ConfigProviderProps, ThemeConfig } from "antd/es/config-provider";
import { createContext, Dispatch, SetStateAction, useCallback, useContext, useEffect, useMemo, useState } from "react";


type IThemeMode = "default" | "compact";
type IThemeStyle = "light" | "dark";



type SetStateType<T> = Dispatch<SetStateAction<T>>

// type SetStateType<T = any> = (value: T) => void;

interface IThemeStore {
  mode: IThemeMode;
  themeStyle: IThemeStyle;
  setThemeStyle: SetStateType<IThemeStyle>;
  themConfig: ThemeConfig
  changeTheme: (themeOption: { mode?: "default" | "compact", themeStyle?: "light" | "dark" }) => void;
}



const ThemeStoreContext = createContext<IThemeStore | undefined>(undefined);

const colorPrimary = 'rgb(65, 148, 255) ';


const ThemeStoreProvider = ({ children }: { children: React.ReactNode; }) => {

  const { token } = theme.useToken();
  const [mode, setMode] = useState<IThemeMode>("default");
  const [themeStyle, setThemeStyle] = useState<IThemeStyle>("dark");
  const [themConfig, setThemConfig] = useState<ThemeConfig>({
  });



  useEffect(() => {
    console.log(`=====Update customVars=====`);
    // const themeVars = {};
    const algorithm = [];
    if (themeStyle === 'dark') {
      algorithm.push(theme.darkAlgorithm)
    } else {
      algorithm.push(theme.defaultAlgorithm)
    }
    if (mode === "compact") {
      algorithm.push(theme.compactAlgorithm)
    }


    //  @select-item-selected-option-color: @primary-color;
    // @processing-color: @primary-color;
    // @select-item-selected-bg: @background-color-base;
    // @secondary-color: @primary-color;
    // @skeleton-color: @primary-color;
    // @btn-primary-bg: @primary-color;
    // @layout-header-background: @background-color-base;

    setThemConfig({
      algorithm,
      token: {

        colorPrimary,
      },
      components: {
        Layout: {
          colorBgHeader: theme.defaultConfig.token.colorBgBase
        },
        // Form: {
        //   colorBgContainer: token.colorBgTextActive
        // }
        // Slider: {

        // }
        // Input: {
        //   colorBgLayout: theme.defaultConfig.token.colorBgBase
        // }
      }
    })
  }, [mode, themeStyle, token])



  const changeTheme = useCallback((themeOption: { mode?: "default" | "compact", themeStyle?: "light" | "dark" }) => {
    if (!themeOption || Object.keys(themeOption).length === 0) {
      return;
    }
    const { mode = undefined, themeStyle = undefined } = themeOption;
    if (!mode && !themeStyle) {
      return;
    }
    if (mode) {
      setMode(mode);
    }
    if (themeStyle) {
      setThemeStyle(themeStyle);
    }

  }, []);


  const values = useMemo(
    () => ({
      themeStyle,
      setThemeStyle,
      mode,
      themConfig,
      changeTheme,
    }),
    [changeTheme, mode, themConfig, themeStyle]
  )

  return <ThemeStoreContext.Provider value={values}>{children}</ThemeStoreContext.Provider>

}

const useThemeStore = () => {
  const context = useContext(ThemeStoreContext);
  if (context === undefined) {
    throw new Error('useWallet hook must be used with a ThemeStoreContext component')
  }
  return context;
}

export {
  ThemeStoreProvider,
  useThemeStore,
}



