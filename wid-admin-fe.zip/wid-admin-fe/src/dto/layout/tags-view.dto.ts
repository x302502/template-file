

export class TabViewItem {
  id: string;
  label: string;
  closable: boolean = true;
  component: any;
};

