
import { v4 } from "uuid";

export class MenuItemDto {
  key: string = v4();
  label: string;
  component?: any;
  tabClosable?: boolean = true;
  icon?: React.ReactNode;
  children?: MenuItemDto[];
}
export type TabItem = Omit<MenuItemDto, 'children'>;
