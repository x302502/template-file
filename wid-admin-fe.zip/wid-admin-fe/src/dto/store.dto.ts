import { PageRequest } from "~/@ui/GridControl/models"
import { PrimaryBaseEntity } from "./@common"


export class ListAdminStoreReq extends PageRequest {

}


export interface Store extends PrimaryBaseEntity {
  addressId: string
  merchantId: string
  storeCode: string
  name: string
  address?: string
}
