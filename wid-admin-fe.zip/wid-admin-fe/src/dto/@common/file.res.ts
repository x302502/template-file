
export class FileRes {

  fileName?: string;
  originalname?: string;
  mimetype?: string;
  size?: number
  cndUrl?: string;
  fullUrl?: string;
}
