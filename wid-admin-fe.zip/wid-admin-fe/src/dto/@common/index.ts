export * from "./file.res";
export * from "./base.dto";
