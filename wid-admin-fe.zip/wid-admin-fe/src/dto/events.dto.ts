import { ESessionSourceLink } from "~/common/enums";

export interface EventDto {
  _id?: string;
  name?: string;
  banner?: string;
  startTime?: Date;
  endTime?: Date;
  mode?: string;
  type?: string;
  status?: number;
  organizer?: string;
  formJoin?: string;
  eventRule?: string;
  acceptSourceLinks?: ESessionSourceLink[];
  certification?: string;
  criteria?: any[];
  desc?: string;
  userRefIds?: any[];
  userBid?: Record<string, string>;
  bonusEMove?: number;
  totalShares?: number;
  __v?: number;
}
