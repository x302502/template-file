import { PageRequest } from "~/@ui/GridControl/models"
import { EMerchantStatus } from "~/common/enums"
import { PrimaryBaseEntity } from "./@common"

export interface Merchant {
  id: string
  createdDate: string
  updatedDate: string
  createdBy: any
  updatedBy: any
  version: number
  email: string
  name: string
  companyName: string
  status: EMerchantStatus
  logo: string
  website: string
}
export interface MerchantApiKey {
  merchantId: string
  keyName: string
  expiredDate: string
  apiKey: string
  createdBy: any
  updatedBy: any
  id: string
  createdDate: string
  updatedDate: string
  version: number
}

export class ListApiKeyByMerchantReq extends PageRequest {
  merchantId: string;
}


export interface MerchantTier extends PrimaryBaseEntity {

  name: string
  contractAddress: string
  chainId: number
  merchantId: string
  type: number
  status: number
  icon: string
  tierName: string
  minQuantity: number
  benefit: string
  description: string
}

export interface ProgramDto extends PrimaryBaseEntity {
  merchantId: string
  name: string
  code: string
  w3wTiers: number[]
  programType: string
  desc: string
  banner: string
  status: number
  startTime: string
  endTime: string
  title: string
  merchantTiers: string[]
  listMerchantTier: MerchantTier[]
  merchant: Merchant;
}


export interface CampaignDto extends PrimaryBaseEntity {
  merchantId: string
  campaignAddressId: string;
  name: string
  countryCode: string;
  cityCode: string;
  w3wTiers: number[]
  banner: string
  logo: string;
  cover: string;
  aboutCampaign: string;
  forMerchant: string;
  showForMerchant: string;
  startTime: string
  endTime: string
  status: number
  sourceId: string;
  merchantTiers: string[]
  merchant: Merchant
  listMerchantTier: MerchantTier[]
}
