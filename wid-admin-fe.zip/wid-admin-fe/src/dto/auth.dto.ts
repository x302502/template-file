
import { EGender, EUserAdminStatus } from "~/common/enums"



export class LoginReq {
  username: string
  password: string
}

export class RegisterReq {

  username: string
  password: string
  gender?: EGender;
  avatar?: string
}

export class UserSessionDto {

  id: string
  username: string;
  status: EUserAdminStatus;
  gender?: EGender;
  avatar?: string;
  accessToken: string;
}
