
import { CampaignDto } from "~/dto/merchant.dto";
import { rootApiService } from "./@common";
import { PageRequest, PageResponse } from "~/@ui/GridControl/models";
import { UUIDReq } from "~/dto";


const Enpoint = {
  list: "/api/admin/campaigns/list".trim(),
  verifyCampaign: "/api/admin/campaigns/verify-campaign".trim(),
  rejectRequestCampaign: "/api/admin/campaigns/reject-request-campaign".trim(),
  suspendCampaign: "/api/admin/campaigns/suspend-campaign".trim(),
}

export class CampaignService {

  async list(params: PageRequest) {
    return rootApiService.get<PageResponse<CampaignDto>>(Enpoint.list, params);
  }


  async verifyCampaign(body: UUIDReq) {
    return rootApiService.post<PageResponse<CampaignDto>>(Enpoint.verifyCampaign, body);
  }

  async rejectRequestCampaign(body: UUIDReq) {
    return rootApiService.post<PageResponse<CampaignDto>>(Enpoint.rejectRequestCampaign, body);
  }

  async suspendCampaign(body: UUIDReq) {
    return rootApiService.post<PageResponse<CampaignDto>>(Enpoint.suspendCampaign, body);
  }


}

// eslint-disable-next-line import/no-anonymous-default-export
export default new CampaignService();
