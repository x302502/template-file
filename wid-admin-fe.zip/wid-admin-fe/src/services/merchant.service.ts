
import { Merchant, MerchantApiKey, ListApiKeyByMerchantReq } from "~/dto/merchant.dto";
import { rootApiService } from "./@common";
import { PageRequest, PageResponse } from "~/@ui/GridControl/models";
import { UUIDReq } from "~/dto";


const Enpoint = {
  list: "/api/admin/merchants/list".trim(),
  verify: "/api/admin/merchants/verify".trim(),
  listApiKey: "/api/admin/merchants/list-api-key".trim(),
  listMerchantApiKey: "/api/admin/api-key/list".trim(),
}

export class MerchantService {

  async list(params: PageRequest) {
    return rootApiService.get<PageResponse<Merchant>>(Enpoint.list, params);
  }
  async listApiKey(params: ListApiKeyByMerchantReq) {
    return rootApiService.get<PageResponse<MerchantApiKey>>(Enpoint.listApiKey, params);
  }

  async listMerchantApiKey(params: PageRequest) {
    return rootApiService.get<PageResponse<MerchantApiKey>>(Enpoint.listMerchantApiKey, params);
  }


  async verify(body: UUIDReq) {
    return rootApiService.post<PageResponse<Merchant>>(Enpoint.verify, body);
  }
}

// eslint-disable-next-line import/no-anonymous-default-export
export default new MerchantService();
