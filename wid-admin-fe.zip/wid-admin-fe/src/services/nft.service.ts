import { } from "~/dto";
import { rootApiService } from "./@common";
import { LoginReq, UserSessionDto } from "~/dto/auth.dto";
import { PageRequest, PageResponse } from "~/@ui/GridControl/models";
import { Merchant } from "~/dto/merchant.dto";

const Enpoint = {
  listCollection: "/api/admin/nfts/list-collection".trim(),
}

export class NftService {
  async listCollection(params: PageRequest) {
    return rootApiService.get<PageResponse<any>>(Enpoint.listCollection, params);
  }
}

// eslint-disable-next-line import/no-anonymous-default-export
export default new NftService();
