import { } from "~/dto";
import { EventDto } from "~/dto/events.dto";
import { rootApiService } from "./@common";

const Enpoint = {
  create: "/api/admin/events/create".trim(),
  update: "/api/admin/events/update".trim(),
  detail: "/api/admin/events/detail".trim(),
  getListEvent: "/api/admin/events/list".trim(),
}

export class AdminEventService {

  async getListEvent(params: { pageIndex: number, pageSize: number }) {
    return rootApiService.get<{ data: EventDto[], total: number }>(Enpoint.getListEvent, params);
  }

  async detail(params: { id: string }) {
    return rootApiService.get<EventDto>(Enpoint.detail, params);
  }
  async create(body: Partial<EventDto>) {
    return rootApiService.post<EventDto>(Enpoint.create, body);
  }

  async update(body: { id: string } & Partial<EventDto>) {
    return rootApiService.post<EventDto>(Enpoint.update, body);
  }




}

// eslint-disable-next-line import/no-anonymous-default-export
export default new AdminEventService();
