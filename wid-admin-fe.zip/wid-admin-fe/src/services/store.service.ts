
import { Merchant, MerchantApiKey, ListApiKeyByMerchantReq } from "~/dto/merchant.dto";
import { rootApiService } from "./@common";
import { PageRequest, PageResponse } from "~/@ui/GridControl/models";
import { UUIDReq } from "~/dto";
import { Store } from "~/dto/store.dto";


const Enpoint = {
  list: "/api/admin/stores/list".trim(),
}

export class StoreService {

  async list(params: PageRequest) {
    return rootApiService.get<PageResponse<Store>>(Enpoint.list, params);
  }

}

// eslint-disable-next-line import/no-anonymous-default-export
export default new StoreService();
