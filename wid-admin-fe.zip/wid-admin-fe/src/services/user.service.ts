import { } from "~/dto";
import { rootApiService } from "./@common";
import { LoginReq, UserSessionDto } from "~/dto/auth.dto";
import { PageRequest, PageResponse } from "~/@ui/GridControl/models";
import { Merchant } from "~/dto/merchant.dto";

const Enpoint = {
  list: "/api/admin/users/list".trim(),
}

export class UserService {
  async list(params: PageRequest) {
    return rootApiService.get<PageResponse<any>>(Enpoint.list, params);
  }
}

// eslint-disable-next-line import/no-anonymous-default-export
export default new UserService();
