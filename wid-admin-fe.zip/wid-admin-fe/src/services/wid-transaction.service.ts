import { rootApiService } from "./@common";
import { PageRequest, PageResponse } from "~/@ui/GridControl/models";

const Enpoint = {
  list: "/api/admin/transactions/list".trim(),
}

export class WidTransactionService {
  async list(params: PageRequest) {
    return rootApiService.get<PageResponse<any>>(Enpoint.list, params);
  }
}

// eslint-disable-next-line import/no-anonymous-default-export
export default new WidTransactionService();
