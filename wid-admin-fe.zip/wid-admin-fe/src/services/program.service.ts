
import { ProgramDto } from "~/dto/merchant.dto";
import { rootApiService } from "./@common";
import { PageRequest, PageResponse } from "~/@ui/GridControl/models";
import { UUIDReq } from "~/dto";


const Enpoint = {
  list: "/api/admin/programs/list".trim(),
  verifyProgram: "/api/admin/programs/verify-program".trim(),
  rejectRequestProgram: "/api/admin/programs/reject-request-program".trim(),
  suspendProgram: "/api/admin/programs/suspend-program".trim(),
}

export class ProgramService {

  async list(params: PageRequest) {
    return rootApiService.get<PageResponse<ProgramDto>>(Enpoint.list, params);
  }


  async verifyProgram(body: UUIDReq) {
    return rootApiService.post<PageResponse<ProgramDto>>(Enpoint.verifyProgram, body);
  }

  async rejectRequestProgram(body: UUIDReq) {
    return rootApiService.post<PageResponse<ProgramDto>>(Enpoint.rejectRequestProgram, body);
  }

  async suspendProgram(body: UUIDReq) {
    return rootApiService.post<PageResponse<ProgramDto>>(Enpoint.suspendProgram, body);
  }


}

// eslint-disable-next-line import/no-anonymous-default-export
export default new ProgramService();
