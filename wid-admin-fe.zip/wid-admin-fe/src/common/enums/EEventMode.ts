export enum EEventMode {
  Public = "Public",
  Private = "Private",
};
