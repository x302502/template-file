


export enum EEventStatus {
  InProgress = 1,
  Comming,
  Finish,
}
