export enum ESessionSourceLink {
  MOVERSE = "MOVERSE",
  STRAVA = "STRAVA",
};
