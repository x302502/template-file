export enum EEventFormJoin {
  Personal = "Personal",
  Team = "Team",
};
