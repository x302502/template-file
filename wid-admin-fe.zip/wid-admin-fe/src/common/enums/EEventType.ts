export enum EEventType {
  Challenge = "Challenge",
};
