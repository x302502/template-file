export enum EMerchantStatus {
    PENDING = 1,
    VERIFY,
    RELEASE
}
