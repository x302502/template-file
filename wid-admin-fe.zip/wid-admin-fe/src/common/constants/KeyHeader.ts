export const KeyHeader = {
  AUTHORIZATION: 'Authorization',
  LANG: 'lang',
  STOREID: "storeid".trim(),
  MERCHANTID: "merchantid".trim()
}
