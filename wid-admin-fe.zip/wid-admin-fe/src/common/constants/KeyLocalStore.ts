export const KeyLocalStore = {
  userSession: "userSession".trim(),
  accessToken: "accessToken".trim(),
  storeId: "storeId".trim(),
  merchantId: "merchantId".trim(),
}
