import React, { ReactNode } from 'react';
import { DataRouteObject, RouteObject } from 'react-router';
export type IRouter = Omit<RouteObject, "children"> & {
  key: string;
  title?: string;
  isMenu?: boolean
  roles?: string[];
  icon?: ReactNode,
  children?: IRouter[];
};



