import React, { useCallback, useEffect, useState } from 'react';
import { Button, Col, Input, Row, theme } from 'antd';
// import { QrReader } from 'react-qr-reader';
import QrReader from 'react-qr-scanner'
import { useThemeStore } from '~/stores/themeStore';
import { rootApiService, toastService } from '~/services';
import { v4 } from 'uuid';




const DemoView: React.FC = () => {


  const { token: { colorBgContainer } } = theme.useToken();
  const { changeTheme } = useThemeStore();

  const [wid, setWid] = useState("");

  const [inputs, setInputs] = useState({
    apiKey: "",
    programCode: "",
    storeCode: "",

  });


  const onChange = useCallback((key: string, val: string) => {
    setInputs({
      ...inputs,
      [key]: val
    })
  }, [inputs])

  useEffect(() => {
    changeTheme({ themeStyle: "dark" })
  }, [changeTheme])

  const handleScan = (output) => {
    setWid(output?.text)
  }
  const handleError = (err) => {
    console.error(err)
  }

  const renderQrScan = useCallback(() => {
    if (!wid) {
      return <QrReader
        key={v4()}
        delay={100}
        style={{
          height: 500,
          width: '100%',
        }}
        onError={handleError}
        onScan={handleScan}
      />
    }
    return <></>
  }, [wid]);


  const verifyWid = useCallback(() => {
    if (wid) {
      rootApiService.post("api/public/scan-wid", {
        ...inputs,
        wid
      }).then(res => {
        toastService.success()
      }).catch(error => {
        toastService.handleError(error)
      })
    }
  }, [wid]);

  useEffect(() => {
    verifyWid()
  }, [verifyWid])


  return (
    <div style={{ flex: 1, justifyContent: "center", alignItems: "center", width: '100%' }}>
      <Row gutter={[24, 2]}>
        {renderQrScan()}


        <Row style={{ width: '100%' }} justify={"center"}>
          <Col span={16}>
            <Button onClick={() => setWid("")}>
              Show Camera
            </Button>
          </Col>
          <Col span={16}>
            WID
            <Input placeholder='wid' value={wid} />
          </Col>
          <Col span={16}>
            apiKey
            <Input placeholder='apiKey' value={inputs["apiKey"]} onChange={(e) => onChange("apiKey", e.target.value || "")} />
          </Col>
          <Col span={16}>
            programCode
            <Input placeholder='programCode' value={inputs["programCode"]} onChange={(e) => onChange("programCode", e.target.value || "")} />
          </Col>
          <Col span={16}>
            storeCode
            <Input placeholder='storeCode' value={inputs["storeCode"]} onChange={(e) => onChange("storeCode", e.target.value || "")} />
          </Col>
        </Row>

      </Row>

    </div >

  )
}

export default DemoView;
