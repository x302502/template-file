
import { DashboardOutlined, DollarOutlined, KeyOutlined, TransactionOutlined, UnorderedListOutlined, UsergroupAddOutlined } from '@ant-design/icons';
import { Outlet } from 'react-router-dom';
import { v4 } from 'uuid';
import { IRouter } from '~/routers';
import DashboardView from './DashboardView';
import MerchantApiKey from './merchant/ListMerchantView';
import ApiKeyView from './merchant/ApiKeyView';
import UserView from './UserView';
import WidTransactionView from './WidTransactionView';
import NftCollectionView from './NftCollectionView';
import MerchantApiKeyView from './MerchantApiKeyView';
import ListStoreView from './stores/ListStoreView';
import ListProgramView from './programs/ListProgramView';
import ListCampaignView from './campaigns/ListCampaignView';

export const mainRouter: IRouter[] = [

  {
    path: "",
    key: v4(),
    element: <DashboardView />,
    title: "Dashboard",
    isMenu: true,
    icon: <DashboardOutlined />,

  },

  {
    path: "merchant",
    key: v4(),
    element: <Outlet />,
    title: "Merchant",
    isMenu: true,
    icon: <DollarOutlined />,
    children: [
      {
        path: "",
        key: v4(),
        element: <MerchantApiKey />,
        title: "List Merchant",
        isMenu: true,
        icon: <UnorderedListOutlined />,
      },
      {
        path: "api-key",
        key: v4(),
        element: <ApiKeyView />,
        title: "API-KEYs By Merchant",
        isMenu: false,
        icon: <KeyOutlined />,
      },
    ]
  },
  {
    path: "api-key",
    key: v4(),
    element: <MerchantApiKeyView />,
    title: "API-KEYs",
    isMenu: true,
    icon: <KeyOutlined />,

  },
  {
    path: "collections",
    key: v4(),
    element: <NftCollectionView />,
    title: "Collections",
    isMenu: true,
    icon: <TransactionOutlined />,

  },

  {
    path: "users",
    key: v4(),
    element: <UserView />,
    title: "List user",
    isMenu: true,
    icon: <UsergroupAddOutlined />,

  },

  {
    path: "wid-transaction",
    key: v4(),
    element: <WidTransactionView />,
    title: "WID Transaction",
    isMenu: true,
    icon: <TransactionOutlined />,

  },

  {
    path: "stores",
    key: v4(),
    element: <Outlet />,
    title: "Store",
    isMenu: true,
    icon: <DollarOutlined />,
    children: [
      {
        path: "",
        key: v4(),
        element: <ListStoreView />,
        title: "List Store",
        isMenu: true,
        icon: <UnorderedListOutlined />,
      },

    ]
  },

  {
    path: "programs",
    key: v4(),
    element: <Outlet />,
    title: "Programs",
    isMenu: true,
    icon: <DollarOutlined />,
    children: [
      {
        path: "",
        key: v4(),
        element: <ListProgramView />,
        title: "List Programs",
        isMenu: true,
        icon: <UnorderedListOutlined />,
      },

    ]
  },

  {
    path: "campaigns",
    key: v4(),
    element: <Outlet />,
    title: "Campaigns",
    isMenu: true,
    icon: <DollarOutlined />,
    children: [
      {
        path: "",
        key: v4(),
        element: <ListCampaignView />,
        title: "List Campaign",
        isMenu: true,
        icon: <UnorderedListOutlined />,
      },

    ]
  },

]
