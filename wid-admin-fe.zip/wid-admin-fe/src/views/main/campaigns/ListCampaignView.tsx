
import { useState, FC, useCallback } from 'react';
import { Button, Divider, theme, Tag, Row, Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';

import TableControl from '~/@ui/TableControl';
import { toastService } from '~/services';
import { SecurityScanOutlined } from '@ant-design/icons';
import moment from 'moment';
import BaseView from '~/components/BaseView';
import { useNavigate } from 'react-router-dom';
import { MerchantTier, CampaignDto } from '~/dto/merchant.dto';
import { getKeyEnumByValue } from '~/common/utils/common.utils';
import { EProgramStatus, EUserTier } from '~/common/enums';
import { ApiException } from '~/@core/dto';
import campaignService from '~/services/campaign.service';


type IListCampaignViewProps = {
}


type IActionType = "Accept" | "Suspend" | "Reject" | "";

const ActionType = {
  Accept: "Accept",
  Suspend: "Suspend",
  Reject: "Reject",
}

const ListCampaignView: FC<IListCampaignViewProps> = (props: IListCampaignViewProps) => {

  const { token: { colorPrimary, colorSuccess, colorSuccessActive, colorSuccessBg } } = theme.useToken();
  const navigate = useNavigate();

  const [open, setOpen] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [refesh, setRefesh] = useState(true);
  const [itemSelected, setItemSelected] = useState<CampaignDto>(null);
  const [actionType, setActionType] = useState<IActionType>("");

  const columns: ColumnsType<CampaignDto> = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
      ellipsis: true,
    },
    {
      title: 'Merchant Name',
      dataIndex: ["merchant", "name"],
      key: 'merchant.name',
      ellipsis: true,
    },
    {
      title: 'Status',
      dataIndex: "status",
      key: 'status',
      ellipsis: true,
      render: (status: any, record: any, index: number) => {
        return <span>
          {getKeyEnumByValue(EProgramStatus, status)}
        </span>
      }
    },
    {
      title: "W3W Tiers",
      dataIndex: "w3wTiers",
      key: "w3wTiers",
      width: 200,
      render: (w3wTiers: number[], record: any, index: number) => {
        return <span>
          {w3wTiers.map(tier => (
            <Tag color={colorPrimary}>
              {getKeyEnumByValue(EUserTier, tier)}
            </Tag>
          ))}
        </span>
      }
    },
    {
      title: "Merchant Tier",
      dataIndex: "listMerchantTier",
      key: "listMerchantTier",
      width: 200,
      render: (listMerchantTier: MerchantTier[], record: any, index: number) => {
        if (!listMerchantTier.length) {
          return null;
        }
        return <span>
          {listMerchantTier[0].name}
          <br />
          {listMerchantTier.map(item => (
            <Tag color={colorPrimary}>
              {item.tierName}
            </Tag>
          ))}
        </span>
      }
    },
    {
      title: "Start Time",
      dataIndex: "startTime",
      key: "startTime",
      width: 200,
      render: (value: any, record: any, index: number) => {
        const dateFormat = 'YYYY-MM-DD hh:mm';
        return <span>{moment(value, dateFormat).format('DD-MM-YYYY hh:mm')}</span>
      }
    },

    {
      title: "End Time",
      dataIndex: "endTime",
      key: "endTime",
      width: 200,
      render: (value: any, record: any, index: number) => {
        const dateFormat = 'YYYY-MM-DD hh:mm';
        return <span>{moment(value, dateFormat).format('DD-MM-YYYY hh:mm')}</span>
      }
    },

    {
      key: "action",
      title: "Action",
      ellipsis: true,
      render: (value: any, record: CampaignDto, index: number) => {
        const { status } = record;
        return (
          <span>
            <Button disabled={!(status === EProgramStatus.REQUEST_PUBLISHED)} type='primary' size='small' icon={<SecurityScanOutlined />}
              onClick={openModal.bind(this, record, ActionType.Accept)}
            >
              Accept
            </Button>
            <Button type='primary' disabled={!(status === EProgramStatus.REQUEST_PUBLISHED)} size='small' icon={<SecurityScanOutlined />}
              onClick={openModal.bind(this, record, ActionType.Reject)}
            >
              Reject
            </Button>
            <Button danger disabled={!(status === EProgramStatus.PUBLISHED)} type='primary' size='small' icon={<SecurityScanOutlined />}
              onClick={openModal.bind(this, record, ActionType.Suspend)}
            >
              Suspend
            </Button>
          </span>
        )

      }
    }

  ];


  const handleOk = async () => {
    setConfirmLoading(true);
    try {
      if (!itemSelected || !itemSelected.id) {
        throw new ApiException("Not existed program sellected")
      }
      if (actionType === ActionType.Accept) {
        await campaignService.verifyCampaign({
          id: itemSelected.id
        })
      }
      if (actionType === ActionType.Reject) {
        await campaignService.rejectRequestCampaign({
          id: itemSelected.id
        })
      }

      if (actionType === ActionType.Suspend) {
        await campaignService.suspendCampaign({
          id: itemSelected.id
        })
      }
      setOpen(false);
      setRefesh(!refesh)
    } catch (error) {
      toastService.handleError(error)
    }
    setConfirmLoading(false);
  };

  const handleCancel = () => {

    setOpen(false);
    setActionType("");
  };



  const openModal = useCallback((item: CampaignDto, actionType: IActionType) => {
    setItemSelected(item);
    setActionType(actionType);
    setOpen(true)
  }, []);


  const loadData = useCallback(({ pageIndex, pageSize }: { pageIndex: number, pageSize: number }) => {
    return campaignService.list({
      pageIndex, pageSize
    })
  }, [refesh])


  const getTitleModal = (actionType: IActionType) => {
    if (!actionType) {
      return "";
    }
    if (actionType === ActionType.Accept) {
      return "Accept Program";
    }
    if (actionType === ActionType.Reject) {
      return "Reject Program";
    }
    if (actionType === ActionType.Suspend) {
      return "Suspend Program";
    }
    return "";
  }


  return (
    <BaseView>
      <Row>
        <Divider />
      </Row>

      <TableControl
        columns={columns}

        // dataSource={[]}
        // defaultPageSize={20}
        loadData={loadData}
      />
      <Modal
        title={getTitleModal(actionType)}
        open={open}
        onOk={handleOk}
        confirmLoading={confirmLoading}
        onCancel={handleCancel}
      >
      </Modal>

    </BaseView>
  )
}
export default ListCampaignView;
