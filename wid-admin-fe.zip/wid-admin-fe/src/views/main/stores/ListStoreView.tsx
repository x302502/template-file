
import { useState, FC, useCallback } from 'react';
import { Button, Image, Divider, theme, Tag, Row, Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';

import TableControl from '~/@ui/TableControl';
import { toastService } from '~/services';
import { CheckCircleOutlined, ExclamationCircleOutlined, SyncOutlined, SecurityScanOutlined, KeyOutlined, UserOutlined } from '@ant-design/icons';
import moment from 'moment';
import BaseView from '~/components/BaseView';
import { createSearchParams, useNavigate } from 'react-router-dom';
import merchantService from '~/services/merchant.service';
import { Merchant } from '~/dto/merchant.dto';
import { getKeyEnumByValue } from '~/common/utils/common.utils';
import { EMerchantStatus } from '~/common/enums';
import storeService from '~/services/store.service';
import { Store } from '~/dto/store.dto';


type IListStoreViewProps = {
}

const ListStoreView: FC<IListStoreViewProps> = (props: IListStoreViewProps) => {

  const { token: { colorPrimary, colorSuccess, colorSuccessActive, colorSuccessBg } } = theme.useToken();
  const navigate = useNavigate();

  const [open, setOpen] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [refesh, setRefesh] = useState(true);
  const [idSelected, setIdSelected] = useState("");

  const columns: ColumnsType<Store> = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
      ellipsis: true,
    },
    {
      title: 'Code',
      dataIndex: 'storeCode',
      key: 'storeCode',
      ellipsis: true,
    },
    {
      title: "Address",
      dataIndex: "address",
      key: "address",
      width: 200,
    },
    {
      title: "Created Date",
      dataIndex: "createdDate",
      key: "createdDate",
      width: 200,
      render: (value: any, record: any, index: number) => {
        const dateFormat = 'YYYY-MM-DD hh:mm';
        return <span>{moment(value, dateFormat).format('DD-MM-YYYY hh:mm')}</span>
      }
    },

    {
      key: "action",
      title: "Action",
      ellipsis: true,
      render: (value: any, record: Store, index: number) => {
        return (
          <span>

            <Button type='dashed' icon={<KeyOutlined />}
            // onClick={() => navigate({
            //   pathname: "api-key",
            //   search: createSearchParams({
            //     merchantId: record.id
            //   }).toString()
            // })}
            />


          </span>
        )
      }
    }

  ];


  const handleOk = async () => {
    setConfirmLoading(true);
    try {

      setOpen(false);
      setRefesh(!refesh)
    } catch (error) {
      toastService.handleError(error)
    }
    setConfirmLoading(false);
  };

  const handleCancel = () => {

    setOpen(false);
  };



  const openModal = useCallback((id: string) => {
    setIdSelected(id);
    setOpen(true)
  }, []);


  const loadData = useCallback(({ pageIndex, pageSize }: { pageIndex: number, pageSize: number }) => {
    return storeService.list({
      pageIndex, pageSize
    })
  }, [refesh])


  return (
    <BaseView>
      <Row>
        <Divider />
      </Row>

      <TableControl
        columns={columns}

        // dataSource={[]}
        // defaultPageSize={20}
        loadData={loadData}
      />
      <Modal
        title='Verify Merchant'
        open={open}
        onOk={handleOk}
        confirmLoading={confirmLoading}
        onCancel={handleCancel}
      >
      </Modal>

    </BaseView>
  )
}
export default ListStoreView;
