
import { useState, FC, useCallback } from 'react';
import { Divider, Row, Tag, theme } from 'antd';
import type { ColumnsType } from 'antd/es/table';

import TableControl from '~/@ui/TableControl';
import { CopyOutlined, CheckOutlined, CheckCircleOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import moment from 'moment';
import BaseView from '~/components/BaseView';
import Paragraph from 'antd/es/typography/Paragraph';
import userService from '~/services/user.service';
import { EUserStatus, EUserTier } from '~/common/enums';
import { getKeyEnumByValue } from '~/common/utils/common.utils';



type IUserViewProps = {
}

const UserView: FC<IUserViewProps> = () => {

  const [refesh, setRefesh] = useState(true);
  const [idSelected, setIdSelected] = useState("");
  const { token: { colorPrimary, colorSuccess, colorSuccessActive, colorSuccessBg } } = theme.useToken();


  const columns: ColumnsType<any> = [
    {
      title: 'WID',
      dataIndex: 'wid',
      key: 'wid',
      ellipsis: true,
      render: (value: string) => {
        return <Paragraph ellipsis copyable={{
          icon: [<CopyOutlined key="copy-icon" />, <CheckOutlined key="copied-icon" />],
          tooltips: ['Copy', 'Copy success'],
        }}>{value}</Paragraph>
      }
    },
    {
      title: 'Wallet address',
      dataIndex: 'walletAddress',
      key: 'walletAddress',
      ellipsis: true,
      render: (value: string) => {
        return <Paragraph ellipsis copyable={{
          icon: [<CopyOutlined key="copy-icon" />, <CheckOutlined key="copied-icon" />],
          tooltips: ['Copy', 'Copy success'],
        }}>{value}</Paragraph>
      }
    },
    {
      title: 'Name',
      dataIndex: 'fullName',
      key: 'fullName',
      ellipsis: true,
      width: 120,
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email',
      ellipsis: true,
      width: 120,
    },
    {
      title: "Tier",
      dataIndex: "tier",
      key: "tier",
      width: 120,
      render: (value: any, record: any, index: number) => {
        return <span>
          <Tag color={colorPrimary}>
            {getKeyEnumByValue(EUserTier, value)}
          </Tag>
        </span>
      }
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 200,
      render: (status: any, record: any, index: number) => {
        return <span>
          {status === EUserStatus.INACTIVE && <Tag icon={<ExclamationCircleOutlined />} color="warning">
            {getKeyEnumByValue(EUserStatus, status)}
          </Tag>}
          {status === EUserStatus.ACTIVE && <Tag icon={<CheckCircleOutlined />} color="success">
            {getKeyEnumByValue(EUserStatus, status)}
          </Tag>}
        </span>
      }
    },
    {
      title: "Created",
      dataIndex: "createdDate",
      key: "createdDate",

      render: (value: any) => {
        const dateFormat = 'YYYY-MM-DD hh:mm';
        return <span>{moment(value, dateFormat).format('DD-MM-YYYY hh:mm')}</span>
      }
    },

  ];


  const loadData = useCallback(({ pageIndex, pageSize }: { pageIndex: number, pageSize: number }) => {
    return userService.list({
      pageIndex, pageSize
    })
  }, [])

  return (
    <BaseView>
      <Row>

        <Divider />
      </Row>
      <TableControl
        columns={columns}

        // dataSource={[]}
        // defaultPageSize={20}
        loadData={loadData}
      />

    </BaseView>
  )
}
export default UserView;
