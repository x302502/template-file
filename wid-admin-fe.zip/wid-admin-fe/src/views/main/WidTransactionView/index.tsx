
import { useState, FC, useCallback } from 'react';
import { Divider, Row } from 'antd';
import type { ColumnsType } from 'antd/es/table';

import TableControl from '~/@ui/TableControl';
import { CopyOutlined, CheckOutlined } from '@ant-design/icons';
import moment from 'moment';
import BaseView from '~/components/BaseView';
import { useSearchParams } from 'react-router-dom';
import merchantService from '~/services/merchant.service';
import { MerchantApiKey } from '~/dto/merchant.dto';
import Paragraph from 'antd/es/typography/Paragraph';
import widTransactionService from '~/services/wid-transaction.service';



type IWidTransactionViewProps = {
}

const WidTransactionView: FC<IWidTransactionViewProps> = () => {

  const [refesh, setRefesh] = useState(true);
  const [idSelected, setIdSelected] = useState("");


  const columns: ColumnsType<MerchantApiKey & { merchantName: string }> = [
    {
      title: 'Merchant',
      dataIndex: 'merchantName',
      key: 'merchantName',
      ellipsis: true,
    },
    {
      title: 'Store',
      dataIndex: 'storeName',
      key: 'storeName',
      ellipsis: true,
    },
    {
      title: 'Program',
      dataIndex: 'programName',
      key: 'programName',
      ellipsis: true,
    },
    {
      title: 'WID',
      dataIndex: 'wid',
      key: 'wid',
      ellipsis: true,
      render: (value: string) => {
        return <Paragraph ellipsis copyable={{
          icon: [<CopyOutlined key="copy-icon" />, <CheckOutlined key="copied-icon" />],
          tooltips: ['Copy', 'Copy success'],
        }}>{value}</Paragraph>
      }
    },
    {
      title: 'Api key token',
      dataIndex: 'apiKey',
      key: 'apiKey',
      ellipsis: true,
      render: (value: string) => {
        return <Paragraph ellipsis copyable={{
          icon: [<CopyOutlined key="copy-icon" />, <CheckOutlined key="copied-icon" />],
          tooltips: ['Copy', 'Copy success'],
        }}>{value}</Paragraph>
      }
    },
    {
      title: "Verify time",
      dataIndex: "createdDate",
      key: "createdDate",

      render: (value: any) => {
        const dateFormat = 'YYYY-MM-DD hh:mm';
        return <span>{moment(value, dateFormat).format('DD-MM-YYYY hh:mm')}</span>
      }
    },

  ];


  const loadData = useCallback(({ pageIndex, pageSize }: { pageIndex: number, pageSize: number }) => {
    return widTransactionService.list({
      pageIndex, pageSize
    })
  }, [])

  return (
    <BaseView>
      <Row>

        <Divider />
      </Row>
      <TableControl
        columns={columns}

        // dataSource={[]}
        // defaultPageSize={20}
        loadData={loadData}
      />

    </BaseView>
  )
}
export default WidTransactionView;
