
import { useState, FC, useCallback } from 'react';
import { Divider, Row, Tag, theme, Image } from 'antd';
import type { ColumnsType } from 'antd/es/table';

import TableControl from '~/@ui/TableControl';
import { CopyOutlined, CheckOutlined, CheckCircleOutlined, ExclamationCircleOutlined, } from '@ant-design/icons';
import moment from 'moment';
import BaseView from '~/components/BaseView';
import Paragraph from 'antd/es/typography/Paragraph';
import userService from '~/services/user.service';
import { EUserStatus, EUserTier } from '~/common/enums';
import { getKeyEnumByValue } from '~/common/utils/common.utils';
import nftService from '~/services/nft.service';



type INftCollectionViewProps = {
}

const NftCollectionView: FC<INftCollectionViewProps> = () => {

  const [refesh, setRefesh] = useState(true);
  const [idSelected, setIdSelected] = useState("");
  const { token: { colorPrimary, colorSuccess, colorSuccessActive, colorSuccessBg } } = theme.useToken();


  const columns: ColumnsType<any> = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
      ellipsis: true,
    },
    {
      title: 'Image',
      dataIndex: 'image',
      key: 'image',
      ellipsis: true,
      render: (value: string, record: any, index: number) => {
        return <Image src={value} alt="image" style={{ width: 30, height: 30 }} />
      }
    },
    {
      title: 'Symbol',
      key: 'symbol',
      dataIndex: 'symbol',
      ellipsis: true,
    },
    {
      title: 'floorPrice',
      key: 'floorPrice',
      dataIndex: 'floorPrice',
      ellipsis: true,
    },

    {
      title: 'Status',
      key: 'status',
      dataIndex: 'status',
      ellipsis: true,
      render: (status: any, record: any, index: number) => {
        return <span>
          {status === EUserStatus.INACTIVE && <Tag icon={<ExclamationCircleOutlined />} color="warning">
            {getKeyEnumByValue(EUserStatus, status)}
          </Tag>}
          {status === EUserStatus.ACTIVE && <Tag icon={<CheckCircleOutlined />} color="success">
            {getKeyEnumByValue(EUserStatus, status)}
          </Tag>}
        </span>
      }
    },

    {
      title: "Created Date",
      dataIndex: "createdDate",
      key: "createdDate",
      width: 200,
      render: (value: any, record: any, index: number) => {
        const dateFormat = 'YYYY-MM-DD hh:mm';
        return <span>{moment(value, dateFormat).format('DD-MM-YYYY hh:mm')}</span>
      }
    },

  ];


  const loadData = useCallback(({ pageIndex, pageSize }: { pageIndex: number, pageSize: number }) => {
    return nftService.listCollection({
      pageIndex, pageSize
    })
  }, [])

  return (
    <BaseView>
      <Row>

        <Divider />
      </Row>
      <TableControl
        columns={columns}

        // dataSource={[]}
        // defaultPageSize={20}
        loadData={loadData}
      />

    </BaseView>
  )
}
export default NftCollectionView;
