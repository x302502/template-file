
import { useState, FC, useCallback } from 'react';
import { Button, Image, Divider, theme, Tag, Row, Modal } from 'antd';
import type { ColumnsType } from 'antd/es/table';

import TableControl from '~/@ui/TableControl';
import { toastService } from '~/services';
import { CheckCircleOutlined, ExclamationCircleOutlined, SyncOutlined, SecurityScanOutlined, KeyOutlined, UserOutlined } from '@ant-design/icons';
import moment from 'moment';
import BaseView from '~/components/BaseView';
import { createSearchParams, useNavigate } from 'react-router-dom';
import merchantService from '~/services/merchant.service';
import { Merchant } from '~/dto/merchant.dto';
import { getKeyEnumByValue } from '~/common/utils/common.utils';
import { EMerchantStatus } from '~/common/enums';


type IListMerchantViewProps = {
}

const ListMerchantView: FC<IListMerchantViewProps> = (props: IListMerchantViewProps) => {

  const { token: { colorPrimary, colorSuccess, colorSuccessActive, colorSuccessBg } } = theme.useToken();
  const navigate = useNavigate();

  const [open, setOpen] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [refesh, setRefesh] = useState(true);
  const [idSelected, setIdSelected] = useState("");

  const columns: ColumnsType<Merchant> = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
      ellipsis: true,
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email',
      ellipsis: true,
    },
    {
      title: 'Company Name',
      dataIndex: 'companyName',
      key: 'companyName',
      ellipsis: true,
    },
    {
      title: 'Logo',
      dataIndex: 'logo',
      key: 'logo',
      ellipsis: true,
      render: (value: string, record: Merchant, index: number) => {
        return value ? <Image src={value} style={{ width: 30, height: 30 }} /> : <UserOutlined />
      }
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 200,
      render: (status: any, record: any, index: number) => {
        return <span>
          {status === EMerchantStatus.PENDING && <Tag icon={<ExclamationCircleOutlined />} color="warning">
            {getKeyEnumByValue(EMerchantStatus, status)}
          </Tag>}

          {status === EMerchantStatus.VERIFY && <Tag icon={<CheckCircleOutlined />} color="success">
            {getKeyEnumByValue(EMerchantStatus, status)}
          </Tag>}

          {status === EMerchantStatus.RELEASE && <Tag icon={<SyncOutlined spin />} color="processing">
            {getKeyEnumByValue(EMerchantStatus, status)}
          </Tag>}
        </span>
      }
    },
    {
      title: "Created Date",
      dataIndex: "createdDate",
      key: "createdDate",
      width: 200,
      render: (value: any, record: any, index: number) => {
        const dateFormat = 'YYYY-MM-DD hh:mm';
        return <span>{moment(value, dateFormat).format('DD-MM-YYYY hh:mm')}</span>
      }
    },

    {
      key: "action",
      title: "Action",
      ellipsis: true,
      render: (value: any, record: Merchant, index: number) => {
        return (
          <span>

            <Button type='primary' icon={<SecurityScanOutlined />}
              onClick={openModal.bind(this, record.id)}
            >
              Verify
            </Button>

            <Button type='dashed' icon={<KeyOutlined />}
              onClick={() => navigate({
                pathname: "api-key",
                search: createSearchParams({
                  merchantId: record.id
                }).toString()
              })}
            />


          </span>
        )
      }
    }

  ];


  const handleOk = async () => {
    setConfirmLoading(true);
    try {
      await merchantService.verify({ id: idSelected });
      setOpen(false);
      setRefesh(!refesh)
    } catch (error) {
      toastService.handleError(error)
    }
    setConfirmLoading(false);
  };

  const handleCancel = () => {
    setOpen(false);
  };



  const openModal = useCallback((id: string) => {
    setIdSelected(id);
    setOpen(true)
  }, []);


  const loadData = useCallback(({ pageIndex, pageSize }: { pageIndex: number, pageSize: number }) => {
    return merchantService.list({
      pageIndex, pageSize
    })
  }, [refesh])


  return (
    <BaseView>
      <Row>
        <Divider />
      </Row>

      <TableControl
        columns={columns}

        // dataSource={[]}
        // defaultPageSize={20}
        loadData={loadData}
      />
      <Modal
        title='Verify Merchant'
        open={open}
        onOk={handleOk}
        confirmLoading={confirmLoading}
        onCancel={handleCancel}
      >
      </Modal>

    </BaseView>
  )
}
export default ListMerchantView;
