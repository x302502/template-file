
import { useState, FC, useCallback } from 'react';
import { Divider, Row } from 'antd';
import type { ColumnsType } from 'antd/es/table';

import TableControl from '~/@ui/TableControl';
import { CopyOutlined, CheckOutlined } from '@ant-design/icons';
import moment from 'moment';
import BaseView from '~/components/BaseView';
import { useSearchParams } from 'react-router-dom';
import merchantService from '~/services/merchant.service';
import { MerchantApiKey } from '~/dto/merchant.dto';
import Paragraph from 'antd/es/typography/Paragraph';



type IMerchantApiKeyViewProps = {
}

const MerchantApiKeyView: FC<IMerchantApiKeyViewProps> = () => {

  const [refesh, setRefesh] = useState(true);
  const [idSelected, setIdSelected] = useState("");


  const columns: ColumnsType<MerchantApiKey & { merchantName: string }> = [
    {
      title: 'Merchant name',
      dataIndex: 'merchantName',
      key: 'merchantName',
      ellipsis: true,
    },
    {
      title: 'Key name',
      dataIndex: 'keyName',
      key: 'keyName',
      ellipsis: true,
    },
    {
      title: 'Api key token',
      dataIndex: 'apiKey',
      key: 'apiKey',
      ellipsis: true,
      render: (value: string) => {
        return <Paragraph ellipsis copyable={{
          icon: [<CopyOutlined key="copy-icon" />, <CheckOutlined key="copied-icon" />],
          tooltips: ['Copy', 'Copy success'],
        }}>{value}</Paragraph>
      }
    },
    {
      title: "Created",
      dataIndex: "createdDate",
      key: "createdDate",

      render: (value: any) => {
        const dateFormat = 'YYYY-MM-DD hh:mm';
        return <span>{moment(value, dateFormat).format('DD-MM-YYYY hh:mm')}</span>
      }
    },

  ];


  const loadData = useCallback(({ pageIndex, pageSize }: { pageIndex: number, pageSize: number }) => {
    return merchantService.listMerchantApiKey({
      pageIndex, pageSize
    })
  }, [])

  return (
    <BaseView>
      <Row>

        <Divider />
      </Row>
      <TableControl
        columns={columns}

        // dataSource={[]}
        // defaultPageSize={20}
        loadData={loadData}
      />

    </BaseView>
  )
}
export default MerchantApiKeyView;
