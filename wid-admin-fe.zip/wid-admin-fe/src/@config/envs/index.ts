export { default as dev } from './dev';
export { default as qa } from './qa';
export { default as prod } from './prod';