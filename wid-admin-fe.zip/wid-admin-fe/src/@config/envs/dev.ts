import { IEnvConfig } from '..';

const config: IEnvConfig = {
  name: "DEVELOPMENT",
  CONNECTORS: {
    ROOT: {
      baseUrl: "http://localhost:7002"
    }
  }
}

export default config;
