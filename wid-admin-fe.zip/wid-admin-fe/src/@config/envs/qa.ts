import { IEnvConfig } from '..';

const config: IEnvConfig = {
  name: "QA",
  CONNECTORS: {
    ROOT: {
      baseUrl: "https://qa.api.wid.famcentral.io"
    }
  }
}

export default config;
