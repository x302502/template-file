import { IEnvConfig } from '..';

const config: IEnvConfig = {
  name: "PRODUCTION",
  CONNECTORS: {
    ROOT: {
      baseUrl: "https://api.wid.famcentral.io"
    },
  }
}

export default config;
