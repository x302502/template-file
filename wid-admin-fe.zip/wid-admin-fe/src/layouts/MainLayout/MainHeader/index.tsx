


import { FC, useState } from 'react';
import screenfull from "screenfull";
import { LogoutOutlined, MenuFoldOutlined, MenuUnfoldOutlined, UserOutlined } from '@ant-design/icons';
import { Dropdown, Layout, theme as antTheme, Tooltip } from 'antd';
import { createElement } from 'react';
import { useNavigate } from 'react-router-dom';
import Avator from '~/assets/header/avator.jpeg';
import { ReactComponent as EnUsSvg } from '~/assets/header/en_US.svg';
import { ReactComponent as LanguageSvg } from '~/assets/header/language.svg';
import { ReactComponent as MoonSvg } from '~/assets/header/moon.svg';
import { ReactComponent as SunSvg } from '~/assets/header/sun.svg';
import { ReactComponent as ZhCnSvg } from '~/assets/header/zh_CN.svg';
import AntdSvg from '~/assets/logo/antd.svg';
import ReactSvg from '~/assets/logo/react.svg';
import ALogo from '~/assets/logo/A.png';
import BLogo from '~/assets/logo/B.png';
import CLogo from '~/assets/logo/C.png';
import { LocaleFormatter, useLocale } from '~/locales';
import { useThemeStore } from '~/stores/themeStore';
import { useAuthStore } from '~/stores/authStore';
import { useLayoutConfig } from '~/stores/layoutConfig';
import FullScreen from '~/components/FullScreen';


const { Header } = Layout;


type IMainHeaderProps = {
  collapsed: boolean;
  toggle: () => void;
}

type Action = 'userInfo' | 'userSetting' | 'logout';

const MainHeader: FC<IMainHeaderProps> = ({ collapsed, toggle }: IMainHeaderProps) => {

  const token = antTheme.useToken();
  const { mode, themeStyle, changeTheme } = useThemeStore();
  const { logged, logout, userInfo } = useAuthStore();
  const navigate = useNavigate();
  const { formatMessage } = useLocale();

  const { device } = useLayoutConfig();


  const toLogin = () => {
    navigate('/login');
  };

  const onChangeTheme = () => {
    const newTheme = themeStyle === 'dark' ? 'light' : 'dark';

    localStorage.setItem('theme', newTheme);
    changeTheme({ themeStyle: newTheme })
  };

  return (
    <Header className="layout-page-header bg-2" style={{ backgroundColor: token.token.colorBgContainer }}>
      {device !== 'MOBILE' && (
        <div className="logo" style={{ width: collapsed ? 80 : 200 }}>
          <img src={ReactSvg} alt="" style={{ marginRight: collapsed ? '2px' : '20px' }} />
          {/* <img src={AntdSvg} alt="" /> */}
        </div>
      )}
      <div className="layout-page-header-main">
        <div onClick={toggle}>
          <span id="sidebar-trigger">{collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}</span>
        </div>
        <div className="actions">
          <Tooltip
            title={formatMessage({
              id: themeStyle === 'dark' ? 'gloabal.tips.theme.lightTooltip' : 'gloabal.tips.theme.darkTooltip',
            })}
          >
            <span>
              {createElement(themeStyle === 'dark' ? SunSvg : MoonSvg, {
                onClick: onChangeTheme,
              })}
            </span>
          </Tooltip>

          <FullScreen />

          {/* <HeaderNoticeComponent /> */}
          <Dropdown
            menu={{
              // onClick: info => selectLocale(info),
              items: [
                {
                  key: 'zh_CN',
                  icon: <ZhCnSvg />,
                  // disabled: locale === 'zh_CN',
                  label: '简体中文',
                },
                {
                  key: 'en_US',
                  icon: <EnUsSvg />,
                  // disabled: locale === 'en_US',
                  label: 'English',
                },
              ],
            }}
          >
            <span>
              <LanguageSvg id="language-change" />
            </span>
          </Dropdown>

          {logged ? (
            <Dropdown
              menu={{
                items: [
                  // {
                  //   key: '1',
                  //   icon: <UserOutlined />,
                  //   label: (
                  //     <span onClick={() => navigate('/dashboard')}>
                  //       <LocaleFormatter id="header.avator.account" />
                  //     </span>
                  //   ),
                  // },
                  {
                    key: '2',
                    icon: <LogoutOutlined />,
                    label: (
                      <span onClick={logout}>
                        <LocaleFormatter id="header.avator.logout" />
                      </span>
                    ),
                  },
                ],
              }}
            >
              <span className="user-action">
                <img src={userInfo?.avatar || Avator} className="user-avator" alt="avator" />
              </span>
            </Dropdown>
          ) : (
            <span style={{ cursor: 'pointer' }} onClick={toLogin}>
              {formatMessage({ id: 'gloabal.tips.login' })}
            </span>
          )}
        </div>
      </div>
    </Header>
  );
}
export default MainHeader;
