
now="$(date +'%Y-%m-%d %H:%M:%S')"
message="update $now";
git add . ;
git commit -m "$message";
git push;


rm -rf build-local;
git clone -b qa --single-branch https://gitlab.com/f-holding/wid-admin-fe.git build-local;
cd build-local;
yarn;
yarn build:qa;
zip -r build.zip build

scp ./build.zip root@143.198.220.202:/opt/front-end/;

ssh root@143.198.220.202 "
    cd /opt/front-end/;
    rm -rf qa.wid-admin.famcentral.io;
    rm -rf build;
    unzip build.zip;
    mv build qa.wid-admin.famcentral.io;
    rm -f build.zip;
    exit;
";

rm -f ./build.zip;
