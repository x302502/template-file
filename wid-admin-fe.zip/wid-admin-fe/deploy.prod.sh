
now="$(date +'%Y-%m-%d %H:%M:%S')"
message="update $now";
git add . ;
git commit -m "$message";
git push;


rm -rf build-local;
git clone -b prod --single-branch https://gitlab.com/f-holding/wid-admin-fe.git build-local;
cd build-local;
yarn;
yarn build:prod;
zip -r build.zip build

scp ./build.zip root@157.230.252.203:/opt/front-end/;

ssh root@157.230.252.203 "
    cd /opt/front-end/;
    rm -rf admin.w3w.link;
    rm -rf build;
    unzip build.zip;
    mv build admin.w3w.link;
    rm -f build.zip;
    exit;
";

rm -f ./build.zip;
